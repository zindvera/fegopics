<?php
if (!defined('ABSPATH')) exit;

function scrollstrike_render_support_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized entry.', 'scrollstrike'));
    }
?>
    <div class="wrap">
        <div class="ss-support-wrap">
            <div class="ss-support-dashboard">

                <div class="ss-support-header">
                    <h1><?php esc_html_e('Help & Support', 'scrollstrike'); ?></h1>
                    <p class="ss-support-intro-text"><?php esc_html_e('Have a query or need help with ScrollStrike? You can email us directly at:', 'scrollstrike'); ?></p>
                    <div class="ss-premium-email-block">
                        <a href="mailto:support@fegopics.online" class="ss-support-email-link">support@fegopics.online</a>
                    </div>
                </div>

                <div class="ss-faq-container">
                    <div class="ss-faq-category-block">
                        <h2>⚙️ <?php esc_html_e('Highlighter Behavior', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How do I create and deploy a new scroll-triggered highlighter?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Open any post or page inside your WordPress block editor. Highlight the text or phrase you want to use to get clicks, click the ScrollStrike marker icon inside your text formatting toolbar, type out your popup message, and save your post to set it live.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Will deleting a highlighter from my library break my website page layouts?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('No. When you delete a highlighter from your dashboard library, the plugin automatically cleans up your website data behind the scenes. Your original paragraph text stays perfectly safe and remains on your page as normal, unhighlighted text.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q3:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('What happens if two highlighters overlap on the same page text?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('To keep your page layout looking clean and prevent confusing your readers, each specific piece of text can only have one highlighter applied to it at a time. If you want to highlight a different section, simply select a new phrase down the page.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-show-more-container ss-hide">
                            <button class="ss-show-more-btn" onclick="ssShowMore(this)"><?php esc_html_e('+ Show More Questions', 'scrollstrike'); ?></button>
                        </div>
                    </div>

                    <div class="ss-faq-category-block">
                        <h2>🔒 <?php esc_html_e('Free Plan Limits', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How many total highlighters am I allowed to create on the Free plan?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('On the Free plan, you are strictly limited to a maximum of 3 highlighters across your entire website. Here is how this restriction works:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('You can build up to 3 separate highlighters using the basic template settings.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Once you reach this 3-highlighter limit, the plugin will block you from creating any more.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('To build new highlighters or reuse an unlimited number from your library, you must click Upgrade to PRO and activate a premium license key.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('What exact styling tools are locked behind the PRO version when I build a highlighter?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('When you are on the Free plan, the studio editor disables the advanced design options that help boost link clicks:', 'scrollstrike'); ?>
                                    <ul>
                                        <li><strong><?php esc_html_e('Plain Text Only:', 'scrollstrike'); ?></strong> <?php esc_html_e('The rich text toolbar is completely hidden. You cannot add custom headings, bold words, or clickable hyperlink text inside your highlighter message.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('No Custom Colors:', 'scrollstrike'); ?></strong> <?php esc_html_e('You cannot type in your website\'s exact brand hex codes. The custom color palette map is locked.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('No Focus Mode:', 'scrollstrike'); ?></strong> <?php esc_html_e('The toggle switch to dim and blur the rest of your page layout when a reader scrolls by is completely locked.', 'scrollstrike'); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q3:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Which colors am I allowed to use for my highlighter text boxes on the Free plan?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('You are limited to 8 simple, built-in preset design colors. You can easily select from these options inside the editor:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('Premium Pink', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Dark Navy', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Royal Blue', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Emerald Green', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Teal', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Orange', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Crimson Red', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Purple', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item ss-hidden-faq">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q4:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('If I am on the Free plan, can I still use custom timing delays for when my highlighters appear?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Yes! The trigger delay features are fully unlocked for free users:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('You can still type custom numbers or decimals (like 0.5 seconds) into the Trigger Delay input box.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('The highlighter will wait exactly that long to pop up after a reader scrolls past your target text.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item ss-hidden-faq">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q5:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How many links can I apply my highlighters to on the Free plan?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('You can apply highlighters to a maximum of 3 links across your entire website. Because the Free plan limits you to creating only 3 total highlighters, you can distribute them however you like:', 'scrollstrike'); ?>
                                    <ul>
                                        <li><?php esc_html_e('You can put 1 highlighter on 3 different links (using up all 3).', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('You can put 2 highlighters on 2 links and have 1 leftover.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('No matter how you mix and match it, the system will stop you the moment you try to highlight a 4th link.', 'scrollstrike'); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="ss-show-more-container">
                            <button class="ss-show-more-btn" onclick="ssShowMore(this)"><?php esc_html_e('+ Show More Questions', 'scrollstrike'); ?></button>
                        </div>
                    </div>

                    <div class="ss-faq-category-block">
                        <h2>⭐ <?php esc_html_e('Upgrading to PRO', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How do I upgrade my account from the Free version to the PRO tier?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('You can unlock premium features by purchasing a license key using these steps:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('Go to your WordPress sidebar menu and click on ScrollStrike -> Upgrade to PRO.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Review the active plan cards on the screen (such as the 30-day, 60-day, or 365-day access tiers) and choose the option that fits your needs.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Click the Get License button underneath your chosen plan card to open the Gumroad checkout window.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Complete your purchase on Gumroad to generate your premium license code.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Copy the code string from your Gumroad receipt page or your confirmation email.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Go back to your WordPress dashboard, paste the license key directly into the input box, and click Activate.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Will my active hyperlink text or existing highlighter cards stop working when I upgrade?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('No, your live hyperlink text and active highlighters remain completely safe. Here is how the transition works:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('The plugin updates your system status from free to premium levels immediately in the background.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Every existing highlight message and action link currently deployed on your posts remains live exactly where it is.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('The editor studio instantly removes the free tier restriction boundaries so you can start styling your links with advanced features.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q3:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Once my PRO license key expires, how do I reactivate my account to keep using the PRO version?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('When your plan ends, your account drops back to the free tier. You can buy a new plan and reactivate your features by following these exact steps:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('Go to your WordPress sidebar menu and click on ScrollStrike -> Upgrade to PRO.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Select your preferred access plan card (such as 30, 60, or 365 days) and click the Get License button to open the Gumroad checkout.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Complete your purchase on Gumroad to generate your new license code.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Copy the code string from your Gumroad receipt page or your confirmation email.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Go back to your WordPress dashboard, paste the new license key directly into the input box, and click Activate.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item ss-hidden-faq">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q4:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('What advanced styling features unlock inside the block editor to help increase my hyperlink click rates?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('The editor removes all structural free plan restrictions instantly, giving you these tools:', 'scrollstrike'); ?>
                                    <ul>
                                        <li><strong><?php esc_html_e('The Rich Text Toolbar:', 'scrollstrike'); ?></strong> <?php esc_html_e('You can format your highlighter cards with custom headings, bold phrases, and clickable hyperlink text to direct readers straight to your offers.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('The Custom Hex Spectrum Map:', 'scrollstrike'); ?></strong> <?php esc_html_e('You can use a full interactive palette to match your exact brand hex codes, drawing immediate attention to your target link elements.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('Focus Blur Toggle:', 'scrollstrike'); ?></strong> <?php esc_html_e('You unlock a toggle switch that automatically dims and blurs the entire post layout when a reader scrolls by, forcing their focus onto your action link card.', 'scrollstrike'); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item ss-hidden-faq">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q5:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Can I register a single premium license key to manage action links across multiple separate websites?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('No, each individual license key is restricted to a single WordPress installation. If you operate multiple distinct websites or separate affiliate networks, you must go through the Get License process on each individual site dashboard to run un-capped highlighter cards.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-show-more-container">
                            <button class="ss-show-more-btn" onclick="ssShowMore(this)"><?php esc_html_e('+ Show More Questions', 'scrollstrike'); ?></button>
                        </div>
                    </div>

                    <div class="ss-faq-category-block">
                        <h2>↩️ <?php esc_html_e('Downgrading to the Free Plan', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How do I manually downgrade my website back to the Free plan tier?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('If you want to stop your PRO plan before its official expiry date, you can switch back using these steps:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('Go to your WordPress sidebar menu and click on ScrollStrike -> Account.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Scroll to the bottom of the Plan Details section.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Click the red Downgrade to Free button.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('The plugin will instantly update your status and return your dashboard workspace back to the free tier limits.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('What happens to my existing PRO highlighters on my live website if I downgrade?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('The moment your site drops to the free tier, the plugin changes how it displays your highlighters:', 'scrollstrike'); ?>
                                    <ul>
                                        <li><strong><?php esc_html_e('PRO highlighters stop working completely:', 'scrollstrike'); ?></strong> <?php esc_html_e('Any highlighter built with premium features (like custom hex colors, rich text formatting, or Focus Mode) will immediately stop displaying to visitors on your live front-end pages.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('Data remains saved:', 'scrollstrike'); ?></strong> <?php esc_html_e('Your premium configuration settings stay safely saved in your database, but they will not render live on the site until a valid PRO key is reactivated.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('Free tier highlighters remain active:', 'scrollstrike'); ?></strong> <?php esc_html_e('Basic highlighters that only use the standard 4 preset colors and plain text will continue to display and function normally for your visitors.', 'scrollstrike'); ?></li>
                                        <li><strong><?php esc_html_e('Library access is capped:', 'scrollstrike'); ?></strong> <?php esc_html_e('In your block editor, only the latest 3 free highlighters you created will appear in the "Attach from Library" list when you want to reuse an existing setup.', 'scrollstrike'); ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q3:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Will my premium Focus Mode settings stop dimming the screen if my plan lapses?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Yes. Because Focus Mode is a premium asset, the entire highlighter associated with it will stop rendering completely on the front end of your website the exact moment your license key expires or you click the downgrade button.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item ss-hidden-faq">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q4:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('If I downgrade my plan on one website, can I immediately use my premium key on a different website?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Yes, because a license key can only be used on one website at a time. You can move your plan to another site using these simple steps:', 'scrollstrike'); ?>
                                    <ol>
                                        <li><?php esc_html_e('Open the dashboard of your first website, go to ScrollStrike -> Account, and click Downgrade to Free.', 'scrollstrike'); ?></li>
                                        <li><?php esc_html_e('Log into the dashboard of your second website, go to the Upgrade to PRO page, paste your license key into the box, and click Activate.', 'scrollstrike'); ?></li>
                                    </ol>
                                </div>
                            </div>
                        </div>

                        <div class="ss-show-more-container">
                            <button class="ss-show-more-btn" onclick="ssShowMore(this)"><?php esc_html_e('+ Show More Questions', 'scrollstrike'); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}