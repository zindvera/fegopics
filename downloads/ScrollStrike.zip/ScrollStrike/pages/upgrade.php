<?php
if (!defined('ABSPATH')) exit;

add_action('wp_ajax_scrollstrike_activate_license_ajax', 'scrollstrike_ajax_activate_license');
function scrollstrike_ajax_activate_license()
{
    check_ajax_referer('ss_upgrade_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'));
    }

    $new_key = isset($_POST['ss_license_key']) ? sanitize_text_field(wp_unslash($_POST['ss_license_key'])) : '';
    update_option('scrollstrike_license_key', $new_key);

    $user_id = get_current_user_id();
    delete_transient('scrollstrike_cached_pro_' . $user_id);
    delete_transient('scrollstrike_buyer_email_' . $user_id);

    wp_send_json_success();
}

function scrollstrike_render_upgrade_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized entry.', 'scrollstrike'));
    }

    $existing_key = get_option('scrollstrike_license_key', '');
    $account_url  = admin_url('admin.php?page=scrollstrike-account');

    $user_id       = get_current_user_id();
    $cached_status = get_transient('scrollstrike_cached_pro_' . $user_id);

    $session_state = ($cached_status !== false) ? ($cached_status ? 'pro' : 'free') : 'pending';
    $loader_class  = ($session_state !== 'pending') ? 'ss-hide' : '';
    $matrix_class  = ($session_state !== 'pending') ? 'ss-opacity-1' : 'ss-opacity-0';
    $packages_vis  = ($session_state === 'free') ? 'ss-show-block ss-opacity-1' : 'ss-hide ss-opacity-0';
?>
    <div class="wrap ss-page-wrapper">
        <div id="ss-upgrade-ajax-notice"></div>

        <div id="ss-top-card" class="ss-top-card-container">
            <div id="ss-localized-loader" class="ss-gatekeeper-loader-wrap <?php echo esc_attr($loader_class); ?>">
                <div class="ss-gatekeeper-spinner"></div>
                <h3 class="ss-loader-heading"><?php esc_html_e('Verifying Subscription Status...', 'scrollstrike'); ?></h3>
            </div>

            <h1 class="ss-page-main-heading"><?php esc_html_e('Upgrade to PRO', 'scrollstrike'); ?></h1>

            <div class="ss-banner-status-box">
                <div id="ss-tier-status-banner" class="ss-status-banner-text">
                    <?php if ($session_state === 'pro'): ?>
                        <span class="ss-text-pro"><?php esc_html_e('You are in PRO Version', 'scrollstrike'); ?></span>
                    <?php elseif ($session_state === 'free'): ?>
                        <span class="ss-text-free"><?php esc_html_e('You are in FREE Version', 'scrollstrike'); ?></span>
                    <?php else: ?>
                        <span class="ss-text-free"><?php esc_html_e('Checking core subscription tier...', 'scrollstrike'); ?></span>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo esc_url($account_url); ?>" class="ss-link-sub-details"><?php esc_html_e('Subscription Details →', 'scrollstrike'); ?></a>
                </div>
            </div>

            <form id="ss-upgrade-form">
                <label class="ss-form-input-label"><?php esc_html_e('License Key', 'scrollstrike'); ?></label>
                <div class="ss-license-input-wrapper">
                    <div class="ss-input-relative-container">
                        <input type="password" id="ss_license_input_field" name="ss_license_key" placeholder="<?php esc_attr_e('Enter your PRO license code here...', 'scrollstrike'); ?>" value="<?php echo esc_attr($existing_key); ?>" class="ss-license-field" required />
                        <span id="ss_toggle_visibility_trigger" class="dashicons dashicons-visibility ss-key-vis-toggle" onclick="ssToggleKeyVisibility()"></span>
                    </div>
                    <button type="submit" id="ss-submit-btn" class="ss-btn ss-btn-activate-main"><?php esc_html_e('Activate', 'scrollstrike'); ?></button>
                </div>
            </form>
        </div>

        <div id="ss-features-matrix-grid" class="ss-features-matrix <?php echo esc_attr($matrix_class); ?>">
            <div class="ss-matrix-card ss-matrix-free">
                <div id="ss-free-current-strip" class="ss-current-plan-ribbon <?php echo esc_attr($session_state === 'free' ? 'ss-show-block' : 'ss-hide'); ?>"><?php esc_html_e('Current Plan', 'scrollstrike'); ?></div>
                <h3 class="ss-matrix-card-title ss-text-muted"><?php esc_html_e('Free Version', 'scrollstrike'); ?></h3>

                <div class="ss-matrix-features-list ss-text-slate">
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('Max 3 unique highlighters', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('Target only 3 elements', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('8 basic color presets only', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('Frequency & Delay Control', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row ss-feature-disabled"><span class="ss-cross-gray">✕</span> <?php esc_html_e('Focus Mode (Background Blur)', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row ss-feature-disabled"><span class="ss-cross-gray">✕</span> <?php esc_html_e('Premium Customer Support', 'scrollstrike'); ?></div>
                </div>
            </div>

            <div class="ss-matrix-card ss-matrix-pro">
                <div id="ss-pro-current-strip" class="ss-current-plan-ribbon <?php echo esc_attr($session_state === 'pro' ? 'ss-show-block' : 'ss-hide'); ?>"><?php esc_html_e('Current Plan', 'scrollstrike'); ?></div>
                <h3 class="ss-matrix-card-title ss-text-orange"><?php esc_html_e('ScrollStrike PRO', 'scrollstrike'); ?></h3>

                <div class="ss-matrix-features-list ss-text-dark">
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <span><span class="ss-bold-orange"><?php esc_html_e('Unlimited', 'scrollstrike'); ?></span> <?php esc_html_e('unique highlighters', 'scrollstrike'); ?></span></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <span><span class="ss-bold-orange"><?php esc_html_e('Unlimited', 'scrollstrike'); ?></span> <?php esc_html_e('target elements', 'scrollstrike'); ?></span></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Pick Any Color', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Frequency & Delay Control', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Focus Mode (Background Blur)', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Premium Customer Support', 'scrollstrike'); ?></div>
                </div>
            </div>
        </div>

        <div id="ss-licensing-packages-section" class="ss-pricing-section <?php echo esc_attr($packages_vis); ?>">
            <h2 class="ss-pricing-heading"><?php esc_html_e('Select Your PRO Plan', 'scrollstrike'); ?></h2>

            <div class="ss-pricing-grid">
                <div class="ss-pricing-card">
                    <div>
                        <div class="ss-pricing-sub"><?php esc_html_e('ScrollStrike', 'scrollstrike'); ?></div>
                        <div class="ss-pricing-title-group">
                            <span class="ss-pricing-term"><?php esc_html_e('1 Month', 'scrollstrike'); ?></span>
                            <span class="ss-pricing-type"><?php esc_html_e('Pro License', 'scrollstrike'); ?></span>
                        </div>
                        <div class="ss-pricing-amount-wrap">
                            <span class="ss-pricing-amount"><?php esc_html_e('$3', 'scrollstrike'); ?></span>
                        </div>
                        <p class="ss-pricing-rate"><?php esc_html_e('$3 per month', 'scrollstrike'); ?></p>
                        <p class="ss-pricing-desc"><?php esc_html_e('Unlock PRO version for 1 month at $3.', 'scrollstrike'); ?></p>
                    </div>
                    <a href="https://fegopics.gumroad.com/l/scrollstrike-1-month-license" target="_blank" class="ss-pricing-btn"><?php esc_html_e('Get License Key', 'scrollstrike'); ?></a>
                </div>

                <div class="ss-pricing-card">
                    <span class="ss-pricing-badge ss-badge-orange"><?php esc_html_e('Save 22%', 'scrollstrike'); ?></span>
                    <div>
                        <div class="ss-pricing-sub"><?php esc_html_e('ScrollStrike', 'scrollstrike'); ?></div>
                        <div class="ss-pricing-title-group">
                            <span class="ss-pricing-term"><?php esc_html_e('6 Months', 'scrollstrike'); ?></span>
                            <span class="ss-pricing-type"><?php esc_html_e('Pro License', 'scrollstrike'); ?></span>
                        </div>
                        <div class="ss-pricing-amount-wrap">
                            <span class="ss-pricing-amount"><?php esc_html_e('$14', 'scrollstrike'); ?></span>
                        </div>
                        <p class="ss-pricing-rate"><?php esc_html_e('~$2.33 per month', 'scrollstrike'); ?></p>
                        <p class="ss-pricing-desc"><?php esc_html_e('Unlock PRO version for 6 months at $14.', 'scrollstrike'); ?></p>
                    </div>
                    <a href="https://fegopics.gumroad.com/l/scrollstrike-6-months-license" target="_blank" class="ss-pricing-btn"><?php esc_html_e('Get License Key', 'scrollstrike'); ?></a>
                </div>

                <div class="ss-pricing-card">
                    <span class="ss-pricing-badge ss-badge-green"><?php esc_html_e('Save 50%', 'scrollstrike'); ?></span>
                    <div>
                        <div class="ss-pricing-sub"><?php esc_html_e('ScrollStrike', 'scrollstrike'); ?></div>
                        <div class="ss-pricing-title-group">
                            <span class="ss-pricing-term"><?php esc_html_e('1 Year', 'scrollstrike'); ?></span>
                            <span class="ss-pricing-type"><?php esc_html_e('Pro License', 'scrollstrike'); ?></span>
                        </div>
                        <div class="ss-pricing-amount-wrap">
                            <span class="ss-pricing-amount"><?php esc_html_e('$18', 'scrollstrike'); ?></span>
                        </div>
                        <p class="ss-pricing-rate"><?php esc_html_e('$1.50 per month', 'scrollstrike'); ?></p>
                        <p class="ss-pricing-desc"><?php esc_html_e('Unlock PRO version for 1 year at $18.', 'scrollstrike'); ?></p>
                    </div>
                    <a href="https://fegopics.gumroad.com/l/scrollstrike-1-year-license" target="_blank" class="ss-pricing-btn"><?php esc_html_e('Get License Key', 'scrollstrike'); ?></a>
                </div>
            </div>
        </div>

        <div id="ss-overwrite-modal" class="ss-modal-overlay ss-hide">
            <div class="ss-modal-card ss-modal-small">
                <div class="ss-warning-circle">!</div>
                <h3 class="ss-modal-header-title"><?php esc_html_e('Overwrite Warning', 'scrollstrike'); ?></h3>
                <p class="ss-modal-description"><?php esc_html_e('Are you sure you want to replace your current license code with the new one?', 'scrollstrike'); ?></p>
                <div class="ss-btn-row ss-btn-center">
                    <button type="button" onclick="ssCloseOverwriteModal()" class="ss-btn ss-btn-secondary"><?php esc_html_e('Cancel', 'scrollstrike'); ?></button>
                    <button type="button" onclick="confirmOverwrite()" class="ss-btn ss-btn-primary ss-bg-orange"><?php esc_html_e('Confirm & Activate', 'scrollstrike'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php
}