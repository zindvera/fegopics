<?php
if (!defined('ABSPATH')) exit;

add_action('wp_ajax_scrollstrike_get_subscription_details', 'scrollstrike_ajax_get_subscription_details');
function scrollstrike_ajax_get_subscription_details() {
    check_ajax_referer('ss_account_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'));
    }

    $user_id = get_current_user_id();
    wp_send_json_success([
        'email'        => get_transient('scrollstrike_buyer_email_' . $user_id) ?: esc_html__('N/A', 'scrollstrike'),
        'expiry_date'  => get_transient('scrollstrike_license_expires_at_' . $user_id) ?: esc_html__('Expired', 'scrollstrike'),
        'product_name' => get_transient('scrollstrike_product_name_' . $user_id) ?: esc_html__('PRO Plan', 'scrollstrike'),
        'start_date'   => get_transient('scrollstrike_license_started_at_' . $user_id) ?: esc_html__('N/A', 'scrollstrike')
    ]);
}

add_action('wp_ajax_scrollstrike_downgrade_to_free_ajax', 'scrollstrike_ajax_downgrade_to_free');
function scrollstrike_ajax_downgrade_to_free() {
    check_ajax_referer('ss_account_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'));
    }

    delete_option('scrollstrike_license_key');
    $user_id = get_current_user_id();
    delete_transient('scrollstrike_cached_pro_' . $user_id);
    delete_transient('scrollstrike_buyer_email_' . $user_id);
    delete_transient('scrollstrike_license_expires_at_' . $user_id);
    delete_transient('scrollstrike_product_name_' . $user_id);
    delete_transient('scrollstrike_license_started_at_' . $user_id);

    wp_send_json_success();
}

function scrollstrike_render_account_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized entry.', 'scrollstrike'));
    }

    $current_user   = wp_get_current_user();
    $display_name   = $current_user->display_name;
    $fallback_email = $current_user->user_email;
    $upgrade_url    = admin_url('admin.php?page=scrollstrike-upgrade');
    ?>
    <div class="wrap ss-account-page-wrap">
        <div id="ss-account-container" class="ss-account-card">
            <div id="ss-account-gatekeeper" class="ss-gatekeeper-loader-wrap">
                <div class="ss-gatekeeper-spinner"></div>
                <h3 class="ss-gatekeeper-title"><?php esc_html_e('Loading Account Data...', 'scrollstrike'); ?></h3>
            </div>

            <h1 class="ss-page-main-heading"><?php esc_html_e('Account Overview', 'scrollstrike'); ?></h1>

            <div id="ss-account-free" class="ss-hide">
                <div class="ss-detail-box ss-bg-slate">
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Administrator', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><?php echo esc_html($display_name); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('System Email', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><?php echo esc_html($fallback_email); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Current Plan', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><span class="ss-pill-free"><?php esc_html_e('Free Status', 'scrollstrike'); ?></span></span>
                    </div>
                </div>

                <div class="ss-text-center">
                    <a href="<?php echo esc_url($upgrade_url); ?>" class="ss-btn ss-btn-upgrade"><?php esc_html_e('⭐ Upgrade to PRO', 'scrollstrike'); ?></a>
                </div>
            </div>

            <div id="ss-account-pro" class="ss-hide">
                <div class="ss-detail-box ss-bg-orange-tint">
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Administrator', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><?php echo esc_html($display_name); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Verified Billing Email', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-pro-email"><div class="ss-spinner-inline"></div></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Current Plan', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><span class="ss-pill-pro"><?php esc_html_e('PRO Version Active', 'scrollstrike'); ?></span></span>
                    </div>
                </div>

                <div class="ss-detail-box ss-bg-white">
                    <h3 class="ss-plan-details-subhead"><?php esc_html_e('Plan Details', 'scrollstrike'); ?></h3>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Plan Package Name', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-pro-name"><div class="ss-spinner-inline"></div></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Plan Start Date', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-sub-start"><div class="ss-spinner-inline"></div></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Expiry Date', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-sub-expiry"><div class="ss-spinner-inline"></div></span>
                    </div>
                </div>

                <div class="ss-text-right">
                    <button type="button" onclick="ssOpenDowngradeModal()" class="ss-btn ss-btn-downgrade"><?php esc_html_e('Downgrade to Free', 'scrollstrike'); ?></button>
                </div>
            </div>
        </div>

        <div id="ss-downgrade-modal" class="ss-modal-overlay ss-hide">
            <div id="ss-downgrade-modal-shell" class="ss-modal-card ss-modal-small">
                <div id="ss-downgrade-interactive-body">
                    <div class="ss-danger-circle">!</div>
                    <h3 class="ss-modal-header-title"><?php esc_html_e('Confirm Plan Downgrade', 'scrollstrike'); ?></h3>
                    <p class="ss-modal-description"><?php esc_html_e('Are you sure you want to downgrade to the Free version?', 'scrollstrike'); ?></p>
                    <div class="ss-btn-row ss-btn-center">
                        <button type="button" onclick="ssCloseDowngradeModal()" class="ss-btn ss-btn-secondary"><?php esc_html_e('Close', 'scrollstrike'); ?></button>
                        <button type="button" id="ss-confirm-downgrade-btn" onclick="ssExecuteDowngrade()" class="ss-btn ss-btn-danger"><?php esc_html_e('Yes, Downgrade to Free', 'scrollstrike'); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}