<?php
/**
 * Fired when the plugin is deleted via the WordPress Admin.
 *
 * @package ScrollStrike
 */

// If uninstall not called from WordPress, exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

function scrollstrike_uninstall_cleanup() {
    global $wpdb;

    // 1. Drop Custom Database Tables
    $table_deployments = $wpdb->prefix . 'scrollstrike_deployments';
    $table_notes       = $wpdb->prefix . 'scrollstrike_notes';

    $wpdb->query("DROP TABLE IF EXISTS `{$table_deployments}`");
    $wpdb->query("DROP TABLE IF EXISTS `{$table_notes}`");

    // 2. Delete Stored Options
    $options_to_delete = [
        'scrollstrike_license_key',
        'scrollstrike_db_version',
        'scrollstrike_last_known_tier',
        'scrollstrike_pending_notice',
        'scrollstrike_saved_notes'
    ];

    foreach ($options_to_delete as $option_name) {
        delete_option($option_name);
    }

    // 3. Delete Transients from DB
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            $wpdb->esc_like('_transient_scrollstrike_') . '%',
            $wpdb->esc_like('_transient_timeout_scrollstrike_') . '%'
        )
    );

    // 4. Strip ScrollStrike Mark Tags from Post Content & Clean Cache
    $posts = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT ID, post_content FROM {$wpdb->posts} WHERE post_content LIKE %s",
            '%' . $wpdb->esc_like('scrollstrike-trigger-word') . '%'
        )
    );

    if (!empty($posts)) {
        foreach ($posts as $p) {
            $clean = preg_replace('/<mark[^>]*class=["\'][^"\']*scrollstrike-trigger-word[^"\']*["\'][^>]*>(.*?)<\/mark>/is', '$1', $p->post_content);
            if ($clean !== $p->post_content) {
                $wpdb->update(
                    $wpdb->posts,
                    ['post_content' => $clean],
                    ['ID' => absint($p->ID)],
                    ['%s'],
                    ['%d']
                );
                clean_post_cache($p->ID);
            }
        }
    }
}

// Execute cleanup across network or single site
if (is_multisite()) {
    $blog_ids = get_sites(['fields' => 'ids']);
    foreach ($blog_ids as $blog_id) {
        switch_to_blog($blog_id);
        scrollstrike_uninstall_cleanup();
        restore_current_blog();
    }
} else {
    scrollstrike_uninstall_cleanup();
}