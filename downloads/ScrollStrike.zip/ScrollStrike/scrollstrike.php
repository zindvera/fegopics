<?php
/*
 * Plugin Name:       ScrollStrike
 * Description:       This is 1.0.1 version. Increase your affiliate link clicks & affiliate revenue by highlighting your affiliate links on the page. Simply create highlighter tooltips on your affiliate links so as visitors scroll, your links get highlighted with context and can't be missed.
 * Version:           1.0.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Fegopics
 * License:           GPL v3 or later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       scrollstrike
 */

if (!defined('ABSPATH')) exit;

define('SCROLLSTRIKE_VERSION', '1.0.1');
define('SCROLLSTRIKE_UPGRADE_URL', admin_url('admin.php?page=scrollstrike-upgrade'));

function scrollstrike_get_pro_state()
{
    $user_id = get_current_user_id();
    $cached  = get_transient('scrollstrike_cached_pro_' . $user_id);

    if (false !== $cached) {
        return $cached ? 'pro' : 'free';
    }

    $key = get_option('scrollstrike_license_key', '');
    return !empty($key) ? 'pending' : 'free';
}

function scrollstrike_is_pro()
{
    return scrollstrike_get_pro_state() === 'pro';
}

// ==========================================
// 2. MODULAR INCLUDES
// ==========================================

$scrollstrike_upgrade_file = plugin_dir_path(__FILE__) . 'pages/upgrade.php';
if (file_exists($scrollstrike_upgrade_file)) {
    require_once $scrollstrike_upgrade_file;
}

$scrollstrike_account_file = plugin_dir_path(__FILE__) . 'pages/account.php';
if (file_exists($scrollstrike_account_file)) {
    require_once $scrollstrike_account_file;
}

$scrollstrike_support_file = plugin_dir_path(__FILE__) . 'pages/support.php';
if (file_exists($scrollstrike_support_file)) {
    require_once $scrollstrike_support_file;
}

// ==========================================
// PRESET COLOR CENTRAL CONFIGURATION
// ==========================================
function scrollstrike_get_preset_colors()
{
    return [
        ['label' => 'Hot Pink',      'value' => '#db2777'],
        ['label' => 'Charcoal',      'value' => '#1e293b'],
        ['label' => 'Royal Blue',    'value' => '#2563eb'],
        ['label' => 'Emerald Green', 'value' => '#16a34a'],
        ['label' => 'Aqua Cyan',     'value' => '#0b819f'],
        ['label' => 'Vivid Orange',  'value' => '#ea580c'],
        ['label' => 'Crimson Red',   'value' => '#dc2626'],
        ['label' => 'Deep Violet',   'value' => '#6e34d3']
    ];
}

function scrollstrike_get_allowed_preset_hexes()
{
    return array_map(function ($color) {
        return strtolower($color['value']);
    }, scrollstrike_get_preset_colors());
}

// ==========================================
// 3. HELPER FUNCTIONS & DB SETUP
// ==========================================
function scrollstrike_generate_unique_id()
{
    return 'scrollstrike_' . number_format(microtime(true) * 1000000, 0, '', '');
}

function scrollstrike_default_bg_color()
{
    return '#fff1f1';
}

function scrollstrike_default_text_color()
{
    return '#333333';
}

function scrollstrike_is_structurally_free($note_text, $bg_color, $focus_mode)
{
    $bg_check = strtolower(trim($bg_color ?? '#fff1f1'));
    $allowed_colors = scrollstrike_get_allowed_preset_hexes();
    $isAllowedColor = in_array($bg_check, $allowed_colors, true);
    $isBlurOff = intval($focus_mode) !== 1;

    return $isAllowedColor && $isBlurOff;
}

function scrollstrike_create_database_tables()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $table_deployments = $wpdb->prefix . 'scrollstrike_deployments';
    $sql1 = "CREATE TABLE $table_deployments (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        tooltip_id varchar(100) NOT NULL,
        page_id bigint(20) NOT NULL,
        timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        KEY tooltip_id (tooltip_id),
        KEY page_id (page_id)
    ) $charset_collate;";
    dbDelta($sql1);

    $table_notes = $wpdb->prefix . 'scrollstrike_notes';
    $sql2 = "CREATE TABLE $table_notes (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        tooltip_id varchar(100) NOT NULL,
        note_text longtext NOT NULL,
        bg_color varchar(20) NOT NULL,
        text_color varchar(20) NOT NULL,
        delay_time float NOT NULL DEFAULT 0,
        focus_mode tinyint(1) NOT NULL DEFAULT 0,
        frequency_type varchar(20) NOT NULL DEFAULT 'always',
        frequency_value int(11) NOT NULL DEFAULT 1,
        is_active tinyint(1) NOT NULL DEFAULT 1,
        tier varchar(20) NOT NULL DEFAULT 'pro',
        timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY tooltip_id (tooltip_id),
        KEY tier (tier)
    ) $charset_collate;";
    dbDelta($sql2);
}
register_activation_hook(__FILE__, 'scrollstrike_create_database_tables');

function scrollstrike_check_db_table()
{
    if (get_option('scrollstrike_db_version') !== '2.0') {
        scrollstrike_create_database_tables();

        global $wpdb;
        $table_notes = $wpdb->prefix . 'scrollstrike_notes';
        $old_notes = get_option('scrollstrike_saved_notes', []);

        if (!empty($old_notes) && is_array($old_notes)) {
            foreach ($old_notes as $note) {
                if (empty($note['id'])) continue;

                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_notes} WHERE tooltip_id = %s", sanitize_text_field($note['id'])));
                if (!$exists) {
                    $note_tier = isset($note['tier']) ? sanitize_text_field($note['tier']) : (scrollstrike_is_structurally_free($note['note_text'] ?? '', $note['bg_color'] ?? '#fff1f1', $note['focus_mode'] ?? 0) ? 'free' : 'pro');

                    $wpdb->insert($table_notes, [
                        'tooltip_id'      => sanitize_text_field($note['id']),
                        'note_text'       => wp_kses_post($note['note_text'] ?? ''),
                        'bg_color'        => sanitize_hex_color($note['bg_color'] ?? '#fff1f1') ?: '#fff1f1',
                        'text_color'      => sanitize_hex_color($note['text_color'] ?? '#333333') ?: '#333333',
                        'delay_time'      => isset($note['delay_time']) ? floatval($note['delay_time']) : 0.0,
                        'focus_mode'      => !empty($note['focus_mode']) ? 1 : 0,
                        'frequency_type'  => sanitize_text_field($note['frequency_type'] ?? 'always'),
                        'frequency_value' => isset($note['frequency_value']) ? absint($note['frequency_value']) : 1,
                        'is_active'       => isset($note['is_active']) ? absint($note['is_active']) : 1,
                        'tier'            => $note_tier,
                        'timestamp'       => current_time('mysql')
                    ]);
                }
            }
        }
        update_option('scrollstrike_db_version', '2.0');
    }
}
add_action('admin_init', 'scrollstrike_check_db_table');

// ==========================================
// 4. ADMIN MENU REGISTRATION
// ==========================================
function scrollstrike_admin_menu()
{
    add_menu_page('ScrollStrike Highlighter Library', 'ScrollStrike', 'manage_options', 'scrollstrike', 'scrollstrike_admin_page', 'dashicons-marker', 80);

    if (function_exists('scrollstrike_render_upgrade_page')) {
        add_submenu_page('scrollstrike', 'Upgrade to PRO', 'Upgrade to PRO', 'manage_options', 'scrollstrike-upgrade', 'scrollstrike_render_upgrade_page');
    }

    if (function_exists('scrollstrike_render_account_page')) {
        add_submenu_page('scrollstrike', 'Account & Plan Details', 'Account', 'manage_options', 'scrollstrike-account', 'scrollstrike_render_account_page');
    }

    if (function_exists('scrollstrike_render_support_page')) {
        add_submenu_page('scrollstrike', 'Help & Support', 'Support', 'manage_options', 'scrollstrike-support', 'scrollstrike_render_support_page');
    }
}
add_action('admin_menu', 'scrollstrike_admin_menu');

// ==========================================
// 5. MAIN ADMIN DASHBOARD ENGINE & ASSETS
// ==========================================

function scrollstrike_enqueue_admin_dashboard_assets($hook)
{
    if (strpos($hook, 'scrollstrike') === false) {
        return;
    }

    wp_enqueue_media();
    wp_enqueue_style('vini-rich-text-css', esc_url(plugins_url('viniRichText/viniRichText.css', __FILE__)), array(), '1.0.0');
    wp_enqueue_script('vini-rich-text-js', esc_url(plugins_url('viniRichText/viniRichText.js', __FILE__)), array(), '1.0.0', true);
    wp_enqueue_style('scrollstrike-admin-style', esc_url(plugins_url('css/style.css', __FILE__)), array(), SCROLLSTRIKE_VERSION);
    wp_enqueue_style('scrollstrike-root-admin-css', esc_url(plugins_url('css/admin.css', __FILE__)), array(), SCROLLSTRIKE_VERSION);

    wp_enqueue_script('scrollstrike-root-admin-js', esc_url(plugins_url('js/admin.js', __FILE__)), array('jquery', 'vini-rich-text-js'), SCROLLSTRIKE_VERSION, true);

    $is_pro       = scrollstrike_is_pro();
    $existing_key = get_option('scrollstrike_license_key', '');
    $user_id      = get_current_user_id();
    $cached       = get_transient('scrollstrike_cached_pro_' . $user_id);
    $session_tier = (false !== $cached) ? ($cached ? 'pro' : 'free') : null;

    wp_localize_script('scrollstrike-root-admin-js', 'ssAdminConfig', [
        'is_pro'            => $is_pro ? 'true' : 'false',
        'session_tier'      => $session_tier ? sanitize_text_field($session_tier) : null,
        'ajax_url'          => esc_url(admin_url('admin-ajax.php')),
        'nonce'             => wp_create_nonce('ss_admin_ajax_nonce'),
        'upgrade_nonce'     => wp_create_nonce('ss_upgrade_action'),
        'verify_nonce'      => wp_create_nonce('scrollstrike_verify_nonce'),
        'account_nonce'     => wp_create_nonce('ss_account_action'),
        'existing_key'      => sanitize_text_field($existing_key),
        'i18n'              => [
            'pro_active'     => esc_html__('You are in PRO Version', 'scrollstrike'),
            'free_active'    => esc_html__('You are in FREE Version', 'scrollstrike'),
            'authenticating' => esc_html__('Authenticating...', 'scrollstrike'),
            'downgrading'    => esc_html__('Processing workspace downgrade, please wait...', 'scrollstrike')
        ]
    ]);
}
add_action('admin_enqueue_scripts', 'scrollstrike_enqueue_admin_dashboard_assets');


function scrollstrike_admin_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized user', 'scrollstrike'));
    }

    global $wpdb;
    $table_notes = $wpdb->prefix . 'scrollstrike_notes';

    $is_pro = scrollstrike_is_pro();
    $upgrade_url = SCROLLSTRIKE_UPGRADE_URL;
    $pro_state = scrollstrike_get_pro_state();

    $current_tier = $is_pro ? 'pro' : 'free';
    $last_tier = get_option('scrollstrike_last_known_tier', 'free');

    if ($current_tier !== $last_tier && $pro_state !== 'pending') {
        update_option('scrollstrike_last_known_tier', $current_tier);
        update_option('scrollstrike_pending_notice', $current_tier === 'pro' ? esc_html__('You have successfully entered into PRO version.', 'scrollstrike') : esc_html__('You now have the free version.', 'scrollstrike'));
    }

    $pending_notice = get_option('scrollstrike_pending_notice', '');

    $free_tooltips_created = absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_notes} WHERE tier = %s", 'free')));
    $display_count = min($free_tooltips_created, 3);
    $badge_state_class = ($free_tooltips_created >= 3) ? 'ss-badge-limit' : 'ss-badge-warning';
    $badge_visibility_class = $is_pro ? 'ss-hide' : 'ss-show-inline';

    $limit_badge = "<span id='ss-dashboard-free-badge' class='ss-badge {$badge_state_class} {$badge_visibility_class}'>Free Tier: " . esc_html($display_count) . "/3 Free Highlighters Used</span>";
?>
    <div id="ss-admin-dashboard">
        <?php if (!empty($pending_notice) && $pro_state !== 'pending'): ?>
            <div id="ss-tier-notice" class="ss-tier-notice-box">
                <span class="ss-tier-notice-text"><?php echo esc_html($pending_notice); ?></span>
                <button onclick="ssDismissTierNotice()" class="ss-close-btn ss-tier-notice-close">&times;</button>
            </div>
            <?php delete_option('scrollstrike_pending_notice'); ?>
        <?php endif; ?>

        <div class="ss-header ss-header-gap">
            <img src="<?php echo esc_url(plugins_url('media/logo/scrollstrike-logo.png', __FILE__)); ?>" alt="ScrollStrike Logo" class="ss-logo">
            <h2 class="ss-main-title">Highlighter Library</h2>
        </div>

        <div class="ss-top-controls ss-align-top">
            <input type="text" id="ss-search" class="ss-search-bar" placeholder="Search your highlighter library...">

            <div class="ss-controls-action-group">
                <?php echo wp_kses_post($limit_badge); ?>
                <button class="ss-btn ss-btn-danger" onclick="ssOpenModal('delete_all', null, 'Delete All')">Delete All Highlighters</button>
            </div>
        </div>

        <div class="ss-grid" id="ss-grid-container">
            <?php for ($i = 0; $i < 4; $i++): ?>
                <div class="ss-card ss-skeleton-card">
                    <div class="ss-skeleton-box ss-skeleton-preview"></div>
                    <div class="ss-skeleton-badges">
                        <div class="ss-skeleton-box ss-skeleton-pill"></div>
                        <div class="ss-skeleton-box ss-skeleton-pill"></div>
                        <div class="ss-skeleton-box ss-skeleton-pill"></div>
                    </div>
                    <div class="ss-skeleton-actions">
                        <div class="ss-skeleton-box ss-skeleton-btn"></div>
                        <div class="ss-skeleton-box ss-skeleton-btn"></div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
        <div id="ss-dashboard-loader" class="ss-dashboard-loader ss-hide">Loading Highlighters...</div>
    </div>

    <div id="ss-admin-modal" class="ss-modal-overlay ss-hide">
        <div id="ss-modal-content-shell" class="ss-modal-card ss-modal-small">
            <div id="ss-modal-interactive-body">
                <h3 id="ss-modal-title" class="ss-modal-header-title">Confirm Action</h3>
                <p id="ss-modal-text" class="ss-modal-description">Are you sure?</p>
                <div class="ss-btn-row ss-btn-center">
                    <button onclick="ssCloseModal()" class="ss-btn ss-btn-secondary">Cancel</button>
                    <button id="ss-modal-confirm-btn" class="ss-btn ss-btn-primary">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <div id="ss-pro-upgrade-modal" class="ss-modal-overlay ss-modal-highest-z ss-hide">
        <div class="ss-modal-card ss-modal-medium ss-relative">
            <button onclick="ssCloseProUpgradeModal()" class="ss-modal-close-corner">✕</button>
            <h3 class="ss-modal-header-danger">Pro Feature Locked</h3>
            <p class="ss-modal-description-spaced">This highlighter contains PRO version features. Upgrade to ScrollStrike PRO to edit it and unlock advanced features.</p>
            <a href="<?php echo esc_url($upgrade_url); ?>" class="ss-btn ss-btn-upgrade">⭐ Upgrade to PRO</a>
        </div>
    </div>

    <div id="ss-studio-modal" class="ss-modal-overlay ss-hide">
        <div class="ss-studio-window">

            <div class="ss-studio-header">
                <h2 class="ss-studio-title">ScrollStrike Studio</h2>
                <button onclick="ssCloseEditModal()" class="ss-close-btn ss-studio-close">✕</button>
            </div>

            <div class="ss-studio-tab-bar">
                <button id="ss-tab-edit" class="ss-studio-tab-btn active" onclick="ssSwitchTab('edit')">✨ Edit Highlighter</button>
                <button id="ss-tab-library" class="ss-studio-tab-btn inactive" onclick="ssSwitchTab('library')">📚 Attach from Library</button>
                <?php if ($is_pro): ?>
                    <span class="ss-badge-pro-pill">👑 PRO VERSION</span>
                <?php else: ?>
                    <a href="<?php echo esc_url($upgrade_url); ?>" class="ss-btn-pro-pill">⭐ Upgrade to Pro</a>
                <?php endif; ?>
            </div>

            <div id="ss-library-container" class="ss-studio-subcontainer ss-hide">
                <div class="ss-library-inner">
                    <div class="ss-library-search-wrapper">
                        <input type="text" id="ss-library-search" oninput="ssFilterLibraryAttach()" placeholder="Search your highlighter library..." class="ss-library-input">
                    </div>
                    <label class="ss-section-label">Select to Import Settings</label>
                    <div id="ss-library-attach-grid" class="ss-attach-grid"></div>
                </div>
            </div>

            <div id="ss-edit-container" class="ss-studio-workspace">
                <input type="hidden" id="edit_id" value="">

                <div class="ss-studio-left-pane">

                    <div class="ss-form-group">
                        <label class="ss-section-label">Highlighter Content</label>
                        <div id="scrollstrike-new-rte-container" class="vini-tooltip-preview-wrapper ss-rte-container"></div>
                    </div>

                    <input type="hidden" id="edit_text_color" value="#333333">

                    <hr class="ss-divider">

                    <div class="ss-form-group">
                        <label class="ss-section-label">Highlighter Colors</label>

                        <div class="ss-preset-container">
                            <?php foreach (scrollstrike_get_preset_colors() as $preset): ?>
                                <button class="ss-preset-btn"
                                    type="button"
                                    title="<?php echo esc_attr($preset['label']); ?>"
                                    onclick="ssSetPresetColor('<?php echo esc_attr($preset['value']); ?>', this)"
                                    data-color="<?php echo esc_attr($preset['value']); ?>"></button>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($is_pro): ?>
                            <div class="ss-color-picker-wrapper">
                                <label class="ss-field-subheading">Or Choose Custom Hex</label>
                                <div class="ss-color-picker-touch-area">
                                    <div id="ss-color-picker-sat-box" onmousedown="ssStartSatDrag(event)" class="ss-sat-box">
                                        <div id="ss-color-picker-pointer" class="ss-picker-pointer"></div>
                                    </div>
                                    <div id="ss-color-picker-hue-box" onmousedown="ssStartHueDrag(event)" class="ss-hue-box">
                                        <div id="ss-color-picker-hue-pointer" class="ss-hue-pointer"></div>
                                    </div>
                                </div>
                                <div class="ss-color-picker-controls">
                                    <div id="ss-color-picker-preview" class="ss-color-preview-box"></div>
                                    <input type="text" id="edit_bg" value="#FFF1F1" readonly class="ss-hex-input">

                                    <div class="ss-rgb-container">
                                        <div class="ss-rgb-column">
                                            <input type="text" id="edit_r_val" value="255" readonly class="ss-rgb-input">
                                            <span class="ss-rgb-label">R</span>
                                        </div>
                                        <div class="ss-rgb-column">
                                            <input type="text" id="edit_g_val" value="241" readonly class="ss-rgb-input">
                                            <span class="ss-rgb-label">G</span>
                                        </div>
                                        <div class="ss-rgb-column">
                                            <input type="text" id="edit_b_val" value="241" readonly class="ss-rgb-input">
                                            <span class="ss-rgb-label">B</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <input type="hidden" id="edit_bg" value="#1e293b">
                        <?php endif; ?>
                    </div>

                    <hr class="ss-divider">

                    <div class="ss-form-group">
                        <label class="ss-section-label">Trigger Delay (Seconds)</label>
                        <input type="number" id="edit_delay" step="0.1" min="0" class="ss-input-field">
                        <span class="ss-input-hint">Use decimals (e.g., 0.5). Set to 0 to trigger instantly.</span>
                    </div>

                    <div class="ss-form-group">
                        <label class="ss-section-label">Display Frequency</label>
                        <select id="edit_freq_type" onchange="ssToggleFreqVal()" class="ss-select-field">
                            <option value="always">Every visit</option>
                            <option value="once">Lifetime once</option>
                            <option value="days">After [ N ] days</option>
                            <option value="visits">After [ N ] visits</option>
                        </select>
                    </div>

                    <div id="edit_freq_val_container" class="ss-form-group ss-hide">
                        <label class="ss-section-label">[ N ] Value</label>
                        <input type="number" id="edit_freq_val" min="1" class="ss-input-field">
                    </div>

                    <?php if ($is_pro): ?>
                        <div class="ss-form-group">
                            <label class="ss-section-label">Focus Mode (Attention-Forcing)</label>
                            <div id="ss-focus-toggle-box" onclick="ssToggleFocus()" class="ss-toggle-card">
                                <div id="ss-focus-toggle-bg" class="ss-toggle-switch">
                                    <div id="ss-focus-toggle-knob" class="ss-toggle-knob"></div>
                                </div>
                                <span class="ss-toggle-text">Activate Background Blur & Focus Mode</span>
                            </div>
                            <input type="hidden" id="edit_focus" value="0">
                        </div>
                    <?php else: ?>
                        <input type="hidden" id="edit_focus" value="0">
                    <?php endif; ?>

                    <div class="ss-form-actions">
                        <button id="edit_save_btn" onclick="ssSaveLibraryEdit()" class="ss-btn ss-btn-primary ss-btn-full">Save Settings</button>
                    </div>

                </div>

                <div class="ss-studio-right-pane">
                    <h4 class="ss-preview-heading">Live Interface Preview</h4>

                    <div id="ss-live-preview-box" class="vini-tooltip-preview-wrapper ss-live-preview-box">
                        <div id="ss-live-preview-content" class="vini-tooltip-preview-content">Type your message on the left to see the magic happen...</div>
                        <div id="ss-live-preview-arrow" class="scrollstrike-arrow"></div>
                        <span id="ss-live-preview-close" class="ss-live-preview-close-btn">✕</span>
                    </div>

                </div>

            </div>

        </div>
    </div>

    <div id="ss-linked-pages-modal" class="ss-modal-overlay ss-hide">
        <div class="ss-modal-card ss-modal-linked-pages">
            <div class="ss-linked-pages-header">
                <h3 class="ss-linked-pages-title">Deployed Pages Timeline</h3>
                <button onclick="ssCloseLinkedPages()" class="ss-close-btn ss-linked-pages-close">✕</button>
            </div>

            <div id="ss-linked-pages-content" class="ss-linked-pages-body"></div>

            <div id="ss-linked-pages-loader" class="ss-linked-pages-spinner-wrapper ss-hide">
                <div class="ss-spinner"></div>
                <div class="ss-spinner-text">Loading list of pages...</div>
            </div>
        </div>
    </div>
<?php
}

// ==========================================
// 6. ASSET PIPELINE & FILTERING
// ==========================================
function scrollstrike_enqueue_frontend_scripts()
{
    global $post, $wpdb;
    if (!$post || empty($post->post_content)) return;

    $table_notes = $wpdb->prefix . 'scrollstrike_notes';
    $content = $post->post_content;

    preg_match_all('/data-id=["\'](scrollstrike_[a-zA-Z0-9_]+)["\']/i', $content, $matches);
    $unique_ids = !empty($matches[1]) ? array_values(array_unique(array_map('sanitize_text_field', $matches[1]))) : [];

    $active_strikes = [];
    if (!empty($unique_ids)) {
        $is_pro = scrollstrike_is_pro();
        $tier_condition = !$is_pro ? " AND tier = 'free'" : "";

        $placeholders = implode(',', array_fill(0, count($unique_ids), '%s'));
        $sql          = "SELECT * FROM {$table_notes} WHERE is_active = 1{$tier_condition} AND tooltip_id IN ($placeholders)";
        $db_notes     = $wpdb->get_results(
            $wpdb->prepare($sql, $unique_ids),
            ARRAY_A
        );

        if (!empty($db_notes)) {
            foreach ($db_notes as $row) {
                $active_strikes[] = [
                    'id'              => sanitize_text_field($row['tooltip_id']),
                    'note_text'       => wp_kses_post($row['note_text']),
                    'bg_color'        => sanitize_hex_color($row['bg_color']) ?: '#fff1f1',
                    'text_color'      => sanitize_hex_color($row['text_color']) ?: '#333333',
                    'delay_time'      => floatval($row['delay_time']),
                    'focus_mode'      => absint($row['focus_mode']),
                    'frequency_type'  => sanitize_text_field($row['frequency_type']),
                    'frequency_value' => absint($row['frequency_value']),
                    'tier'            => sanitize_text_field($row['tier'])
                ];
            }
        }
    }

    wp_enqueue_style('vini-rich-text-css', esc_url(plugins_url('viniRichText/viniRichText.css', __FILE__)), array(), '1.0.0');
    wp_enqueue_style('scrollstrike-frontend-style', esc_url(plugins_url('css/style.css', __FILE__)), [], SCROLLSTRIKE_VERSION);
    wp_enqueue_script('scrollstrike-frontend-engine', esc_url(plugins_url('js/scrollstrike-frontend.js', __FILE__)), ['jquery'], SCROLLSTRIKE_VERSION, true);

    wp_localize_script('scrollstrike-frontend-engine', 'scrollstrike_data', [
        'notes'  => $active_strikes,
        'is_pro' => scrollstrike_is_pro()
    ]);
}
add_action('wp_enqueue_scripts', 'scrollstrike_enqueue_frontend_scripts');


function scrollstrike_enqueue_gutenberg_editor_assets()
{
    global $wpdb;
    $table = $wpdb->prefix . 'scrollstrike_notes';

    wp_enqueue_media();
    wp_enqueue_style('vini-rich-text-css', esc_url(plugins_url('viniRichText/viniRichText.css', __FILE__)), array(), '1.0.0');
    wp_enqueue_script('vini-rich-text-js', esc_url(plugins_url('viniRichText/viniRichText.js', __FILE__)), array(), '1.0.0', true);

    $notes = $wpdb->get_results("SELECT tooltip_id as id, note_text, bg_color, text_color, delay_time, focus_mode, frequency_type, frequency_value, is_active, tier FROM {$table} ORDER BY timestamp DESC", ARRAY_A);

    wp_enqueue_script('scrollstrike-format-btn', esc_url(plugins_url('js/scrollstrike-gutenberg.js', __FILE__)), array('wp-rich-text', 'wp-element', 'wp-components', 'wp-editor', 'wp-data', 'vini-rich-text-js'), SCROLLSTRIKE_VERSION, true);
    wp_localize_script('scrollstrike-format-btn', 'scrollstrike_editor_data', [
        'notes'         => $notes,
        'is_pro'        => scrollstrike_is_pro(),
        'upgrade_url'   => SCROLLSTRIKE_UPGRADE_URL,
        'ajax_url'      => esc_url(admin_url('admin-ajax.php')),
        'nonce'         => wp_create_nonce('scrollstrike_save_note_nonce'),
        'preset_colors' => scrollstrike_get_preset_colors(),
        'plugin_url'    => esc_url(plugin_dir_url(__FILE__))
    ]);
    
    // Enqueue admin.css inside Gutenberg editor
    wp_enqueue_style('scrollstrike-root-admin-css', esc_url(plugins_url('css/admin.css', __FILE__)), array(), SCROLLSTRIKE_VERSION);
}
add_action('enqueue_block_editor_assets', 'scrollstrike_enqueue_gutenberg_editor_assets');


// =========================================================================================
// 7. UNIVERSAL GATEKEEPER ASYNCHRONOUS OVERLAY & VERIFICATION ENGINE (HYBRID LIFECYCLE)
// =========================================================================================

function scrollstrike_ajax_unified_gatekeeper_check()
{
    check_ajax_referer('scrollstrike_verify_nonce', 'nonce');
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    $user_id = get_current_user_id();

    $cached = get_transient('scrollstrike_cached_pro_' . $user_id);
    if (false !== $cached) {
        $tier = $cached ? 'pro' : 'free';
        wp_send_json_success(['tier' => $tier]);
    }

    $saved_key = sanitize_text_field(trim(get_option('scrollstrike_license_key', '')));

    if (empty($saved_key) || strlen($saved_key) < 5) {
        set_transient('scrollstrike_cached_pro_' . $user_id, false, DAY_IN_SECONDS);
        delete_transient('scrollstrike_license_expires_at_' . $user_id);
        wp_send_json_success(['tier' => 'free']);
        return;
    }

    $products_to_verify = [
        '365 Days Plan' => 'w8-WqlCRGK8DR9Y3d-RTAw==',
        '180 Days Plan' => 'y_ZF8XO0iv6cP_YfN9oWAw==',
        '30 Days Plan'  => 'ddOHIks2F59K9htAdUP8Bw=='
    ];

    $is_valid = false;
    $purchase = null;

    foreach ($products_to_verify as $plan_name => $id_hash) {
        if (strpos($id_hash, 'INSERT_YOUR_') === 0) continue;

        $response = wp_remote_post('https://api.gumroad.com/v2/licenses/verify', [
            'timeout'   => 5,
            'sslverify' => true,
            'body'      => [
                'product_id'  => sanitize_text_field($id_hash),
                'license_key' => $saved_key
            ]
        ]);

        if (!is_wp_error($response)) {
            $code = wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);

            if ($code === 200 && isset($body['success']) && $body['success'] === true) {
                $is_valid = true;
                $purchase = $body['purchase'];
                break;
            }
        }
    }

    if ($is_valid && $purchase) {
        $permalink  = isset($purchase['permalink']) ? sanitize_text_field(trim($purchase['permalink'])) : '';
        $created_at = isset($purchase['created_at']) ? sanitize_text_field(trim($purchase['created_at'])) : '';

        $allowed_days = 0;
        if (strpos($permalink, '1-month') !== false) {
            $allowed_days = 30;
        } elseif (strpos($permalink, '6-months') !== false) {
            $allowed_days = 180;
        } elseif (strpos($permalink, '1-year') !== false) {
            $allowed_days = 365;
        }

        if ($allowed_days > 0 && !empty($created_at)) {
            $purchase_time = strtotime($created_at);
            $expiry_time   = $purchase_time + ($allowed_days * DAY_IN_SECONDS);
            $now           = current_time('timestamp');

            if ($now <= $expiry_time) {
                set_transient('scrollstrike_cached_pro_' . $user_id, true, DAY_IN_SECONDS);
                set_transient('scrollstrike_buyer_email_' . $user_id, sanitize_email($purchase['email'] ?? ''), DAY_IN_SECONDS);
                set_transient('scrollstrike_license_expires_at_' . $user_id, wp_date(get_option('date_format'), $expiry_time), DAY_IN_SECONDS);
                set_transient('scrollstrike_product_name_' . $user_id, sanitize_text_field($purchase['product_name'] ?? 'PRO Plan'), DAY_IN_SECONDS);
                set_transient('scrollstrike_license_started_at_' . $user_id, wp_date(get_option('date_format'), $purchase_time), DAY_IN_SECONDS);

                wp_send_json_success(['tier' => 'pro']);
                return;
            }
        }

        set_transient('scrollstrike_cached_pro_' . $user_id, false, DAY_IN_SECONDS);
        delete_transient('scrollstrike_buyer_email_' . $user_id);
        set_transient('scrollstrike_license_expires_at_' . $user_id, 'Expired', DAY_IN_SECONDS);
        wp_send_json_success(['tier' => 'free']);
    } else {
        set_transient('scrollstrike_cached_pro_' . $user_id, false, DAY_IN_SECONDS);
        delete_transient('scrollstrike_buyer_email_' . $user_id);
        delete_transient('scrollstrike_license_expires_at_' . $user_id);
        wp_send_json_success(['tier' => 'free']);
    }
}
add_action('wp_ajax_scrollstrike_unified_gatekeeper_check', 'scrollstrike_ajax_unified_gatekeeper_check');


// ==========================================
// 8. ASYNCHRONOUS AJAX SQL ROUTES
// ==========================================

function scrollstrike_ajax_get_paginated_notes()
{
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';

    if (!wp_verify_nonce($nonce, 'ss_admin_ajax_nonce') && !wp_verify_nonce($nonce, 'scrollstrike_save_note_nonce')) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    $is_pro = scrollstrike_is_pro();
    $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;
    $limit = 10;
    $search = isset($_POST['search']) ? sanitize_text_field(wp_unslash($_POST['search'])) : '';

    global $wpdb;
    $table = $wpdb->prefix . 'scrollstrike_notes';

    $search_where = "1=1";
    $search_args = [];
    if (!empty($search)) {
        $words = preg_split('/\s+/', trim($search));
        if (!empty($words)) {
            $clauses = [];
            foreach ($words as $word) {
                $clauses[] = "note_text LIKE %s";
                $search_args[] = '%' . $wpdb->esc_like($word) . '%';
            }
            $search_where = implode(' AND ', $clauses);
        }
    }

    if (!$is_pro) {
        $sql_top_free = "SELECT tooltip_id as id, note_text, bg_color, text_color, delay_time, focus_mode, frequency_type, frequency_value, is_active, tier FROM {$table} WHERE tier = 'free' AND {$search_where} ORDER BY timestamp DESC LIMIT 3";
        $top_free     = $wpdb->get_results(
            !empty($search_args) ? $wpdb->prepare($sql_top_free, $search_args) : $sql_top_free,
            ARRAY_A
        );

        $top_free_ids = !empty($top_free) ? array_map('sanitize_text_field', array_column($top_free, 'id')) : [];

        $exclude_where = "1=1";
        $exclude_args  = [];
        if (!empty($top_free_ids)) {
            $placeholders  = implode(',', array_fill(0, count($top_free_ids), '%s'));
            $exclude_where = "tooltip_id NOT IN ($placeholders)";
            $exclude_args  = $top_free_ids;
        }

        $sql_other   = "SELECT tooltip_id as id, note_text, bg_color, text_color, delay_time, focus_mode, frequency_type, frequency_value, is_active, tier FROM {$table} WHERE {$search_where} AND {$exclude_where} ORDER BY timestamp DESC LIMIT %d OFFSET %d";
        $all_params  = array_merge($search_args, $exclude_args, [$limit, $offset]);
        $other_items = $wpdb->get_results(
            $wpdb->prepare($sql_other, $all_params),
            ARRAY_A
        );

        $results = ($offset === 0) ? array_merge($top_free, $other_items) : $other_items;

        $sql_count    = "SELECT COUNT(*) FROM {$table} WHERE {$search_where} AND {$exclude_where}";
        $count_params = array_merge($search_args, $exclude_args);
        $total_other  = $wpdb->get_var(
            !empty($count_params) ? $wpdb->prepare($sql_count, $count_params) : $sql_count
        );
        $has_more = ($offset + $limit) < intval($total_other);
    } else {
        $sql_pro    = "SELECT tooltip_id as id, note_text, bg_color, text_color, delay_time, focus_mode, frequency_type, frequency_value, is_active, tier FROM {$table} WHERE {$search_where} ORDER BY timestamp DESC LIMIT %d OFFSET %d";
        $pro_params = array_merge($search_args, [$limit, $offset]);
        $results    = $wpdb->get_results(
            $wpdb->prepare($sql_pro, $pro_params),
            ARRAY_A
        );

        $sql_count_pro = "SELECT COUNT(*) FROM {$table} WHERE {$search_where}";
        $total         = $wpdb->get_var(
            !empty($search_args) ? $wpdb->prepare($sql_count_pro, $search_args) : $sql_count_pro
        );
        $has_more = ($offset + $limit) < intval($total);
    }

    wp_send_json_success(['notes' => $results, 'has_more' => $has_more]);
}
add_action('wp_ajax_scrollstrike_get_paginated_notes', 'scrollstrike_ajax_get_paginated_notes');

function scrollstrike_ajax_admin_save_edit()
{
    if (!check_ajax_referer('ss_admin_ajax_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    $is_pro = scrollstrike_is_pro();
    $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
    $raw_note_text = isset($_POST['note_text']) ? wp_unslash($_POST['note_text']) : '';

    $allowed_html = array(
        'p'      => array('style' => array(), 'class' => array()),
        'span'   => array('style' => array(), 'class' => array()),
        'b'      => array(),
        'strong' => array(),
        'i'      => array(),
        'em'     => array(),
        'u'      => array(),
        'br'     => array(),
        'font'   => array('size' => array(), 'color' => array(), 'style' => array()),
        'div'    => array('class' => array(), 'style' => array()),
        'a'      => array('href' => array(), 'title' => array(), 'target' => array(), 'id' => array(), 'class' => array(), 'style' => array(), 'contenteditable' => array(), 'data-scale' => array()),
        'img'    => array('src' => array(), 'alt' => array(), 'title' => array(), 'style' => array(), 'class' => array(), 'width' => array(), 'height' => array())
    );

    $clean_note_text = wp_kses($raw_note_text, $allowed_html);
    $trimmed_text = trim($clean_note_text);
    if (!preg_match('/^<(p|div|h[1-6]|ul|ol|blockquote)[\s\S]*>/i', $trimmed_text)) {
        $clean_note_text = '<p>' . $trimmed_text . '</p>';
    }

    $raw_bg = isset($_POST['bg_color']) ? sanitize_hex_color(wp_unslash($_POST['bg_color'])) : scrollstrike_default_bg_color();
    $raw_focus = (isset($_POST['focus_mode']) && wp_unslash($_POST['focus_mode']) === 'true') ? 1 : 0;

    if (!$is_pro) {
        $allowed_presets = scrollstrike_get_allowed_preset_hexes();
        if (!in_array(strtolower($raw_bg), $allowed_presets, true)) {
            $raw_bg = scrollstrike_default_bg_color();
        }
        $raw_focus = 0;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'scrollstrike_notes';

    $current_tier = $wpdb->get_var($wpdb->prepare("SELECT tier FROM {$table} WHERE tooltip_id = %s", $id));
    if (!$current_tier) {
        wp_send_json_error(esc_html__('Highlighter not found.', 'scrollstrike'), 404);
    }

    $new_tier = scrollstrike_is_structurally_free($clean_note_text, $raw_bg, $raw_focus) ? 'free' : 'pro';

    $wpdb->update($table, [
        'note_text'       => $clean_note_text,
        'bg_color'        => $raw_bg,
        'text_color'      => isset($_POST['text_color']) ? sanitize_hex_color(wp_unslash($_POST['text_color'])) : scrollstrike_default_text_color(),
        'delay_time'      => isset($_POST['delay_time']) ? floatval(wp_unslash($_POST['delay_time'])) : 0.0,
        'focus_mode'      => $raw_focus,
        'frequency_type'  => isset($_POST['frequency_type']) ? sanitize_text_field(wp_unslash($_POST['frequency_type'])) : 'always',
        'frequency_value' => isset($_POST['frequency_value']) ? absint(wp_unslash($_POST['frequency_value'])) : 1,
        'tier'            => $new_tier
    ], ['tooltip_id' => $id]);

    wp_send_json_success(['tier' => $new_tier]);
}
add_action('wp_ajax_scrollstrike_admin_save_edit', 'scrollstrike_ajax_admin_save_edit');

function scrollstrike_ajax_get_linked_pages()
{
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'ss_admin_ajax_nonce') && !wp_verify_nonce($nonce, 'scrollstrike_save_note_nonce')) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'scrollstrike_deployments';
    $tooltip_id = isset($_POST['tooltip_id']) ? sanitize_text_field(wp_unslash($_POST['tooltip_id'])) : '';
    $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;
    $limit = 15;

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT d.page_id, d.timestamp 
         FROM {$table_name} d 
         INNER JOIN {$wpdb->posts} p ON d.page_id = p.ID 
         WHERE d.tooltip_id = %s AND p.post_status IN ('publish', 'draft', 'private', 'pending')
         ORDER BY d.timestamp DESC LIMIT %d OFFSET %d",
        $tooltip_id,
        $limit,
        $offset
    ));

    $pages = [];
    if (!empty($results)) {
        foreach ($results as $row) {
            $pages[] = [
                'title' => get_the_title($row->page_id) ?: 'Untitled Page (ID: ' . absint($row->page_id) . ')',
                'url'   => esc_url(get_permalink($row->page_id)),
                'date'  => wp_date(get_option('date_format') . ' \a\t ' . get_option('time_format'), strtotime($row->timestamp))
            ];
        }
    }

    $total = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(d.id) FROM {$table_name} d 
         INNER JOIN {$wpdb->posts} p ON d.page_id = p.ID 
         WHERE d.tooltip_id = %s AND p.post_status IN ('publish', 'draft', 'private', 'pending')",
        $tooltip_id
    ));

    wp_send_json_success(['pages' => $pages, 'has_more' => ($offset + $limit) < intval($total)]);
}
add_action('wp_ajax_scrollstrike_get_linked_pages', 'scrollstrike_ajax_get_linked_pages');

function scrollstrike_ajax_sync_deployment()
{
    if (!check_ajax_referer('scrollstrike_save_note_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
    $tooltip_id = isset($_POST['tooltip_id']) ? sanitize_text_field(wp_unslash($_POST['tooltip_id'])) : '';
    $action_type = isset($_POST['action_type']) ? sanitize_text_field(wp_unslash($_POST['action_type'])) : '';

    if (!$post_id || empty($tooltip_id)) {
        wp_send_json_error('Missing data', 400);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'scrollstrike_deployments';

    if ($action_type === 'deploy') {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table_name} WHERE tooltip_id = %s AND page_id = %d", $tooltip_id, $post_id));
        if ($exists) {
            $wpdb->query($wpdb->prepare("UPDATE {$table_name} SET timestamp = CURRENT_TIMESTAMP WHERE id = %d", $exists));
        } else {
            $wpdb->insert($table_name, ['tooltip_id' => $tooltip_id, 'page_id' => $post_id], ['%s', '%d']);
        }
    } elseif ($action_type === 'remove') {
        $post = get_post($post_id);
        $has_other_instances = false;

        if ($post && !empty($post->post_content)) {
            $has_other_instances = (substr_count($post->post_content, 'data-id="' . $tooltip_id . '"') > 1) ||
                (substr_count($post->post_content, "data-id='" . $tooltip_id . "'") > 1);
        }

        if (!$has_other_instances) {
            $wpdb->delete($table_name, ['tooltip_id' => $tooltip_id, 'page_id' => $post_id], ['%s', '%d']);
        }
    }
    wp_send_json_success();
}
add_action('wp_ajax_scrollstrike_sync_deployment', 'scrollstrike_ajax_sync_deployment');

function scrollstrike_sync_post_deployments_on_save($post_id, $post, $update)
{
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_autosave($post) || wp_is_post_revision($post) || $post->post_status === 'auto-draft') return;
    if (!current_user_can('edit_post', $post_id)) return;

    global $wpdb;
    $table_deployments = $wpdb->prefix . 'scrollstrike_deployments';

    preg_match_all('/data-id=["\'](scrollstrike_[a-zA-Z0-9_]+)["\']/i', $post->post_content, $matches);
    $active_tooltip_ids = !empty($matches[1]) ? array_values(array_unique(array_map('sanitize_text_field', $matches[1]))) : [];

    if (!empty($active_tooltip_ids)) {
        $placeholders = implode(',', array_fill(0, count($active_tooltip_ids), '%s'));
        $delete_sql   = "DELETE FROM {$table_deployments} WHERE page_id = %d AND tooltip_id NOT IN ($placeholders)";
        $params       = array_merge([$post_id], $active_tooltip_ids);
        $wpdb->query($wpdb->prepare($delete_sql, $params));

        foreach ($active_tooltip_ids as $tooltip_id) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table_deployments} WHERE tooltip_id = %s AND page_id = %d",
                $tooltip_id,
                $post_id
            ));
            if (!$exists) {
                $wpdb->insert($table_deployments, ['tooltip_id' => $tooltip_id, 'page_id' => $post_id], ['%s', '%d']);
            }
        }
    } else {
        $wpdb->delete($table_deployments, ['page_id' => $post_id], ['%d']);
    }
}
add_action('save_post', 'scrollstrike_sync_post_deployments_on_save', 10, 3);

function scrollstrike_ajax_save_note()
{
    if (!check_ajax_referer('scrollstrike_save_note_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    $is_pro = scrollstrike_is_pro();
    $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
    $editor_count = isset($_POST['editor_count']) ? absint($_POST['editor_count']) : 0;
    $is_reusing = isset($_POST['is_reusing']) && wp_unslash($_POST['is_reusing']) === 'true';
    $has_existing_id = isset($_POST['has_existing_id']) && wp_unslash($_POST['has_existing_id']) === 'true';

    if ($is_pro && $is_reusing) {
        wp_send_json_success(['action' => 'approved_reuse', 'free_tooltips_created' => 0, 'site_elements_deployed' => 0]);
    }

    global $wpdb;
    $table_notes = $wpdb->prefix . 'scrollstrike_notes';

    $free_tooltips_created = 0;
    $total_site_elements = 0;

    if (!$is_pro) {
        $free_tooltips_created = absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_notes} WHERE tier = %s", 'free')));
        $active_free_ids = $wpdb->get_col($wpdb->prepare("SELECT tooltip_id FROM {$table_notes} WHERE tier = %s AND is_active = 1 LIMIT 3", 'free'));

        $db_count = 0;
        if (!empty($active_free_ids)) {
            $exclude_sql = $post_id ? $wpdb->prepare("AND ID != %d", $post_id) : "";
            $results = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT post_content FROM {$wpdb->posts} WHERE post_status IN ('publish', 'draft', 'future', 'pending', 'private') AND post_type NOT IN ('revision', 'nav_menu_item', 'attachment') AND post_content LIKE %s {$exclude_sql}",
                    '%' . $wpdb->esc_like('scrollstrike-trigger-word') . '%'
                )
            );
            if (!empty($results)) {
                foreach ($results as $row) {
                    foreach ($active_free_ids as $allowed_id) {
                        $db_count += substr_count($row->post_content, 'data-id="' . esc_attr($allowed_id) . '"');
                    }
                }
            }
        }

        $total_site_elements = $db_count + $editor_count;

        if ($is_reusing) {
            if ($total_site_elements > 3) {
                wp_send_json_error(['code' => 'limit_elements', 'message' => 'Element limit reached.'], 400);
            }
            wp_send_json_success(['action' => 'approved_reuse', 'free_tooltips_created' => $free_tooltips_created, 'site_elements_deployed' => $total_site_elements]);
        } else {
            if ($free_tooltips_created >= 3) {
                wp_send_json_error(['code' => 'limit_tooltips', 'message' => 'Library limit reached.'], 400);
            }

            if (!$has_existing_id && $total_site_elements > 3) {
                wp_send_json_error(['code' => 'limit_elements', 'message' => 'Element limit reached.'], 400);
            }
        }
    }

    $raw_bg = isset($_POST['bg_color']) ? sanitize_hex_color(wp_unslash($_POST['bg_color'])) : scrollstrike_default_bg_color();
    $raw_focus = (isset($_POST['focus_mode']) && wp_unslash($_POST['focus_mode']) === 'true') ? 1 : 0;

    if (!$is_pro) {
        $allowed_presets = scrollstrike_get_allowed_preset_hexes();
        if (!in_array(strtolower($raw_bg), $allowed_presets, true)) {
            $raw_bg = scrollstrike_default_bg_color();
        }
        $raw_focus = 0;
    }

    $id = scrollstrike_generate_unique_id();
    $raw_note_text = isset($_POST['note_text']) ? wp_unslash($_POST['note_text']) : '';

    $allowed_html = array(
        'p'      => array('style' => array(), 'class' => array()),
        'span'   => array('style' => array(), 'class' => array()),
        'b'      => array(),
        'strong' => array(),
        'i'      => array(),
        'em'     => array(),
        'u'      => array(),
        'br'     => array(),
        'font'   => array('size' => array(), 'color' => array(), 'style' => array()),
        'div'    => array('class' => array(), 'style' => array()),
        'a'      => array('href' => array(), 'title' => array(), 'target' => array(), 'id' => array(), 'class' => array(), 'style' => array(), 'contenteditable' => array(), 'data-scale' => array()),
        'img'    => array('src' => array(), 'alt' => array(), 'title' => array(), 'style' => array(), 'class' => array(), 'width' => array(), 'height' => array())
    );

    $note_text  = wp_kses($raw_note_text, $allowed_html);
    $text_color = isset($_POST['text_color']) ? sanitize_hex_color(wp_unslash($_POST['text_color'])) : scrollstrike_default_text_color();
    $delay      = isset($_POST['delay_time']) ? floatval(wp_unslash($_POST['delay_time'])) : 0.0;
    $freqType   = isset($_POST['frequency_type']) ? sanitize_text_field(wp_unslash($_POST['frequency_type'])) : 'always';
    $freqVal    = isset($_POST['frequency_value']) ? absint(wp_unslash($_POST['frequency_value'])) : 1;
    $tier       = scrollstrike_is_structurally_free($note_text, $raw_bg, $raw_focus) ? 'free' : 'pro';

    $wpdb->insert($table_notes, [
        'tooltip_id'      => $id,
        'note_text'       => $note_text,
        'bg_color'        => $raw_bg,
        'text_color'      => $text_color,
        'delay_time'      => $delay,
        'focus_mode'      => $raw_focus,
        'frequency_type'  => $freqType,
        'frequency_value' => $freqVal,
        'is_active'       => 1,
        'tier'            => $tier,
        'timestamp'       => current_time('mysql')
    ]);

    if (!$is_pro) $free_tooltips_created++;

    $new_note = [
        'id'              => $id,
        'note_text'       => $note_text,
        'bg_color'        => $raw_bg,
        'text_color'      => $text_color,
        'delay_time'      => $delay,
        'focus_mode'      => $raw_focus,
        'frequency_type'  => $freqType,
        'frequency_value' => $freqVal,
        'is_active'       => 1,
        'tier'            => $tier
    ];

    wp_send_json_success(['note' => $new_note, 'free_tooltips_created' => $free_tooltips_created, 'site_elements_deployed' => $total_site_elements]);
}
add_action('wp_ajax_scrollstrike_save_note', 'scrollstrike_ajax_save_note');

function scrollstrike_ajax_get_counts()
{
    if (!check_ajax_referer('scrollstrike_save_note_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }

    $is_pro = scrollstrike_is_pro();
    if ($is_pro) {
        wp_send_json_success(['free_tooltips_created' => 0, 'site_elements_deployed' => 0]);
    }

    global $wpdb;
    $table_notes = $wpdb->prefix . 'scrollstrike_notes';

    $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
    $editor_count = isset($_POST['editor_count']) ? absint($_POST['editor_count']) : 0;

    $free_tooltips_created = absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_notes} WHERE tier = %s", 'free')));
    $active_free_ids = $wpdb->get_col($wpdb->prepare("SELECT tooltip_id FROM {$table_notes} WHERE tier = %s AND is_active = 1 LIMIT 3", 'free'));

    $db_count = 0;
    if (!empty($active_free_ids)) {
        $exclude_sql = $post_id ? $wpdb->prepare("AND ID != %d", $post_id) : "";
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_content FROM {$wpdb->posts} WHERE post_status IN ('publish', 'draft', 'future', 'pending', 'private') AND post_type NOT IN ('revision', 'nav_menu_item', 'attachment') AND post_content LIKE %s {$exclude_sql}",
                '%' . $wpdb->esc_like('scrollstrike-trigger-word') . '%'
            )
        );
        if (!empty($results)) {
            foreach ($results as $row) {
                foreach ($active_free_ids as $allowed_id) {
                    $db_count += substr_count($row->post_content, 'data-id="' . esc_attr($allowed_id) . '"');
                }
            }
        }
    }

    wp_send_json_success(['free_tooltips_created' => $free_tooltips_created, 'site_elements_deployed' => $db_count + $editor_count]);
}
add_action('wp_ajax_scrollstrike_get_counts', 'scrollstrike_ajax_get_counts');

function scrollstrike_ajax_admin_toggle()
{
    if (!check_ajax_referer('ss_admin_ajax_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    global $wpdb;
    $table_notes = $wpdb->prefix . 'scrollstrike_notes';
    $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';

    $current = $wpdb->get_var($wpdb->prepare("SELECT is_active FROM {$table_notes} WHERE tooltip_id = %s", $id));
    $wpdb->update($table_notes, ['is_active' => $current ? 0 : 1], ['tooltip_id' => $id]);

    wp_send_json_success();
}
add_action('wp_ajax_scrollstrike_admin_toggle', 'scrollstrike_ajax_admin_toggle');

function scrollstrike_ajax_admin_delete()
{
    if (!check_ajax_referer('ss_admin_ajax_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }

    global $wpdb;
    $table_notes = $wpdb->prefix . 'scrollstrike_notes';
    $table_deployments = $wpdb->prefix . 'scrollstrike_deployments';
    $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';

    $wpdb->delete($table_notes, ['tooltip_id' => $id], ['%s']);
    $wpdb->delete($table_deployments, ['tooltip_id' => $id], ['%s']);

    $posts = $wpdb->get_results($wpdb->prepare("SELECT ID, post_content FROM {$wpdb->posts} WHERE post_content LIKE %s", '%' . $wpdb->esc_like($id) . '%'));
    if (!empty($posts)) {
        foreach ($posts as $p) {
            $regex = '/<mark[^>]*data-id=["\']' . preg_quote($id, '/') . '["\'][^>]*>(.*?)<\/mark>/is';
            $clean = preg_replace($regex, '$1', $p->post_content);
            if ($clean !== $p->post_content) {
                wp_update_post([
                    'ID'           => absint($p->ID),
                    'post_content' => $clean,
                ]);
            }
        }
    }

    $free_count = absint($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table_notes} WHERE tier = %s", 'free')));

    wp_send_json_success([
        'free_count' => $free_count
    ]);
}
add_action('wp_ajax_scrollstrike_admin_delete', 'scrollstrike_ajax_admin_delete');

function scrollstrike_ajax_admin_delete_all()
{
    if (!check_ajax_referer('ss_admin_ajax_nonce', 'nonce', false)) {
        wp_send_json_error(esc_html__('Security check failed.', 'scrollstrike'), 403);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'), 403);
    }
 
    global $wpdb;
    $table_notes = $wpdb->prefix . 'scrollstrike_notes';
    $table_deployments = $wpdb->prefix . 'scrollstrike_deployments';

    $wpdb->query("TRUNCATE TABLE {$table_notes}");
    $wpdb->query("TRUNCATE TABLE {$table_deployments}");

    $posts = $wpdb->get_results("SELECT ID, post_content FROM {$wpdb->posts} WHERE post_content LIKE '%scrollstrike-trigger-word%'");
    if (!empty($posts)) {
        foreach ($posts as $p) {
            $clean = preg_replace('/<mark[^>]*class=["\'][^"\']*scrollstrike-trigger-word[^"\']*["\'][^>]*>(.*?)<\/mark>/is', '$1', $p->post_content);
            if ($clean !== $p->post_content) {
                wp_update_post([
                    'ID'           => absint($p->ID),
                    'post_content' => $clean,
                ]);
            }
        }
    }

    wp_send_json_success(['display_count' => 0]);
}
add_action('wp_ajax_scrollstrike_admin_delete_all', 'scrollstrike_ajax_admin_delete_all');



// ==========================================
// 9. AUTOMATIC SELF-HOSTED UPDATE CHECKER
// ==========================================
define('SCROLLSTRIKE_UPDATE_JSON_URL', 'https://zindvera.github.io/fegopics/scrollstrike-update.json');

add_filter('site_transient_update_plugins', 'scrollstrike_check_for_updates');
function scrollstrike_check_for_updates($transient) {
    if (empty($transient->checked)) {
        return $transient;
    }

    $response = wp_remote_get(SCROLLSTRIKE_UPDATE_JSON_URL, [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json']
    ]);

    if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
        return $transient;
    }

    $remote_data = json_decode(wp_remote_retrieve_body($response));
    $plugin_slug = plugin_basename(__FILE__); 

    if (!empty($remote_data->version)) {
        $item               = new stdClass();
        $item->id           = 'scrollstrike-custom-id';
        $item->slug         = 'scrollstrike';
        $item->plugin       = $plugin_slug;
        $item->new_version  = $remote_data->version;
        $item->url          = $remote_data->homepage ?? '';
        $item->package      = $remote_data->download_url ?? ''; 
        $item->tested       = $remote_data->tested ?? '7.1';
        $item->requires     = $remote_data->requires ?? '6.0';
        $item->requires_php = $remote_data->requires_php ?? '7.4';

        if (version_compare(SCROLLSTRIKE_VERSION, $remote_data->version, '<')) {
            $transient->response[$plugin_slug] = $item;
            unset($transient->no_update[$plugin_slug]);
        } else {
            $transient->no_update[$plugin_slug] = $item;
            unset($transient->response[$plugin_slug]);
        }
    }

    return $transient;
}

add_filter('plugins_api', 'scrollstrike_plugin_details_popup', 20, 3);
function scrollstrike_plugin_details_popup($result, $action, $args) {
    if ($action !== 'plugin_information' || !isset($args->slug) || $args->slug !== 'scrollstrike') {
        return $result;
    }

    $response = wp_remote_get(SCROLLSTRIKE_UPDATE_JSON_URL, ['timeout' => 10]);
    if (!is_wp_error($response) && 200 === wp_remote_retrieve_response_code($response)) {
        $remote_data = json_decode(wp_remote_retrieve_body($response));

        $info                = new stdClass();
        $info->name          = $remote_data->name;
        $info->slug          = 'scrollstrike';
        $info->version       = $remote_data->version;
        $info->author        = '<a href="https://zindvera.github.io/fegopics/">Fegopics</a>';
        $info->homepage      = $remote_data->homepage;
        $info->download_link = $remote_data->download_url;
        $info->tested        = $remote_data->tested ?? '7.1';
        $info->requires      = $remote_data->requires ?? '6.0';
        $info->requires_php  = $remote_data->requires_php ?? '7.4';
        $info->sections      = (array) $remote_data->sections;

        return $info;
    }

    return $result;
}
