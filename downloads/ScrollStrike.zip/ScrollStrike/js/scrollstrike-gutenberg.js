(function (wp) {

    // Self-contained gatekeeper resolver for Gutenberg Editor
    (function () {
        if (typeof scrollstrike_editor_data === 'undefined') return;

        var sessionTier = scrollstrike_editor_data.session_tier;

        if (sessionTier) {
            window.scrollstrike_is_processing = false;
            window.scrollstrike_global_tier = sessionTier;

            var event = new CustomEvent('scrollstrike_gatekeeper_resolved', {
                detail: { tier: sessionTier }
            });
            document.dispatchEvent(event);
        } else {
            window.scrollstrike_is_processing = true;
            window.scrollstrike_global_tier = 'pending';

            if (typeof jQuery !== 'undefined') {
                jQuery.post(scrollstrike_editor_data.ajax_url, {
                    action: 'scrollstrike_unified_gatekeeper_check',
                    nonce: scrollstrike_editor_data.verify_nonce
                }, function (response) {
                    window.scrollstrike_is_processing = false;
                    var tier = (response.success && response.data && response.data.tier) ? response.data.tier : 'free';
                    window.scrollstrike_global_tier = tier;

                    var event = new CustomEvent('scrollstrike_gatekeeper_resolved', {
                        detail: { tier: tier }
                    });
                    document.dispatchEvent(event);
                }).fail(function () {
                    window.scrollstrike_is_processing = false;
                    window.scrollstrike_global_tier = 'free';

                    var event = new CustomEvent('scrollstrike_gatekeeper_resolved', {
                        detail: { tier: 'free' }
                    });
                    document.dispatchEvent(event);
                });
            }
        }
    })();

    const { registerFormatType, applyFormat, removeFormat } = wp.richText;
    const { __ } = wp.i18n || { __: (text) => text };
    const { BlockControls } = wp.blockEditor || wp.editor;
    const { ToolbarGroup, ToolbarButton, Button } = wp.components;
    const { useState, useEffect, useRef, Fragment, createElement: el, createPortal } = wp.element;

    // --- HELPER FUNCTIONS ---
    const normalizeHtml = (html) => {
        if (!html) return '';
        let clean = html.trim();
        let match = clean.match(/^<p>\s*(.*?)\s*<\/p>$/is);
        if (match) clean = match[1].trim();
        return clean.replace(/\s+/g, ' ').toLowerCase();
    };

    const getCloseIconColor = (hex) => {
        if (!hex) return 'rgba(0,0,0,0.4)';
        let cleanHex = hex.replace('#', '');
        if (cleanHex.length === 3) cleanHex = cleanHex.split('').map(c => c + c).join('');
        const r = parseInt(cleanHex.substring(0, 2), 16);
        const g = parseInt(cleanHex.substring(2, 4), 16);
        const b = parseInt(cleanHex.substring(4, 6), 16);
        const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
        return (yiq >= 128) ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.8)';
    };

    const hslToHex = (h, s, l) => {
        l /= 100;
        const a = s * Math.min(l, 1 - l) / 100;
        const f = n => {
            const k = (n + h / 30) % 12;
            const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
            return Math.round(255 * color).toString(16).padStart(2, '0');
        };
        return `#${f(0)}${f(8)}${f(4)}`;
    };

    const hexToRgb = (hex) => {
        let cleanHex = hex.replace('#', '');
        if (cleanHex.length === 3) cleanHex = cleanHex.split('').map(c => c + c).join('');
        const r = parseInt(cleanHex.substring(0, 2), 16) || 0;
        const g = parseInt(cleanHex.substring(2, 4), 16) || 0;
        const b = parseInt(cleanHex.substring(4, 6), 16) || 0;
        return { r, g, b };
    };

    const triggerProUpgrade = () => {
        window.open(scrollstrike_editor_data.upgrade_url, '_blank');
    };

    const premiumHTMLTemplate = `
    <p style="margin: 0 0 6px 0; font-size: 20px; font-weight: 700; line-height: 1.3; color: inherit;">15 Best Corner Floor Lamps for Living Room</p>
    <p style="margin: 0 0 10px 0; font-size: 14px; opacity: 0.95; line-height: 1.5; color: inherit;">
        Here you can browse the top 15 corner floor lamps curated for your living room space.
    </p>
    <div class="vini-img-wrapper" style="text-align: center; margin-top: 20px; margin-bottom: 4px;">
        <img src="${window.scrollstrike_editor_data.plugin_url}media/asset/sample-image.png" alt="Uploaded Image" style="width: 100%; border-radius: 6px;" />
    </div>`;

    // --- COMPONENT: Reusable Demo Modal Wrapper ---
    const DemoModalWrapper = ({ title, onClose, children }) => {
        return createPortal(
            el('div', { style: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.85)', zIndex: 99999, display: 'flex', alignItems: 'center', justifyContent: 'center' } },
                el('div', { style: { width: '80vw', height: '90vh', minHeight: '600px', background: '#fff', borderRadius: '12px', display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative', boxShadow: '0 25px 60px rgba(0,0,0,0.5)' } },
                    el('div', { style: { padding: '20px 30px', borderBottom: '1px solid #ddd', display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 50, background: '#fff', flexShrink: 0 } },
                        el('h3', { style: { margin: 0, fontSize: '18px', fontWeight: '600', color: '#1d2327' } }, title),
                        el('div', { style: { display: 'flex', alignItems: 'center', gap: '15px' } },
                            el(Button, { isPrimary: true, onClick: triggerProUpgrade, style: { background: '#f56e28', border: 'none', borderRadius: '20px', padding: '4px 18px', fontWeight: 'bold' } }, '⭐ Upgrade to Pro'),
                            el('button', { onClick: onClose, style: { background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#8c8f94', transition: 'color 0.2s' } }, '✕')
                        )
                    ),
                    el('div', { style: { padding: '12px 30px', background: '#f8f9fa', borderBottom: '1px solid #ddd', display: 'flex', alignItems: 'center', justifyContent: 'space-between' } },
                        el('button', { onClick: onClose, style: { background: 'none', border: 'none', color: '#2271b1', fontSize: '18px', fontWeight: '600', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', padding: 0 } }, '← Back to Studio'),
                        el('span', { style: { background: '#f56e28', color: '#fff', fontSize: '13px', fontWeight: '600', padding: '4px 12px', borderRadius: '4px', letterSpacing: '0.5px' } }, 'This is PRO feature')
                    ),
                    el('div', { style: { display: 'flex', flexGrow: 1, overflow: 'hidden' } }, children)
                )
            ), document.body
        );
    };

    // --- COMPONENT: FocusModeDemoModal ---
    const FocusModeDemoModal = ({ onClose, initialNoteText, initialBgColor, initialTextColor }) => {
        const [active, setActive] = useState(false);
        const [dismissed, setDismissed] = useState(false);
        const containerRef = useRef(null);
        const targetRef = useRef(null);
        const [targetPos, setTargetPos] = useState({ top: 0, left: 0, width: 0, height: 0 });

        const isLegacyContent = initialNoteText && initialNoteText.trim() !== '';
        const previewHtml = isLegacyContent ? initialNoteText : premiumHTMLTemplate;
        const previewBg = isLegacyContent ? initialBgColor : '#C21D46';
        const previewColor = isLegacyContent ? initialTextColor : '#ffffff';

        const recalculateTargetPos = () => {
            if (targetRef.current && containerRef.current) {
                const targetRect = targetRef.current.getBoundingClientRect();
                const containerRect = containerRef.current.getBoundingClientRect();
                setTargetPos({
                    top: targetRect.top - containerRect.top + containerRef.current.scrollTop,
                    left: targetRect.left - containerRect.left,
                    width: targetRect.width,
                    height: targetRect.height
                });
            }
        };

        useEffect(() => {
            let focusTimer;
            const scrollTimeout = setTimeout(() => {
                if (targetRef.current && containerRef.current) {
                    const container = containerRef.current;
                    const target = targetRef.current;
                    const targetRect = target.getBoundingClientRect();
                    const containerRect = container.getBoundingClientRect();
                    const absoluteTargetTop = (targetRect.top - containerRect.top) + container.scrollTop;
                    const containerHeight = container.clientHeight;
                    const desiredScrollTop = Math.max(0, absoluteTargetTop - containerHeight + targetRect.height + 60);

                    container.scrollTo({ top: desiredScrollTop, behavior: 'smooth' });
                    focusTimer = setTimeout(() => {
                        recalculateTargetPos();
                        setActive(true);
                    }, 800);
                }
            }, 150);

            return () => {
                clearTimeout(scrollTimeout);
                clearTimeout(focusTimer);
            };
        }, []);

        const handleDismissTooltip = (e) => {
            e.stopPropagation();
            setDismissed(true);
            setActive(false);
        };

        const isFocused = active && !dismissed;

        return el(DemoModalWrapper, { title: 'Live Demo: Attention-Forcing Focus Mode', onClose: onClose },
            el('div', {
                ref: containerRef,
                onScroll: isFocused ? recalculateTargetPos : null,
                className: `ss-demo-modal-container ${isFocused ? 'is-focused' : ''}`,
                style: {
                    position: 'relative',
                    flexGrow: 1,
                    padding: '40px 70px 140px 70px',
                    background: '#f8f9fa',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'flex-start',
                    overflowY: 'auto'
                }
            },
                isFocused && el('div', {
                    style: {
                        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, width: '100%',
                        height: `${containerRef.current ? containerRef.current.scrollHeight : 1200}px`,
                        background: 'rgba(0,0,0,0.35)', zIndex: 10, pointerEvents: 'none'
                    }
                }),
                el('div', {
                    style: {
                        maxWidth: '720px', width: '100%', position: 'relative',
                        filter: isFocused ? 'blur(4px)' : 'none',
                        WebkitFilter: isFocused ? 'blur(4px)' : 'none',
                        transition: 'filter 0.5s ease, -webkit-filter 0.5s ease', zIndex: 1
                    }
                },
                    el('h2', { style: { fontSize: '30px', fontWeight: '700', color: '#1d2327', marginBottom: '16px', lineHeight: '1.25' } }, 'The Ultimate Living Room Decoration & Lighting Guide'),
                    el('div', { style: { width: '100%', marginBottom: '25px', borderRadius: '10px', overflow: 'hidden', boxShadow: '0 4px 15px rgba(0,0,0,0.06)' } },
                        el('img', {
                            src: 'https://images.pexels.com/photos/1125130/pexels-photo-1125130.jpeg?auto=compress&cs=tinysrgb&w=1200',
                            alt: 'Living Room Decoration & Corner Lighting',
                            style: { width: '100%', height: '260px', objectFit: 'cover', display: 'block' },
                            onLoad: () => { if (isFocused) recalculateTargetPos(); }
                        })
                    ),
                    el('p', { style: { fontSize: '15.5px', color: '#3c434a', lineHeight: '1.7', marginBottom: '20px' } },
                        'Creating a cozy and well-lit seating area relies heavily on layered illumination that balances warmth and functional elegance.'
                    ),
                    el('p', { style: { position: 'relative', fontSize: '15.5px', color: '#3c434a', lineHeight: '1.7', marginBottom: '20px' } },
                        el('span', null, 'When curating your space, discovering the '),
                        el('a', {
                            ref: targetRef,
                            href: 'https://benable.com/fingoz/15-best-corner-floor-lamps-for-living-room',
                            onClick: (e) => { e.preventDefault(); window.open(e.currentTarget.href, '_blank', 'noopener,noreferrer'); },
                            style: { color: '#2563eb', textDecoration: 'underline', fontWeight: '600', opacity: isFocused ? 0 : 1 }
                        }, '15 Best Corner Floor Lamps for Living Room'),
                        el('span', null, ' arrangements will effortlessly balance your decor, bringing both beauty and utility to your home.')
                    ),
                    el('p', { style: { fontSize: '15.5px', color: '#3c434a', lineHeight: '1.7', marginBottom: '20px' } },
                        'Interior designers often suggest incorporating slender metallic frames or warm wooden shades that elevate surrounding furniture.'
                    )
                ),
                isFocused && targetPos.width > 0 && el('div', { style: { position: 'absolute', top: targetPos.top, left: targetPos.left, zIndex: 30 } },
                    el('a', {
                        href: 'https://benable.com/fingoz/15-best-corner-floor-lamps-for-living-room',
                        onClick: (e) => { e.preventDefault(); window.open(e.currentTarget.href, '_blank', 'noopener,noreferrer'); },
                        style: {
                            color: '#2563eb', textDecoration: 'underline', fontSize: '15.5px', lineHeight: '1.7',
                            fontWeight: '600', padding: '0 2px', borderRadius: '2px', background: '#fff',
                            boxShadow: '0 0 15px rgba(255,255,255,0.9)'
                        }
                    }, '15 Best Corner Floor Lamps for Living Room'),
                    el('div', { style: { position: 'absolute', bottom: 'calc(100% + 14px)', left: '50%', transform: 'translateX(-50%)', background: previewBg, color: previewColor, padding: '14px 45px 12px 14px', borderRadius: '8px', width: '330px', boxShadow: '0 20px 50px rgba(0,0,0,0.4)', animation: 'ssTooltipPopUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards', textAlign: 'left', cursor: 'default', boxSizing: 'border-box' } },
                        el('span', { onClick: handleDismissTooltip, style: { position: 'absolute', top: '10px', right: '12px', fontSize: '14px', fontWeight: 'bold', color: getCloseIconColor(previewBg), zIndex: 20, cursor: 'pointer', padding: '2px 6px' }, title: 'Close Tooltip' }, '✕'),
                        el('div', { className: 'vini-content', style: { padding: 0, color: 'inherit' }, dangerouslySetInnerHTML: { __html: previewHtml } }),
                        el('div', { style: { position: 'absolute', bottom: '-8px', left: '50%', transform: 'translateX(-50%)', width: 0, height: 0, borderLeft: '10px solid transparent', borderRight: '10px solid transparent', borderTop: `8px solid ${previewBg}` } })
                    )
                )
            )
        );
    };

    // --- COMPONENT: Custom Interactive 2D Color Picker Demo ---
    const CustomColorDemoModal = ({ onClose, initialNoteText, initialBgColor, initialTextColor }) => {
        const isLegacyContent = initialNoteText && initialNoteText.trim() !== '';
        const initHex = isLegacyContent ? initialBgColor : '#C21D46';

        const hexToHsl = (hexStr) => {
            let hex = (hexStr || '#C21D46').replace('#', '');
            if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
            let r = (parseInt(hex.substring(0, 2), 16) || 0) / 255;
            let g = (parseInt(hex.substring(2, 4), 16) || 0) / 255;
            let b = (parseInt(hex.substring(4, 6), 16) || 0) / 255;
            let cmax = Math.max(r, g, b), cmin = Math.min(r, g, b);
            let delta = cmax - cmin, l = (cmax + cmin) / 2, h = 0, s = 0;
            if (delta !== 0) {
                if (cmax === r) h = ((g - b) / delta) % 6;
                else if (cmax === g) h = (b - r) / delta + 2;
                else h = (r - g) / delta + 4;
                s = delta / (1 - Math.abs(2 * l - 1));
            }
            h = Math.round(h * 60); if (h < 0) h += 360;
            return { h, s: s * 100, l: l * 100 };
        };

        const initialHsl = hexToHsl(initHex);
        const [hue, setHue] = useState(initialHsl.h);
        const [sat, setSat] = useState(initialHsl.s);
        const [light, setLight] = useState(initialHsl.l);
        const [demoBg, setDemoBg] = useState(initHex);
        const [demoHtml, setDemoHtml] = useState(isLegacyContent ? initialNoteText : premiumHTMLTemplate);
        const demoColor = isLegacyContent ? initialTextColor : '#ffffff';

        const isDraggingSatLight = useRef(false);
        const isDraggingHue = useRef(false);

        const updateSatLight = (e) => {
            if (!isDraggingSatLight.current && e.type !== 'mousedown') return;
            const rect = e.currentTarget.getBoundingClientRect();
            let x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
            let y = Math.max(0, Math.min(e.clientY - rect.top, rect.height));
            const newSat = (x / rect.width) * 100;
            const newLight = 100 - ((y / rect.height) * 100);
            setSat(newSat); setLight(newLight);
            setDemoBg(hslToHex(hue, newSat, newLight));
        };

        const updateHue = (e) => {
            if (!isDraggingHue.current && e.type !== 'mousedown') return;
            const rect = e.currentTarget.getBoundingClientRect();
            let y = Math.max(0, Math.min(e.clientY - rect.top, rect.height));
            const newHue = (y / rect.height) * 360;
            setHue(newHue);
            setDemoBg(hslToHex(newHue, sat, light));
        };

        useEffect(() => {
            const stopDragging = () => { isDraggingSatLight.current = false; isDraggingHue.current = false; };
            window.addEventListener('mouseup', stopDragging);
            return () => window.removeEventListener('mouseup', stopDragging);
        }, []);

        return el(DemoModalWrapper, { title: 'Live Demo: Custom Highlighter Color & Formatting', onClose: onClose },
            el('div', { style: { width: '45%', padding: '30px', borderRight: '1px solid #ddd', background: '#fff', overflowY: 'auto' } },
                el('p', { style: { fontSize: '14px', color: '#646970', marginBottom: '25px' } }, 'Use the interactive palette and rich text editor to match your exact brand aesthetics.'),
                el('label', { style: { display: 'block', fontSize: '12px', fontWeight: 'bold', color: '#646970', textTransform: 'uppercase', marginBottom: '10px' } }, 'Background Color Selector'),
                el('div', { style: { background: '#f8f9fa', border: '1px solid #ccd0d4', borderRadius: '8px', padding: '15px', marginBottom: '25px', userSelect: 'none' } },
                    el('div', { style: { display: 'flex', gap: '15px', marginBottom: '15px' } },
                        el('div', {
                            onMouseDown: (e) => { isDraggingSatLight.current = true; updateSatLight(e); },
                            onMouseMove: updateSatLight,
                            style: { flexGrow: 1, height: '140px', background: `linear-gradient(to bottom, transparent, #000), linear-gradient(to right, #fff, hsl(${hue}, 100%, 50%))`, borderRadius: '4px', position: 'relative', border: '1px solid rgba(0,0,0,0.1)', cursor: 'crosshair' }
                        },
                            el('div', { style: { position: 'absolute', left: `${sat}%`, top: `${100 - light}%`, transform: 'translate(-50%, -50%)', width: '12px', height: '12px', border: '2px solid #fff', borderRadius: '50%', boxShadow: '0 0 3px rgba(0,0,0,0.5)', pointerEvents: 'none' } })
                        ),
                        el('div', {
                            onMouseDown: (e) => { isDraggingHue.current = true; updateHue(e); },
                            onMouseMove: updateHue,
                            style: { width: '20px', height: '140px', background: 'linear-gradient(to bottom, #f00, #ff0, #0f0, #0ff, #00f, #f0f, #f00)', borderRadius: '10px', position: 'relative', border: '1px solid rgba(0,0,0,0.1)', cursor: 'ns-resize' }
                        },
                            el('div', { style: { position: 'absolute', top: `${(hue / 360) * 100}%`, left: '-2px', right: '-2px', transform: 'translateY(-50%)', height: '6px', background: '#fff', borderRadius: '3px', boxShadow: '0 0 3px rgba(0,0,0,0.5)', pointerEvents: 'none' } })
                        )
                    ),
                    el('div', { style: { display: 'flex', gap: '10px', alignItems: 'center' } },
                        el('div', { style: { width: '30px', height: '30px', background: demoBg, border: '1px solid #ccd0d4', borderRadius: '4px' } }),
                        el('input', { type: 'text', value: demoBg.toUpperCase(), readOnly: true, style: { flexGrow: 1, padding: '8px', border: '1px solid #ccd0d4', borderRadius: '4px', fontSize: '13px', background: '#fff' } })
                    )
                )
            ),
            el('div', { style: { width: '55%', background: '#f8f9fa', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', padding: '40px', overflowY: 'auto', boxSizing: 'border-box' } },
                el('div', { style: { position: 'relative', background: demoBg, color: demoColor, padding: '14px 45px 10px 14px', borderRadius: '8px', boxShadow: '0 15px 35px rgba(0,0,0,0.2)', maxWidth: '350px', width: '100%', fontSize: '15px', lineHeight: '1.5', flexShrink: 0 } },
                    el('span', { style: { position: 'absolute', top: '10px', right: '12px', fontSize: '14px', fontWeight: 'bold', color: getCloseIconColor(demoBg) } }, '✕'),
                    el('div', { className: 'ss-demo-preview-text', dangerouslySetInnerHTML: { __html: demoHtml } }),
                    el('div', { style: { position: 'absolute', bottom: '-8px', left: '50%', transform: 'translateX(-50%)', width: 0, height: 0, borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderTop: `8px solid ${demoBg}` } })
                )
            )
        );
    };

    // --- COMPONENT: Premium Promotional Wrapper ---
    const ProFeaturePresentation = (props) => {
        const { description, innerContent, onClickOverride } = props;
        return el('div', { className: 'scrollstrike-pro-presentation', style: { marginBottom: '30px', padding: '0', paddingTop: '15px', borderTop: '1px solid #e0e0e0' } },
            description && el('p', { style: { fontSize: '12px', color: '#646970', marginBottom: '10px', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.5px' } }, description),
            el('div', {
                onClick: onClickOverride,
                title: "Click to try live demo!",
                style: {
                    background: 'linear-gradient(135deg, rgba(250, 250, 252, 0.9) 0%, rgba(240, 242, 245, 0.6) 100%)',
                    backdropFilter: 'blur(8px)', border: 'none',
                    boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.8), 0 2px 8px rgba(0,0,0,0.04)',
                    borderRadius: '8px', padding: '25px 20px 20px 20px', cursor: 'pointer', position: 'relative'
                }
            },
                el('span', { style: { position: 'absolute', top: '12px', right: '12px', background: '#f56e28', color: '#fff', fontSize: '10px', padding: '4px 10px', borderRadius: '12px', fontWeight: 'bold', zIndex: 20 } }, 'PRO'),
                el('div', { style: { pointerEvents: 'none', opacity: '0.95' } }, innerContent)
            )
        );
    };

    // --- SHARED COMPONENT: Pro Feature Comparison Table ---
    const renderProComparisonTable = () => {
        return el('table', { style: { width: '100%', borderCollapse: 'collapse', marginBottom: '30px', border: '1px solid #ccd0d4' } },
            el('thead', { style: { background: '#f8f9fa' } },
                el('tr', null,
                    el('th', { style: { padding: '12px 15px', textAlign: 'left', borderBottom: '2px solid #ccd0d4', fontWeight: 'bold' } }, 'Feature'),
                    el('th', { style: { padding: '12px 15px', textAlign: 'left', borderBottom: '2px solid #ccd0d4', fontWeight: 'bold' } }, 'Free Version'),
                    el('th', { style: { padding: '12px 15px', textAlign: 'left', borderBottom: '2px solid #ccd0d4', fontWeight: 'bold', color: '#f56e28' } }, 'ScrollStrike PRO')
                )
            ),
            el('tbody', null,
                [
                    ['Total Highlighters (Library IDs)', 'Max 3 unique highlighters', 'Unlimited'],
                    ['Total Target Elements', 'Max 3 elements (Website-wide)', 'Unlimited'],
                    ['Highlighter Colors', '8 basic presets only', 'Full custom (Any color)'],
                    ['Frequency & Delay', '✅ Fully Customizable', '✅ Fully Customizable'],
                    ['Focus Mode (Blur)', '❌ Locked', '✅ Included']
                ].map((row, i) =>
                    el('tr', { key: i, style: { borderBottom: '1px solid #f0f0f1' } },
                        el('td', { style: { padding: '12px 15px', fontWeight: '600', color: '#1d2327' } }, row[0]),
                        el('td', { style: { padding: '12px 15px', color: '#646970' } }, row[1]),
                        el('td', { style: { padding: '12px 15px', fontWeight: 'bold', color: '#1d2327', background: '#fff9f5' } }, row[2])
                    )
                )
            )
        );
    };

    // --- COMPONENT: Limit Warning Modal ---
    const LimitModal = ({ type, onClose }) => {
        const title = type === 'limit_elements'
            ? '❌ Free Tier Limit: Website-Wide Placement Restrictions Exceeded'
            : '❌ Free Tier Limit: Global Library Creation Cap Reached';

        const message = type === 'limit_elements'
            ? 'You have reached the maximum of 3 highlighted elements allowed across your website on the Free tier. Upgrade to PRO to add unlimited highlights, or remove an old one.'
            : 'You have reached the maximum of 3 free highlighters allowed in your library. Upgrade to PRO to create unlimited highlighters, or delete an old one.';

        return createPortal(
            el('div', { style: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.85)', zIndex: 99999, display: 'flex', alignItems: 'center', justifyContent: 'center' } },
                el('div', { style: { background: '#fff', borderRadius: '12px', width: '100%', maxWidth: '700px', overflow: 'hidden', boxShadow: '0 25px 60px rgba(0,0,0,0.5)' } },
                    el('div', { style: { padding: '25px 30px', borderBottom: '1px solid #ddd', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fce4e4' } },
                        el('h3', { style: { margin: 0, fontSize: '18px', fontWeight: '700', color: '#d63638' } }, title),
                        el('button', { onClick: onClose, style: { background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#d63638' } }, '✕')
                    ),
                    el('div', { style: { padding: '30px' } },
                        el('p', { style: { fontSize: '15px', color: '#3c434a', marginBottom: '25px', lineHeight: '1.6' } }, message),
                        renderProComparisonTable(),
                        el('div', { style: { textAlign: 'center' } },
                            el(Button, { isPrimary: true, onClick: triggerProUpgrade, style: { background: '#f56e28', border: 'none', borderRadius: '30px', padding: '12px 30px', fontSize: '16px', fontWeight: 'bold' } }, '⭐ Upgrade to PRO Instantly')
                        )
                    )
                )
            ), document.body
        );
    };


    const ScrollStrikeStudioCanvas = (props) => {
        const { value, onChange, onClose, existingId } = props;

        const [isProActive, setIsProActive] = useState(() => {
            if (typeof window.scrollstrike_global_tier !== 'undefined' && window.scrollstrike_global_tier !== 'pending') {
                return window.scrollstrike_global_tier === 'pro';
            }
            if (typeof scrollstrike_editor_data !== 'undefined' && scrollstrike_editor_data.session_tier) {
                return scrollstrike_editor_data.session_tier === 'pro';
            }
            return scrollstrike_editor_data.is_pro === true || scrollstrike_editor_data.is_pro === '1';
        });

        const [isVerifyingTier, setIsVerifyingTier] = useState(() => {
            if (typeof scrollstrike_editor_data !== 'undefined' && scrollstrike_editor_data.session_tier) {
                return false;
            }
            return typeof window.scrollstrike_is_processing !== 'undefined' ? window.scrollstrike_is_processing : false;
        });

        useEffect(() => {
            const handleGatekeeperResolved = (e) => {
                setIsVerifyingTier(false);
                setIsProActive(e.detail.tier === 'pro');
            };

            document.addEventListener('scrollstrike_gatekeeper_resolved', handleGatekeeperResolved);

            if (typeof window.scrollstrike_is_processing !== 'undefined' && window.scrollstrike_is_processing === false) {
                setIsVerifyingTier(false);
                setIsProActive(window.scrollstrike_global_tier === 'pro');
            }

            return () => {
                document.removeEventListener('scrollstrike_gatekeeper_resolved', handleGatekeeperResolved);
            };
        }, []);

        const [activeTab, setActiveTab] = useState('create');
        const [noteText, setNoteText] = useState('');
        const [textColor, setTextColor] = useState('#ffffff');

        const defaultBgColor = (scrollstrike_editor_data && scrollstrike_editor_data.preset_colors && scrollstrike_editor_data.preset_colors.length > 0)
            ? scrollstrike_editor_data.preset_colors[0].value
            : '#db2777';

        const [bgColor, setBgColor] = useState(defaultBgColor);
        const [delayTime, setDelayTime] = useState('0');
        const [freqType, setFreqType] = useState('always');
        const [freqValue, setFreqValue] = useState(1);
        const [focusMode, setFocusMode] = useState(false);
        const [isSaving, setIsSaving] = useState(false);

        const [loadedNoteId, setLoadedNoteId] = useState(null);
        const [initialNoteSnapshot, setInitialNoteSnapshot] = useState(null);
        const [isCurrentNotePro, setIsCurrentNotePro] = useState(false);

        const [showFocusDemo, setShowFocusDemo] = useState(false);
        const [showColorDemo, setShowColorDemo] = useState(false);
        const [showProUpgradeModal, setShowProUpgradeModal] = useState(false);
        const [limitErrorType, setLimitErrorType] = useState(null);

        const [libraryNotes, setLibraryNotes] = useState([]);
        const [libraryOffset, setLibraryOffset] = useState(0);
        const [libraryHasMore, setLibraryHasMore] = useState(true);
        const [isLibraryLoading, setIsLibraryLoading] = useState(false);
        const [searchQuery, setSearchQuery] = useState('');
        const observerRef = useRef(null);
        const lastNodeRef = useRef(null);

        const presetColors = (scrollstrike_editor_data && scrollstrike_editor_data.preset_colors)
            ? scrollstrike_editor_data.preset_colors
            : [
                ['Hot Pink', '#db2777'],
                ['Charcoal', '#1e293b'],
                ['Royal Blue', '#2563eb'],
                ['Emerald Green', '#16a34a'],
                ['Aqua Cyan', '#0b819f'],
                ['Vivid Orange', '#ea580c'],
                ['Crimson Red', '#dc2626'],
                ['Deep Violet', '#6e34d3']
            ].map(([label, value]) => ({ label, value }));

        const [liveSiteElements, setLiveSiteElements] = useState(0);
        const [liveFreeTooltips, setLiveFreeTooltips] = useState(0);
        const [isFetchingLimits, setIsFetchingLimits] = useState(false);

        const [hue, setHue] = useState(196);
        const [sat, setSat] = useState(77);
        const [light, setLight] = useState(31);

        useEffect(() => {
            const editorContainer = document.getElementById('scrollstrike-gutenberg-vini-editor');
            if (editorContainer && typeof editorContainer.setCanvasColors === 'function') {
                editorContainer.setCanvasColors(bgColor, textColor);
            }
        }, [bgColor, textColor]);

        const isDraggingSatLight = useRef(false);
        const isDraggingHue = useRef(false);

        const fetchLibraryNotes = (reset = false, query = '') => {
            if (isLibraryLoading || isVerifyingTier) return;
            const currentOffset = reset ? 0 : libraryOffset;
            setIsLibraryLoading(true);

            jQuery.post(scrollstrike_editor_data.ajax_url, {
                action: 'scrollstrike_get_paginated_notes',
                nonce: scrollstrike_editor_data.nonce,
                offset: currentOffset,
                search: query
            }, (response) => {
                if (response.success && response.data) {
                    const fetchedNotes = response.data.notes;
                    setLibraryNotes(prev => reset ? fetchedNotes : [...prev, ...fetchedNotes]);
                    setLibraryHasMore(response.data.has_more);
                    setLibraryOffset(currentOffset + fetchedNotes.length);

                    fetchedNotes.forEach(fetchedNote => {
                        if (!scrollstrike_editor_data.notes.some(n => n.id === fetchedNote.id)) {
                            scrollstrike_editor_data.notes.push(fetchedNote);
                        }
                    });
                }
                setIsLibraryLoading(false);
            });
        };

        useEffect(() => {
            if (activeTab === 'library' && !isVerifyingTier) {
                const timer = setTimeout(() => {
                    fetchLibraryNotes(true, searchQuery);
                }, 300);
                return () => clearTimeout(timer);
            }
        }, [searchQuery, activeTab, isVerifyingTier]);

        useEffect(() => {
            if (isLibraryLoading || isVerifyingTier) return;
            if (observerRef.current) observerRef.current.disconnect();

            observerRef.current = new IntersectionObserver(entries => {
                if (entries[0].isIntersecting && libraryHasMore) {
                    fetchLibraryNotes(false, searchQuery);
                }
            }, { threshold: 0.1 });

            if (lastNodeRef.current) {
                observerRef.current.observe(lastNodeRef.current);
            }
        }, [libraryNotes, isLibraryLoading, libraryHasMore, searchQuery, isVerifyingTier]);

        const getFilteredEditorCount = () => {
            let count = 0;
            if (window.wp && window.wp.data && window.wp.data.select('core/block-editor')) {
                const blocks = window.wp.data.select('core/block-editor').getBlocks();
                const content = window.wp.blocks ? window.wp.blocks.serialize(blocks) : '';
                const matches = content.match(/class=["'][^"']*scrollstrike-trigger-word/g);
                if (matches) count = matches.length;
            }
            return count;
        };

        const syncDeployment = (tooltipId, actionType) => {
            let postId = 0;
            if (window.wp && window.wp.data && window.wp.data.select('core/editor')) {
                postId = window.wp.data.select('core/editor').getCurrentPostId() || 0;
            }
            if (!postId) return;

            let editorCount = getFilteredEditorCount();
            if (actionType === 'remove') editorCount = Math.max(0, editorCount - 1);

            jQuery.ajax({
                url: scrollstrike_editor_data.ajax_url,
                type: 'POST',
                data: {
                    action: 'scrollstrike_sync_deployment', nonce: scrollstrike_editor_data.nonce,
                    post_id: postId, tooltip_id: tooltipId, action_type: actionType, editor_count: editorCount
                }
            });
        };

        useEffect(() => {
            if (isProActive || isVerifyingTier) return;
            let postId = 0;
            if (window.wp && window.wp.data && window.wp.data.select('core/editor')) {
                postId = window.wp.data.select('core/editor').getCurrentPostId() || 0;
            }

            setIsFetchingLimits(true);
            jQuery.ajax({
                url: scrollstrike_editor_data.ajax_url, type: 'POST',
                data: { action: 'scrollstrike_get_counts', nonce: scrollstrike_editor_data.nonce, post_id: postId, editor_count: getFilteredEditorCount() },
                success: function (response) {
                    setIsFetchingLimits(false);
                    if (response.success && response.data) {
                        setLiveFreeTooltips(response.data.free_tooltips_created);
                        setLiveSiteElements(response.data.site_elements_deployed);
                    }
                }
            });
        }, [isProActive, isVerifyingTier]);

        useEffect(() => {
            if (!bgColor || isDraggingSatLight.current || isDraggingHue.current) return;
            let hex = bgColor.replace('#', '');
            if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
            let r = (parseInt(hex.substring(0, 2), 16) || 0) / 255;
            let g = (parseInt(hex.substring(2, 4), 16) || 0) / 255;
            let b = (parseInt(hex.substring(4, 6), 16) || 0) / 255;
            let cmax = Math.max(r, g, b), cmin = Math.min(r, g, b);
            let delta = cmax - cmin, h = 0, s = 0, l = 0;
            if (delta === 0) h = 0;
            else if (cmax === r) h = ((g - b) / delta) % 6;
            else if (cmax === g) h = (b - r) / delta + 2;
            else h = (r - g) / delta + 4;
            h = Math.round(h * 60);
            if (h < 0) h += 360;
            l = (cmax + cmin) / 2;
            s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));
            setHue(h); setSat(s * 100); setLight(l * 100);
        }, [bgColor]);

        const updateSatLight = (e) => {
            if (!isDraggingSatLight.current && e.type !== 'mousedown') return;
            const rect = e.currentTarget.getBoundingClientRect();
            let x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
            let y = Math.max(0, Math.min(e.clientY - rect.top, rect.height));
            const newSat = (x / rect.width) * 100;
            const newLight = 100 - ((y / rect.height) * 100);
            setSat(newSat); setLight(newLight);
            setBgColor(hslToHex(hue, newSat, newLight));
        };

        const updateHue = (e) => {
            if (!isDraggingHue.current && e.type !== 'mousedown') return;
            const rect = e.currentTarget.getBoundingClientRect();
            let y = Math.max(0, Math.min(e.clientY - rect.top, rect.height));
            const newHue = (y / rect.height) * 360;
            setHue(newHue);
            setBgColor(hslToHex(newHue, sat, light));
        };

        useEffect(() => {
            const stopDragging = () => { isDraggingSatLight.current = false; isDraggingHue.current = false; };
            window.addEventListener('mouseup', stopDragging);
            return () => window.removeEventListener('mouseup', stopDragging);
        }, []);

        useEffect(() => {
            if (existingId && !isVerifyingTier && scrollstrike_editor_data && scrollstrike_editor_data.notes) {
                const note = scrollstrike_editor_data.notes.find(n => n.id === existingId) || libraryNotes.find(n => n.id === existingId);

                if (note) {
                    const content = note.note_text || '';
                    setNoteText(content);

                    if (!isProActive) {
                        const noteTier = note.tier || 'free';
                        setIsCurrentNotePro(noteTier === 'pro');
                    } else {
                        setIsCurrentNotePro(false);
                    }

                    const activeBgColor = note.bg_color || defaultBgColor;
                    const activeTextColor = note.text_color || '#ffffff';

                    setTextColor(activeTextColor);
                    setBgColor(activeBgColor);
                    setDelayTime(note.delay_time ? note.delay_time.toString() : '0');
                    setFreqType(note.frequency_type || 'always');
                    setFreqValue(note.frequency_value || 1);
                    setFocusMode(note.focus_mode == 1);
                    setLoadedNoteId(note.id);

                    setInitialNoteSnapshot({
                        note_text: content,
                        bg_color: activeBgColor,
                        text_color: activeTextColor,
                        delay_time: note.delay_time ? note.delay_time.toString() : '0',
                        frequency_type: note.frequency_type || 'always',
                        frequency_value: note.frequency_value || 1,
                        focus_mode: note.focus_mode == 1
                    });

                    setActiveTab('create');
                }
            }
        }, [existingId, isProActive, isVerifyingTier]);

        const handleUseTooltip = (note) => {
            const rawContent = note.note_text || '';
            setNoteText(rawContent);

            setTimeout(() => {
                const viniCanvas = document.querySelector('#scrollstrike-gutenberg-vini-editor .vini-content');
                if (viniCanvas) {
                    viniCanvas.innerHTML = rawContent;
                }
            }, 50);

            if (!isProActive) {
                const noteTier = note.tier || 'free';
                setIsCurrentNotePro(noteTier === 'pro');
            } else {
                setIsCurrentNotePro(false);
            }

            const activeBg = note.bg_color || '#fff1f1';
            const activeText = note.text_color || '#333333';

            setTextColor(activeText);
            setBgColor(activeBg);
            setDelayTime(note.delay_time ? note.delay_time.toString() : '0');
            setFreqType(note.frequency_type || 'always');
            setFreqValue(note.frequency_value || 1);
            setFocusMode(note.focus_mode == 1);
            setLoadedNoteId(note.id);

            setInitialNoteSnapshot({
                note_text: rawContent,
                bg_color: activeBg,
                text_color: activeText,
                delay_time: note.delay_time ? note.delay_time.toString() : '0',
                frequency_type: note.frequency_type || 'always',
                frequency_value: note.frequency_value || 1,
                focus_mode: note.focus_mode == 1
            });

            setActiveTab('create');
        };

        const handleRemove = () => {
            if (existingId) syncDeployment(existingId, 'remove');
            onChange(removeFormat(value, 'scrollstrike/note'));
            onClose();
        };

        const handleSave = () => {
            if (isSaving) return;

            const viniCanvas = document.querySelector('#scrollstrike-gutenberg-vini-editor .vini-content');
            const finalNoteText = viniCanvas ? viniCanvas.innerHTML : noteText;

            if (!finalNoteText || !finalNoteText.trim() || finalNoteText === '<p><br></p>') {
                return;
            }

            let editorCount = getFilteredEditorCount();
            if (!existingId) editorCount += 1;

            let postId = 0;
            if (window.wp && window.wp.data && window.wp.data.select('core/editor')) {
                postId = window.wp.data.select('core/editor').getCurrentPostId() || 0;
            }

            let isReusing = false;
            let finalIdToSave = null;

            if (loadedNoteId && initialNoteSnapshot) {
                const isIdenticalToOriginal = (
                    normalizeHtml(finalNoteText) === normalizeHtml(initialNoteSnapshot.note_text) &&
                    (bgColor || '').toLowerCase() === (initialNoteSnapshot.bg_color || '').toLowerCase() &&
                    (textColor || '').toLowerCase() === (initialNoteSnapshot.text_color || '').toLowerCase() &&
                    parseFloat(delayTime || 0) === parseFloat(initialNoteSnapshot.delay_time || 0) &&
                    (freqType || 'always') === (initialNoteSnapshot.frequency_type || 'always') &&
                    parseInt(freqValue || 1, 10) === parseInt(initialNoteSnapshot.frequency_value || 1, 10) &&
                    Boolean(focusMode) === Boolean(initialNoteSnapshot.focus_mode)
                );

                if (isIdenticalToOriginal) {
                    isReusing = true;
                    finalIdToSave = loadedNoteId;
                }
            }

            if (!isProActive) {
                if (!existingId && liveSiteElements >= 3) {
                    setLimitErrorType('limit_elements');
                    return;
                }
                if (!isReusing && liveFreeTooltips >= 3) {
                    setLimitErrorType('limit_tooltips');
                    return;
                }
            }

            setIsSaving(true);

            jQuery.ajax({
                url: scrollstrike_editor_data.ajax_url,
                type: 'POST',
                data: {
                    action: 'scrollstrike_save_note',
                    nonce: scrollstrike_editor_data.nonce,
                    post_id: postId,
                    editor_count: editorCount,
                    is_reusing: isReusing ? 'true' : 'false',
                    has_existing_id: existingId ? 'true' : 'false',
                    note_text: finalNoteText,
                    text_color: textColor,
                    bg_color: bgColor,
                    delay_time: parseFloat(delayTime) || 0,
                    focus_mode: focusMode ? 'true' : 'false',
                    frequency_type: freqType,
                    frequency_value: freqValue
                },
                success: function (response) {
                    setIsSaving(false);
                    if (response.success) {
                        if (response.data && response.data.action === 'approved_reuse') {
                            finalizeAttachment(finalIdToSave);
                        } else if (response.data && response.data.note) {
                            const newNote = response.data.note;
                            if (!scrollstrike_editor_data.notes.some(n => n.id === newNote.id)) {
                                scrollstrike_editor_data.notes.unshift(newNote);
                            }
                            finalizeAttachment(newNote.id);
                        }
                    } else {
                        if (response.data && response.data.code) {
                            setLimitErrorType(response.data.code);
                        } else {
                            console.error(response.data.message || response.data || 'Unknown error');
                        }
                    }
                },
                error: function () {
                    setIsSaving(false);
                    console.error('An unexpected server error occurred.');
                }
            });
        };

        const finalizeAttachment = (idToAttach) => {
            if (existingId && existingId !== idToAttach) syncDeployment(existingId, 'remove');
            onChange(applyFormat(value, { type: 'scrollstrike/note', attributes: { 'data-id': idToAttach } }));
            syncDeployment(idToAttach, 'deploy');
            onClose();
        };

        const labelStyle = { fontSize: '12px', fontWeight: '600', color: '#64748b', textTransform: 'uppercase', marginBottom: '8px', display: 'block', letterSpacing: '0.5px' };

        return el(Fragment, null,
            limitErrorType && el(LimitModal, { type: limitErrorType, onClose: () => setLimitErrorType(null) }),

            showProUpgradeModal && el('div', { style: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.7)', zIndex: 99999, display: 'flex', alignItems: 'center', justifyContent: 'center' } },
                el('div', { style: { background: '#fff', padding: '35px 40px', borderRadius: '12px', textAlign: 'center', width: '100%', maxWidth: '700px', boxShadow: '0 25px 60px rgba(0,0,0,0.5)', position: 'relative' } },
                    el('button', { onClick: () => setShowProUpgradeModal(false), style: { position: 'absolute', top: '15px', right: '15px', background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#8c8f94', transition: 'color 0.2s' } }, '✕'),
                    el('h3', { style: { margin: '0 0 10px 0', fontSize: '20px', color: '#1d2327' } }, 'Pro Feature Locked'),
                    el('p', { style: { fontSize: '15px', color: '#646970', margin: '0 0 30px 0', lineHeight: '1.5' } }, 'Upgrade to PRO version to unlock this highlighter and advanced features.'),
                    renderProComparisonTable(),
                    el(Button, { isPrimary: true, onClick: triggerProUpgrade, style: { background: '#f56e28', border: 'none', borderRadius: '30px', padding: '10px 24px', fontSize: '15px', fontWeight: 'bold' } }, '⭐ Upgrade to PRO')
                )
            ),

            (!isProActive && showFocusDemo && !isVerifyingTier) && el(FocusModeDemoModal, {
                onClose: () => setShowFocusDemo(false),
                initialNoteText: (isCurrentNotePro && initialNoteSnapshot && initialNoteSnapshot.note_text) ? initialNoteSnapshot.note_text : '',
                initialBgColor: (initialNoteSnapshot && initialNoteSnapshot.bg_color) ? initialNoteSnapshot.bg_color : '',
                initialTextColor: (initialNoteSnapshot && initialNoteSnapshot.text_color) ? initialNoteSnapshot.text_color : ''
            }),
            (!isProActive && showColorDemo && !isVerifyingTier) && el(CustomColorDemoModal, {
                onClose: () => setShowColorDemo(false),
                initialNoteText: (isCurrentNotePro && initialNoteSnapshot && initialNoteSnapshot.note_text) ? initialNoteSnapshot.note_text : '',
                initialBgColor: (initialNoteSnapshot && initialNoteSnapshot.bg_color) ? initialNoteSnapshot.bg_color : '',
                initialTextColor: (initialNoteSnapshot && initialNoteSnapshot.text_color) ? initialNoteSnapshot.text_color : ''
            }),

            el('div', { style: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.65)', zIndex: 99990, display: 'flex', alignItems: 'center', justifyContent: 'center', boxSizing: 'border-box' } },
                el('div', { style: { width: '80vw', height: '90vh', minHeight: '600px', background: '#fff', borderRadius: '12px', boxShadow: '0 25px 60px rgba(0,0,0,0.4)', display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative' } },

                    isVerifyingTier && el('div', { style: { position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(255,255,255,0.95)', zIndex: 9999, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', backdropFilter: 'blur(5px)' } },
                        el('div', { style: { width: '40px', height: '40px', border: '4px solid rgba(234, 88, 12, 0.2)', borderTopColor: '#ea580c', borderRadius: '50%', animation: 'ss-spin 1s linear infinite', marginBottom: '15px' } }),
                        el('h3', { style: { color: '#0f172a', fontSize: '16px', fontWeight: '600', margin: 0, letterSpacing: '0.5px' } }, 'Verifying License Workspace...')
                    ),

                    el('div', { style: { padding: '20px 30px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fff', flexShrink: 0 } },
                        el('h2', { style: { margin: 0, fontSize: '20px', fontWeight: 700, color: '#1d2327' } }, 'ScrollStrike Studio'),
                        el('button', { onClick: onClose, style: { background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#8c8f94', padding: '5px', transition: 'color 0.2s' } }, '✕')
                    ),

                    el('div', { style: { padding: '0 30px 20px 30px', borderBottom: '1px solid #dcdde1', display: 'flex', alignItems: 'center', gap: '10px' } },
                        el(Button, { isPrimary: activeTab === 'create', isSecondary: activeTab !== 'create', onClick: () => { setActiveTab('create'); setLoadedNoteId(null); setInitialNoteSnapshot(null); setIsCurrentNotePro(false); }, style: { borderRadius: '20px', padding: '4px 18px', fontWeight: 600 } }, '✨ Create New Highlighter'),
                        el(Button, { isPrimary: activeTab === 'library', isSecondary: activeTab !== 'library', onClick: () => setActiveTab('library'), style: { borderRadius: '20px', padding: '4px 18px', fontWeight: 600 } }, '📚 Attach from Library'),

                        isProActive ?
                            el('span', { style: { marginLeft: 'auto', background: '#1d2327', color: '#fff', borderRadius: '20px', padding: '6px 16px', fontWeight: 'bold', fontSize: '12px', letterSpacing: '0.5px' } }, '👑 PRO VERSION')
                            :
                            el(Button, { isPrimary: true, onClick: triggerProUpgrade, style: { marginLeft: 'auto', background: '#f56e28', border: 'none', borderRadius: '20px', padding: '4px 18px', fontWeight: 'bold' } }, '⭐ Upgrade to Pro')
                    ),

                    activeTab === 'library' ?
                        el('div', { style: { flexGrow: 1, padding: '40px', width: '100%', overflowY: 'auto', boxSizing: 'border-box', background: '#f8f9fa' } },
                            el('div', { style: { maxWidth: '1000px', margin: '0 auto' } },
                                el('div', { style: { marginBottom: '40px', textAlign: 'center' } },
                                    el('input', { type: 'text', placeholder: "Search your highlighter library...", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value), style: { width: '100%', maxWidth: '500px', padding: '14px 20px', fontSize: '15px', borderRadius: '30px', border: '1px solid #ccd0d4', outline: 'none', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' } })
                                ),
                                el('div', { style: { marginBottom: '40px' } },
                                    el('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '25px', alignItems: 'start' } },
                                        libraryNotes.map((note, index) => {
                                            const isTriggerNode = index === Math.max(0, libraryNotes.length - 6);
                                            return renderLibraryCard(note, isTriggerNode ? lastNodeRef : null);
                                        })
                                    )
                                ),
                                isLibraryLoading && el('div', { style: { textAlign: 'center', padding: '20px', color: '#8c8f94', fontWeight: '600', fontSize: '14px' } }, 'Loading Highlighters...'),
                                (!isLibraryLoading && libraryNotes.length === 0) && el('p', { style: { color: '#8c8f94', fontSize: '14px', textAlign: 'center' } }, 'No highlighters found in library.')
                            )
                        )
                        :
                        el('div', { style: { display: 'flex', flexGrow: 1, overflow: 'hidden', width: '100%', position: 'relative' } },
                            el('div', { style: { position: 'absolute', top: 0, bottom: 0, left: 0, width: '55%', overflowY: 'auto', boxSizing: 'border-box', borderRight: '1px solid #f0f0f1', padding: '35px 35px 80px 35px' } },
                                activeTab === 'create' && el('div', null,
                                    el('div', { style: { marginBottom: '30px' } },
                                        el('label', { style: labelStyle }, 'Highlighter Content'),
                                        el('div', {
                                            id: 'scrollstrike-gutenberg-vini-editor',
                                            className: 'vini-tooltip-preview-wrapper',
                                            style: { width: '100%', minHeight: '250px' },
                                            ref: (node) => {
                                                if (node && !node.dataset.viniInitialized) {
                                                    node.dataset.viniInitialized = "true";

                                                    if (typeof window.initViniRichText === 'function') {
                                                        node.innerHTML = '';
                                                        window.initViniRichText('scrollstrike-gutenberg-vini-editor', {
                                                            bgColor: bgColor,
                                                            textColor: textColor
                                                        });

                                                        const canvas = node.querySelector('.vini-content');
                                                        if (canvas) {
                                                            if (noteText) {
                                                                const trimmed = noteText.trim();
                                                                canvas.innerHTML = /^<(p|div|h[1-6]|ul|ol|blockquote)[\s\S]*>/i.test(trimmed)
                                                                    ? trimmed
                                                                    : '<p>' + trimmed + '</p>';
                                                            }
                                                            const syncPreview = () => {
                                                                setNoteText(canvas.innerHTML);
                                                                setIsCurrentNotePro(false);
                                                            };

                                                            canvas.addEventListener('input', syncPreview);
                                                            canvas.addEventListener('keyup', syncPreview);

                                                            window.ssUpdatePreview = () => {
                                                                if (canvas) {
                                                                    setNoteText(canvas.innerHTML);
                                                                    setIsCurrentNotePro(false);
                                                                }
                                                            };
                                                        }
                                                    }
                                                }
                                                if (node) {
                                                    const canvas = node.querySelector('.vini-content');
                                                    if (canvas && noteText && canvas.innerHTML !== noteText && document.activeElement !== canvas) {
                                                        canvas.innerHTML = noteText;
                                                    }
                                                }
                                            }
                                        })
                                    ),

                                    el('hr', { style: { margin: '30px 0', border: 'none', borderTop: '1px solid #f0f0f1' } }),

                                    el('div', { style: { marginBottom: '30px' } },
                                        el('label', { style: labelStyle }, 'Preset Highlighter Colors'),
                                        el('div', { style: { display: 'flex', gap: '15px' } },
                                            presetColors.map(preset => {
                                                const isPresetDisabled = !isProActive && isCurrentNotePro;
                                                return el('button', {
                                                    key: preset.value,
                                                    title: isPresetDisabled ? 'Color presets disabled for PRO tooltips in Free tier' : preset.label,
                                                    onClick: () => {
                                                        if (isPresetDisabled) return;
                                                        setBgColor(preset.value);
                                                        setTextColor('#ffffff');
                                                    },
                                                    style: {
                                                        width: '40px', height: '40px', borderRadius: '50%', background: preset.value,
                                                        border: bgColor.toLowerCase() === preset.value.toLowerCase() ? '3px solid #757575' : '1px solid #dcdde1',
                                                        transform: bgColor.toLowerCase() === preset.value.toLowerCase() ? 'scale(1.08)' : 'scale(1)',
                                                        boxShadow: bgColor.toLowerCase() === preset.value.toLowerCase() ? '0 4px 10px rgba(0,0,0,0.1)' : '0 2px 4px rgba(0,0,0,0.05)',
                                                        cursor: isPresetDisabled ? 'not-allowed' : 'pointer',
                                                        opacity: isPresetDisabled ? 0.4 : 1,
                                                        padding: 0, transition: 'all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
                                                    }
                                                });
                                            })
                                        )
                                    ),

                                    isProActive ?
                                        el('div', { style: { marginBottom: '30px' } },
                                            el('label', { style: labelStyle }, 'Custom Highlighter Color'),
                                            el('div', { style: { padding: '20px', background: '#fff', border: '1px solid #ccd0d4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' } },
                                                el('div', { style: { display: 'flex', gap: '15px', marginBottom: '15px' } },
                                                    el('div', {
                                                        onMouseDown: (e) => { isDraggingSatLight.current = true; updateSatLight(e); },
                                                        onMouseMove: updateSatLight,
                                                        style: { flexGrow: 1, height: '140px', background: `linear-gradient(to bottom, transparent, #000), linear-gradient(to right, #fff, hsl(${hue}, 100%, 50%))`, borderRadius: '6px', position: 'relative', border: '1px solid rgba(0,0,0,0.1)', cursor: 'crosshair' }
                                                    },
                                                        el('div', { style: { position: 'absolute', left: `${sat}%`, top: `${100 - light}%`, transform: 'translate(-50%, -50%)', width: '12px', height: '12px', border: '2px solid #fff', borderRadius: '50%', boxShadow: '0 0 3px rgba(0,0,0,0.5)', pointerEvents: 'none' } })
                                                    ),
                                                    el('div', {
                                                        onMouseDown: (e) => { isDraggingHue.current = true; updateHue(e); },
                                                        onMouseMove: updateHue,
                                                        style: { width: '20px', height: '140px', background: 'linear-gradient(to bottom, #f00, #ff0, #0f0, #0ff, #00f, #f0f, #f00)', borderRadius: '10px', position: 'relative', border: '1px solid rgba(0,0,0,0.1)', cursor: 'ns-resize' }
                                                    },
                                                        el('div', { style: { position: 'absolute', top: `${(hue / 360) * 100}%`, left: '-2px', right: '-2px', transform: 'translateY(-50%)', height: '8px', background: '#fff', borderRadius: '4px', boxShadow: '0 0 3px rgba(0,0,0,0.5)', pointerEvents: 'none' } })
                                                    )
                                                ),
                                                el('div', { style: { display: 'flex', gap: '12px', alignItems: 'center' } },
                                                    el('div', { style: { width: '36px', height: '36px', borderRadius: '4px', background: bgColor, border: '1px solid #ccd0d4', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' } }),
                                                    el('input', { type: 'text', value: bgColor.toUpperCase(), readOnly: true, style: { padding: '8px 12px', border: '1px solid #ccd0d4', borderRadius: '4px', width: '90px', fontSize: '13px', color: '#1d2327', background: '#f8f9fa', outline: 'none' } }),
                                                    el('div', { style: { display: 'flex', gap: '6px', marginLeft: 'auto' } },
                                                        ['R', 'G', 'B'].map((label, i) => {
                                                            const rgb = hexToRgb(bgColor);
                                                            const val = i === 0 ? rgb.r : i === 1 ? rgb.g : rgb.b;
                                                            return el('div', { key: i, style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' } },
                                                                el('input', { type: 'text', value: val, readOnly: true, style: { width: '38px', padding: '6px', border: '1px solid #ccd0d4', borderRadius: '4px', textAlign: 'center', fontSize: '12px', background: '#f8f9fa', outline: 'none' } }),
                                                                el('span', { style: { fontSize: '10px', color: '#8c8f94', fontWeight: 'bold' } }, label)
                                                            );
                                                        })
                                                    )
                                                )
                                            )
                                        )
                                        :
                                        el(ProFeaturePresentation, {
                                            description: "Custom Highlighter Color & Formatting",
                                            onClickOverride: () => setShowColorDemo(true),
                                            innerContent: el('div', { style: { display: 'flex', flexDirection: 'column', gap: '15px' } },
                                                el('div', { style: { display: 'flex', gap: '15px' } },
                                                    el('div', { style: { flexGrow: 1, height: '140px', borderRadius: '6px', background: `linear-gradient(to bottom, transparent, #000), linear-gradient(to right, #fff, ${bgColor})`, position: 'relative', boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.1)' } },
                                                        el('div', { style: { position: 'absolute', top: '25%', right: '25%', width: '12px', height: '12px', border: '2px solid #fff', borderRadius: '50%', boxShadow: '0 0 3px rgba(0,0,0,0.5)' } })
                                                    ),
                                                    el('div', { style: { width: '18px', height: '140px', borderRadius: '9px', background: 'linear-gradient(to bottom, #f00, #ff0, #0f0, #0ff, #00f, #f0f, #f00)', position: 'relative', boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.1)' } },
                                                        el('div', { style: { position: 'absolute', top: '45%', left: '-3px', right: '-3px', height: '8px', background: '#fff', borderRadius: '4px', boxShadow: '0 0 3px rgba(0,0,0,0.5)' } })
                                                    )
                                                )
                                            )
                                        }),

                                    el('hr', { style: { margin: '30px 0', border: 'none', borderTop: '1px solid #f0f0f1' } }),

                                    el('div', { style: { marginBottom: '30px' } },
                                        el('label', { style: labelStyle }, 'Trigger Delay (Seconds)'),
                                        el('input', { type: "number", value: delayTime, onChange: (e) => setDelayTime(e.target.value), step: "0.1", min: "0", style: { width: '100%', padding: '10px 12px', borderRadius: '6px', border: '1px solid #ccd0d4', fontSize: '14px', outline: 'none', background: '#fff', color: '#1d2327' } }),
                                        el('span', { style: { fontSize: '11px', color: '#8c8f94', marginTop: '4px', display: 'block' } }, "Use decimals (e.g., 0.5). Set to 0 to trigger instantly.")
                                    ),

                                    el('div', { style: { marginBottom: '30px' } },
                                        el('label', { style: labelStyle }, 'Display Frequency'),
                                        el('select', {
                                            value: freqType,
                                            onChange: (e) => setFreqType(e.target.value),
                                            style: { width: '100%', padding: '10px 12px', borderRadius: '6px', border: '1px solid #ccd0d4', fontSize: '14px', outline: 'none', background: '#fff', color: '#1d2327', WebkitAppearance: 'none', appearance: 'none' }
                                        },
                                            [{ label: 'Every visit', value: 'always' }, { label: 'Lifetime once', value: 'once' }, { label: 'After N Days', value: 'days' }, { label: 'After N Visits', value: 'visits' }].map(opt =>
                                                el('option', { key: opt.value, value: opt.value }, opt.label)
                                            )
                                        )
                                    ),

                                    (freqType === 'days' || freqType === 'visits') && el('div', { style: { marginBottom: '30px' } },
                                        el('label', { style: labelStyle }, `Number of ${freqType === 'days' ? 'Days' : 'Visits'}:`),
                                        el('input', { type: "number", value: freqValue, onChange: (e) => setFreqValue(parseInt(e.target.value) || 1), min: "1", style: { width: '100%', padding: '10px 12px', borderRadius: '6px', border: '1px solid #ccd0d4', fontSize: '14px', outline: 'none' } })
                                    ),

                                    isProActive ?
                                        el('div', { style: { marginBottom: '30px' } },
                                            el('label', { style: labelStyle }, 'Focus Mode (Attention-Forcing)'),
                                            el('div', { style: { display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', padding: '15px 20px', background: '#fff', border: '1px solid #ccd0d4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' }, onClick: () => setFocusMode(!focusMode) },
                                                el('div', { style: { width: '40px', height: '22px', background: focusMode ? '#007cba' : '#b5bcc2', borderRadius: '11px', position: 'relative', transition: 'background 0.2s' } },
                                                    el('div', { style: { width: '18px', height: '18px', background: '#fff', borderRadius: '50%', position: 'absolute', top: '2px', left: focusMode ? '20px' : '2px', boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'left 0.2s' } })
                                                ),
                                                el('span', { style: { fontSize: '14px', fontWeight: '600', color: '#1d2327' } }, "Activate Background Blur & Focus Mode")
                                            )
                                        )
                                        :
                                        el(ProFeaturePresentation, {
                                            onClickOverride: () => setShowFocusDemo(true),
                                            innerContent: el('div', { style: { display: 'flex', alignItems: 'center', gap: '10px' } },
                                                el('div', { style: { width: '36px', height: '20px', background: '#b5bcc2', borderRadius: '10px', position: 'relative' } },
                                                    el('div', { style: { width: '16px', height: '16px', background: '#fff', borderRadius: '50%', position: 'absolute', top: '2px', left: '2px', boxShadow: '0 1px 2px rgba(0,0,0,0.2)' } })
                                                ),
                                                el('span', { style: { fontSize: '13px', fontWeight: '600', color: '#1d2327' } }, "Activate Background Blur & Focus Mode")
                                            )
                                        }),

                                    el('div', { style: { display: 'flex', gap: '10px', marginTop: '10px' } },
                                        existingId && el(Button, {
                                            style: { background: '#d63638', color: '#ffffff', border: 'none', padding: '14px', fontSize: '15px', fontWeight: '600', borderRadius: '6px', flex: '1', justifyContent: 'center', transition: 'background 0.2s' },
                                            onClick: handleRemove
                                        }, 'Remove Highlighter'),

                                        el(Button, {
                                            isPrimary: true,
                                            disabled: isSaving || isFetchingLimits,
                                            style: { flex: existingId ? '2' : '1', justifyContent: 'center', padding: '14px', fontSize: '15px', fontWeight: '600', borderRadius: '6px' },
                                            onClick: handleSave,
                                            isBusy: isSaving || isFetchingLimits
                                        }, isSaving ? 'Deploying...' : 'Deploy Highlighter')
                                    )
                                )
                            ),

                            el('div', { style: { position: 'absolute', top: 0, bottom: 0, right: 0, width: '45%', overflowY: 'auto', background: '#f6f7f7', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', padding: '40px', boxSizing: 'border-box' } },
                                el('h4', { style: { margin: '0 0 35px 0', color: '#8c8f94', textTransform: 'uppercase', letterSpacing: '1.5px', fontSize: '11px', fontWeight: '700', flexShrink: 0 } }, 'Live Interface Preview'),
                                el('div', {
                                    className: 'vini-tooltip-preview-wrapper ss-live-preview-box',
                                    style: {
                                        position: 'relative',
                                        background: bgColor,
                                        color: textColor,
                                        padding: '14px 45px 12px 14px',
                                        borderRadius: '8px',
                                        boxShadow: '0 12px 30px rgba(0,0,0,0.15)',
                                        maxWidth: '100%',
                                        width: 'fit-content',
                                        boxSizing: 'border-box',
                                        fontSize: '14px',
                                        lineHeight: '1.5',
                                        wordWrap: 'break-word',
                                        transition: 'all 0.3s ease',
                                        flexShrink: 0
                                    }
                                },
                                    el('div', { className: 'ss-library-preview-text', dangerouslySetInnerHTML: { __html: noteText || 'Type your message on the left to see the magic happen...' } }),
                                    el('div', {
                                        className: 'scrollstrike-arrow',
                                        style: {
                                            position: 'absolute',
                                            bottom: '-14px',
                                            left: '50%',
                                            transform: 'translateX(-50%)',
                                            width: '0px',
                                            height: '0px',
                                            fontSize: '0px',
                                            lineHeight: '0px',
                                            boxSizing: 'content-box',
                                            borderLeft: '14px solid transparent',
                                            borderRight: '14px solid transparent',
                                            borderTop: `14px solid ${bgColor}`,
                                            zIndex: 10,
                                            pointerEvents: 'none',
                                            transition: 'border-top-color 0.3s ease'
                                        }
                                    }),
                                    el('span', { style: { position: 'absolute', top: '10px', right: '12px', fontSize: '14px', fontWeight: 'bold', color: getCloseIconColor(bgColor) } }, '✕')
                                )
                            )
                            
                        )
                )
            )
        );

      
       function renderLibraryCard(note, targetRef) {
            const badgeStyle = {
                background: '#f0f0f1', color: '#50575e', padding: '4px 10px', borderRadius: '4px',
                fontSize: '11px', fontWeight: '600', display: 'inline-block'
            };
            const isFocusMode = note.focus_mode == 1 ? 'On' : 'Off';
            const noteTier = note.tier || 'pro';
            const isLocked = !isProActive && (noteTier === 'pro');
            const displayId = (note.id || '').split('_')[1] || note.id;
            const currentBg = note.bg_color || '#fff1f1';
            const currentText = note.text_color || '#333333';

            return el('div', {
                key: note.id,
                ref: targetRef,
                className: 'ss-card simple-card',
                style: {
                    background: '#fff', 
                    border: '1px solid #ccd0d4', 
                    borderRadius: '8px',
                    padding: '20px', 
                    boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                    display: 'flex', 
                    flexDirection: 'column', 
                    overflow: 'visible',
                    minWidth: 0
                }
            },
                el('div', { 
                    style: { 
                        display: 'flex', 
                        justifyContent: 'center', 
                        width: '100%',
                        marginBottom: '15px' 
                    } 
                },
                    el('div', {
                        className: 'vini-content noTouch ss-preview',
                        style: {
                            position: 'relative', 
                            background: currentBg, 
                            color: currentText,
                            padding: '14px 45px 12px 14px', 
                            borderRadius: '8px',
                            boxShadow: '0 4px 12px rgba(0,0,0,0.08)', 
                            fontSize: '13px', 
                            lineHeight: '1.5',
                            width: 'fit-content',
                            maxWidth: '100%', 
                            boxSizing: 'border-box', 
                            overflow: 'visible', 
                            wordWrap: 'break-word',
                            display: 'inline-block'
                        }
                    },
                        el('span', { 
                            style: { 
                                position: 'absolute', 
                                top: '10px', 
                                right: '12px', 
                                fontSize: '14px', 
                                fontWeight: 'bold', 
                                color: getCloseIconColor(currentBg) 
                            } 
                        }, '✕'),
                        
                        el('div', {
                            className: 'ss-library-preview-text',
                            style: {
                                width: '100%', 
                                maxWidth: '100%', 
                                overflow: 'hidden', 
                                textOverflow: 'ellipsis',
                                display: '-webkit-box', 
                                WebkitLineClamp: 4, 
                                WebkitBoxOrient: 'vertical'
                            },
                            dangerouslySetInnerHTML: { __html: note.note_text }
                        }),
                        
                        el('div', {
                            className: 'scrollstrike-arrow',
                            style: {
                                position: 'absolute',
                                bottom: '-14px',
                                left: '50%',
                                transform: 'translateX(-50%)',
                                width: '0px',
                                height: '0px',
                                fontSize: '0px',
                                lineHeight: '0px',
                                boxSizing: 'content-box',
                                borderLeft: '14px solid transparent',
                                borderRight: '14px solid transparent',
                                borderTop: `14px solid ${currentBg}`,
                                zIndex: 10,
                                pointerEvents: 'none',
                                transition: 'border-top-color 0.3s ease'
                            }
                        })
                    )
                ),
                el('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: 'auto', paddingTop: '15px' } },
                    el('span', { style: badgeStyle }, `ID: ${displayId}`),
                    el('span', { style: badgeStyle }, `Delay: ${note.delay_time || 0}s`),
                    el('span', { style: badgeStyle }, `Freq: ${note.frequency_type || 'always'}`),
                    el('span', { style: badgeStyle }, `Blur: ${isFocusMode}`),
                    noteTier === 'pro' && el('span', { style: { ...badgeStyle, background: '#1d2327', color: '#fff' } }, 'PRO TIER')
                ),
                el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginTop: '15px' } },
                    el('button', {
                        onClick: isLocked ? (e) => { e.preventDefault(); setShowProUpgradeModal(true); } : () => handleUseTooltip(note),
                        title: isLocked ? 'Upgrade to PRO to use highlighter' : 'Use This Highlighter',
                        style: {
                            background: isLocked ? '#f0f0f1' : '#e3f2fd',
                            color: isLocked ? '#8c8f94' : '#0c63e4',
                            border: 'none', borderRadius: '20px',
                            padding: '6px 16px', fontSize: '12px', fontWeight: '700',
                            cursor: isLocked ? 'not-allowed' : 'pointer',
                            boxShadow: isLocked ? 'none' : '0 2px 4px rgba(12, 99, 228, 0.2)',
                            transition: 'all 0.2s ease'
                        },
                        onMouseEnter: isLocked ? null : (e) => { e.target.style.background = '#0c63e4'; e.target.style.color = '#fff'; },
                        onMouseLeave: isLocked ? null : (e) => { e.target.style.background = '#e3f2fd'; e.target.style.color = '#0c63e4'; }
                    }, 'Use This Highlighter')
                )
            );
        }

    };

    registerFormatType('scrollstrike/note', {
        title: 'ScrollStrike Trigger',
        tagName: 'mark',
        className: 'scrollstrike-trigger-word',
        attributes: { 'data-id': 'data-id' },
        edit: (props) => {
            const { isActive, value, onChange, activeAttributes } = props;
            const [isCanvasOpen, setIsCanvasOpen] = useState(false);
            const existingId = isActive ? activeAttributes['data-id'] : null;

            return el(Fragment, null,
                el(BlockControls, null, el(ToolbarGroup, null, el(ToolbarButton, { icon: "marker", title: "Attach ScrollStrike", isActive: isActive, onClick: () => setIsCanvasOpen(!isCanvasOpen) }))),
                isCanvasOpen && createPortal(el(ScrollStrikeStudioCanvas, { value: value, onChange: onChange, onClose: () => setIsCanvasOpen(false), existingId: existingId }), document.body)
            );
        }
    });

})(window.wp);