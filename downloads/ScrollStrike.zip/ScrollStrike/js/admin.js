var isProUser = (typeof ssAdminConfig !== 'undefined' && ssAdminConfig.is_pro === 'true');
var ajaxurl = (typeof ssAdminConfig !== 'undefined') ? ssAdminConfig.ajax_url : '';
var ssNonce = (typeof ssAdminConfig !== 'undefined') ? ssAdminConfig.nonce : '';

var ssGlobalLibrary = [];
var ssActiveAction = null;
var ssActiveId = null;

var ssDashOffset = 0;
var ssDashHasMore = true;
var ssDashIsLoading = false;
var ssDashSearchQuery = '';
var ssDashObserver = null;

var ssLibOffset = 0;
var ssLibHasMore = true;
var ssLibIsLoading = false;
var ssLibSearchQuery = '';
var ssLibObserver = null;

var ssModalOriginalHTML = '';

function ssDismissTierNotice() {
    var noticeBox = document.getElementById('ss-tier-notice');
    if (noticeBox) {
        noticeBox.style.display = 'none';
        jQuery.post(ajaxurl, {
            action: 'scrollstrike_dismiss_notice'
        });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    var modalShell = document.getElementById('ss-modal-content-shell');
    if (modalShell) {
        ssModalOriginalHTML = modalShell.innerHTML;
    }

    document.querySelectorAll('.ss-preset-btn[data-color]').forEach(function(btn) {
        var color = btn.getAttribute('data-color');
        if (color) {
            btn.style.backgroundColor = color;
        }
    });

    ssDashObserver = new IntersectionObserver(function(entries) {
        if (entries[0].isIntersecting && !ssDashIsLoading && ssDashHasMore) {
            ssLoadDashboardCards();
        }
    }, {
        root: document.getElementById('ss-admin-dashboard'),
        rootMargin: '0px',
        threshold: 0.1
    });

    var searchInput = document.getElementById('ss-search');
    var searchTimeout;
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            ssDashSearchQuery = this.value;
            searchTimeout = setTimeout(function() {
                ssLoadDashboardCards(true);
            }, 300);
        });
    }
});

// Listen for global gatekeeper resolution
document.addEventListener('scrollstrike_gatekeeper_resolved', function(e) {
    var previousTier = isProUser ? 'pro' : 'free';
    isProUser = (e.detail.tier === 'pro');

    var freeBadge = document.getElementById('ss-dashboard-free-badge');
    if (freeBadge) {
        if (isProUser) {
            freeBadge.classList.add('ss-hide');
            freeBadge.classList.remove('ss-show-inline');
        } else {
            freeBadge.classList.remove('ss-hide');
            freeBadge.classList.add('ss-show-inline');
        }
    }

    if (previousTier === 'free' && e.detail.tier === 'pro') {
        location.reload();
    } else {
        if (ssDashOffset === 0) {
            ssLoadDashboardCards(true);
        }
    }
});

function ssLoadDashboardCards(reset) {
    if (typeof reset === 'undefined') reset = false;
    if (reset) {
        ssDashOffset = 0;
        ssDashHasMore = true;
        document.getElementById('ss-grid-container').innerHTML = '';
    }
    if (!ssDashHasMore || ssDashIsLoading) return;

    ssDashIsLoading = true;
    var loader = document.getElementById('ss-dashboard-loader');
    if (loader) loader.classList.remove('ss-hide');

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_get_paginated_notes',
        nonce: ssNonce,
        offset: ssDashOffset,
        search: ssDashSearchQuery
    }, function(response) {
        ssDashIsLoading = false;
        if (loader) loader.classList.add('ss-hide');

        if (response.success && response.data) {
            var notes = response.data.notes;
            ssDashHasMore = response.data.has_more;
            var grid = document.getElementById('ss-grid-container');

            if (ssDashOffset === 0) {
                grid.innerHTML = '';
            }

            var oldTarget = grid.querySelector('.ss-lazy-trigger');
            if (oldTarget) oldTarget.classList.remove('ss-lazy-trigger');

            if (notes.length === 0 && ssDashOffset === 0) {
                grid.innerHTML = '<p class="ss-empty-placeholder">No highlighters found.</p>';
                return;
            }

            notes.forEach(function(note, index) {
                if (!ssGlobalLibrary.find(function(n) { return n.id === note.id; })) {
                    ssGlobalLibrary.push(note);
                }

                var div = document.createElement('div');
                div.innerHTML = createCardHTML(note);
                var newCard = div.firstElementChild;

                if (index === Math.max(0, notes.length - 6)) {
                    newCard.classList.add('ss-lazy-trigger');
                }

                grid.appendChild(newCard);
            });

            var newTarget = grid.querySelector('.ss-lazy-trigger');
            if (newTarget && ssDashHasMore) {
                ssDashObserver.observe(newTarget);
            }

            ssDashOffset += notes.length;
        }
    });
}

function createCardHTML(note) {
    var raw_text = note.note_text || '';
    var tmp = document.createElement('div');
    tmp.innerHTML = raw_text;
    var plain_text = (tmp.textContent || tmp.innerText || "").toLowerCase();

    var hasImage = /<img[^>]+>/i.test(raw_text) ? ' has-img' : '';

    var is_active = parseInt(note.is_active) === 1;
    var toggle_class = is_active ? 'ss-btn-deactivate' : 'ss-btn-activate';
    var toggle_text = is_active ? 'Deactivate' : 'Activate';

    var is_locked = (!isProUser && note.tier === 'pro');

    var focusText = parseInt(note.focus_mode) === 1 ? 'On' : 'Off';
    var delayText = parseFloat(note.delay_time || 0) + 's';
    var displayId = (note.id || '').split('_')[1] || note.id;

    var tierBadge = (note.tier === 'pro') ? "<span class='ss-badge ss-badge-tier-pro'>PRO TIER</span>" : "";
    var inactiveBadge = (!is_active) ? "<span class='ss-badge ss-dynamic-inactive ss-badge-inactive'>INACTIVE</span>" : "";

    return `
<div class='ss-card simple-card' data-text='${plain_text}' id='card_${note.id}'>
    <div class='ss-preview-wrapper'>
        <div class='ss-preview vini-content noTouch${hasImage}' style='position: relative; background: ${note.bg_color || '#fff1f1'}; color: ${note.text_color || '#333333'}; padding: 18px 25px 18px 20px; box-sizing: border-box;'>
            <span class="scrollstrike-close-btn" style="position: absolute; top: 10px; right: 12px; font-weight: bold; line-height: 1; font-family: Arial, sans-serif; color: ${getCloseIconColor(note.bg_color || '#fff1f1')}; pointer-events: none; z-index: 20;">✕</span>
            <div>${raw_text}</div>
            <div class='scrollstrike-arrow' style='border-top-color: ${note.bg_color || '#fff1f1'};'></div>
        </div>
    </div>
    <div class='ss-badges'>
        <span class='ss-badge'>ID: ${displayId}</span>
        <span class='ss-badge'>Delay: ${delayText}</span>
        <span class='ss-badge'>Freq: ${note.frequency_type || 'always'}</span>
        <span class='ss-badge'>Blur: ${focusText}</span>
        ${inactiveBadge}
        ${tierBadge}
    </div>
    <div class='ss-actions'>
        <button class='ss-btn ss-btn-pages' onclick="ssOpenLinkedPages('${note.id}')">Linked Pages</button>
        ${is_locked ? `<button class='ss-btn ss-btn-locked' onclick="ssOpenProUpgradeModal()" title="Upgrade to PRO to Edit">Edit</button>` 
                    : `<button class='ss-btn ss-btn-edit' onclick="ssOpenEditModal('${note.id}')">Edit</button>`}
        <button class='ss-btn ss-toggle-action-btn ${toggle_class}' onclick="ssOpenModal('toggle', '${note.id}', '${toggle_text}')">${toggle_text}</button>
        <button class='ss-btn ss-btn-delete' onclick="ssOpenModal('delete', '${note.id}', 'Delete')">Delete</button>
    </div>
</div>`;
}

function ssOpenModal(action, id, btnText) {
    ssActiveAction = action;
    ssActiveId = id;
    var modal = document.getElementById('ss-admin-modal');
    var modalShell = document.getElementById('ss-modal-content-shell');

    if (modalShell && ssModalOriginalHTML) {
        modalShell.innerHTML = ssModalOriginalHTML;
    }

    var title = document.getElementById('ss-modal-title');
    var text = document.getElementById('ss-modal-text');
    var confirmBtn = document.getElementById('ss-modal-confirm-btn');

    modal.classList.remove('ss-hide');
    modal.style.display = 'flex';

    if (action === 'delete_all') {
        title.innerText = 'Delete all highlighters permanently?';
        text.innerText = 'This will completely wipe your library. Any highlighted text on the frontend using any highlighter will instantly stop working. This cannot be undone.';
        confirmBtn.style.background = '#ef4444';
        confirmBtn.innerText = 'Yes, Delete All';
    } else if (action === 'delete') {
        title.innerText = 'Delete Highlighter permanently?';
        text.innerText = 'This will remove the highlighter from your library. Any highlighted text on the frontend using this ID will stop working.';
        confirmBtn.style.background = '#ef4444';
        confirmBtn.innerText = 'Yes, Delete';
    } else {
        title.innerText = btnText + ' this Highlighter?';
        text.innerText = btnText === 'Deactivate' ? 'It will remain in your library, but will stop showing up on the frontend until reactivated.' : 'It will instantly become live on the frontend again.';
        confirmBtn.style.background = btnText === 'Deactivate' ? '#ea580c' : '#2563eb';
        confirmBtn.innerText = 'Yes, ' + btnText;
    }
    confirmBtn.onclick = ssExecuteAction;
}

function ssCloseModal() {
    var modal = document.getElementById('ss-admin-modal');
    modal.classList.add('ss-hide');
    modal.style.display = 'none';
}

function ssExecuteAction() {
    var targetAction = 'scrollstrike_admin_toggle';
    var processingMessage = 'Processing context, please wait...';

    if (ssActiveAction === 'delete') {
        targetAction = 'scrollstrike_admin_delete';
        processingMessage = 'Deleting highlighter, please wait...';
    } else if (ssActiveAction === 'delete_all') {
        targetAction = 'scrollstrike_admin_delete_all';
        processingMessage = 'Clearing entire library, please wait...';
    } else if (ssActiveAction === 'toggle') {
        var currentCard = document.getElementById('card_' + ssActiveId);
        if (currentCard) {
            var toggleBtn = currentCard.querySelector('.ss-toggle-action-btn');
            if (toggleBtn && toggleBtn.innerText === 'Deactivate') {
                processingMessage = 'Deactivating highlighter, please wait...';
            } else {
                processingMessage = 'Activating highlighter, please wait...';
            }
        }
    }

    var modalShell = document.getElementById('ss-modal-content-shell');
    if (modalShell) {
        modalShell.innerHTML = `
            <div class="ss-modal-processing-box">
                <div class="ss-modal-spinner"></div>
                <p class="ss-modal-processing-text">${processingMessage}</p>
            </div>`;
    }

    jQuery.post(ajaxurl, {
        action: targetAction,
        nonce: ssNonce,
        id: ssActiveId
    }, function(response) {
        if (response.success) {
            ssCloseModal();

            if (ssActiveAction === 'delete_all') {
                ssGlobalLibrary = [];
                ssDashOffset = 0;
                ssDashHasMore = false;

                var gridContainer = document.getElementById('ss-grid-container');
                if (gridContainer) {
                    gridContainer.innerHTML = '<p class="ss-empty-placeholder">No highlighters found.</p>';
                }

                var freeBadge = document.getElementById('ss-dashboard-free-badge');
                if (freeBadge) {
                    freeBadge.innerText = 'Free Tier: 0/3 Free Highlighters Used';
                    freeBadge.className = 'ss-badge ss-badge-warning ' + (isProUser ? 'ss-hide' : 'ss-show-inline');
                }
                return;
            }

            var cardNode = document.getElementById('card_' + ssActiveId);
            if (ssActiveAction === 'delete' && cardNode) {
                ssGlobalLibrary = ssGlobalLibrary.filter(function(item) {
                    return item.id !== ssActiveId;
                });

                cardNode.style.transition = 'all 0.3s ease';
                cardNode.style.opacity = '0';
                cardNode.style.transform = 'scale(0.9)';
                setTimeout(function() {
                    cardNode.remove();
                    var gridContainer = document.getElementById('ss-grid-container');
                    if (gridContainer && gridContainer.children.length === 0) {
                        gridContainer.innerHTML = '<p class="ss-empty-placeholder">No highlighters found.</p>';
                    }
                }, 300);

                if (response.data && typeof response.data.free_count !== 'undefined') {
                    var freeBadge = document.getElementById('ss-dashboard-free-badge');
                    if (freeBadge) {
                        var displayCount = Math.min(response.data.free_count, 3);
                        var badgeStateClass = (response.data.free_count >= 3) ? 'ss-badge-limit' : 'ss-badge-warning';
                        var badgeVisClass = isProUser ? 'ss-hide' : 'ss-show-inline';

                        freeBadge.innerText = 'Free Tier: ' + displayCount + '/3 Free Highlighters Used';
                        freeBadge.className = `ss-badge ${badgeStateClass} ${badgeVisClass}`;
                    }
                }
            } else if (ssActiveAction === 'toggle' && cardNode) {
                var badgeContainer = cardNode.querySelector('.ss-badges');
                var actionButton = cardNode.querySelector('.ss-toggle-action-btn');

                if (actionButton.classList.contains('ss-btn-deactivate')) {
                    actionButton.className = 'ss-btn ss-toggle-action-btn ss-btn-activate';
                    actionButton.innerText = 'Activate';
                    actionButton.setAttribute('onclick', `ssOpenModal('toggle', '${ssActiveId}', 'Activate')`);

                    if (badgeContainer && !badgeContainer.querySelector('.ss-dynamic-inactive')) {
                        var inactiveSpan = document.createElement('span');
                        inactiveSpan.className = 'ss-badge ss-dynamic-inactive ss-badge-inactive';
                        inactiveSpan.innerText = 'INACTIVE';
                        badgeContainer.appendChild(inactiveSpan);
                    }
                } else {
                    actionButton.className = 'ss-btn ss-toggle-action-btn ss-btn-deactivate';
                    actionButton.innerText = 'Deactivate';
                    actionButton.setAttribute('onclick', `ssOpenModal('toggle', '${ssActiveId}', 'Deactivate')`);

                    if (badgeContainer) {
                        var inactiveSpan = badgeContainer.querySelector('.ss-dynamic-inactive');
                        if (inactiveSpan) inactiveSpan.remove();
                    }
                }
            }
        } else {
            alert(response.data || 'Error occurred');
            ssCloseModal();
        }
    });
}

function ssOpenProUpgradeModal() {
    var modal = document.getElementById('ss-pro-upgrade-modal');
    modal.classList.remove('ss-hide');
    modal.style.display = 'flex';
}

function ssCloseProUpgradeModal() {
    var modal = document.getElementById('ss-pro-upgrade-modal');
    modal.classList.add('ss-hide');
    modal.style.display = 'none';
}

function getCloseIconColor(hex) {
    if (!hex) return 'rgba(0,0,0,0.4)';
    var cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) cleanHex = cleanHex.split('').map(function(c) { return c + c; }).join('');
    var r = parseInt(cleanHex.substring(0, 2), 16) || 0;
    var g = parseInt(cleanHex.substring(2, 4), 16) || 0;
    var b = parseInt(cleanHex.substring(4, 6), 16) || 0;
    var yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    return (yiq >= 128) ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.8)';
}

function hslToHex(h, s, l) {
    l /= 100;
    var a = s * Math.min(l, 1 - l) / 100;
    var f = function(n) {
        var k = (n + h / 30) % 12;
        var color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
        return Math.round(255 * color).toString(16).padStart(2, '0');
    };
    return '#' + f(0) + f(8) + f(4);
}

function hexToRgb(hex) {
    var cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) cleanHex = cleanHex.split('').map(function(c) { return c + c; }).join('');
    var r = parseInt(cleanHex.substring(0, 2), 16) || 0;
    var g = parseInt(cleanHex.substring(2, 4), 16) || 0;
    var b = parseInt(cleanHex.substring(4, 6), 16) || 0;
    return { r: r, g: g, b: b };
}

function rgb2hex(rgb) {
    if (!rgb) return '';
    var match = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    if (!match) return rgb;

    function hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + hex(match[1]) + hex(match[2]) + hex(match[3]);
}

function ssToggleFreqVal() {
    var type = document.getElementById('edit_freq_type').value;
    var container = document.getElementById('edit_freq_val_container');
    if (type === 'days' || type === 'visits') {
        container.classList.remove('ss-hide');
    } else {
        container.classList.add('ss-hide');
    }
}

function ssToggleFocus() {
    var valObj = document.getElementById('edit_focus');
    var bg = document.getElementById('ss-focus-toggle-bg');
    var knob = document.getElementById('ss-focus-toggle-knob');
    if (valObj.value === '1') {
        valObj.value = '0';
        bg.style.background = '#94a3b8';
        knob.style.left = '2px';
    } else {
        valObj.value = '1';
        bg.style.background = '#2563eb';
        knob.style.left = '20px';
    }
}

function ssSetPresetColor(hex, el) {
    hex = hex.toUpperCase();
    document.getElementById('edit_bg').value = hex;

    if (document.getElementById('edit_text_color')) {
        document.getElementById('edit_text_color').value = '#ffffff';
    }

    document.querySelectorAll('.ss-preset-btn').forEach(function(p) {
        p.classList.remove('is-active');
    });

    if (el) {
        el.classList.add('is-active');
    }

    if (isProUser && typeof ssSetColorFromHex === 'function') {
        ssSetColorFromHex(hex);
    } else {
        ssUpdatePreview();
    }
}

function ssUpdateTextHex(hex) {
    if (!isProUser) return;
    var display = document.getElementById('edit_text_color_display');
    if (display) display.innerText = hex.toUpperCase();
}

var cpState = {
    hue: 0,
    sat: 100,
    light: 50,
    isSatDragging: false,
    isHueDragging: false
};

function ssSyncColorPickerUI() {
    if (!isProUser) return;
    var bg = document.getElementById('edit_bg').value;
    var satBox = document.getElementById('ss-color-picker-sat-box');
    var ptr = document.getElementById('ss-color-picker-pointer');
    var hueBox = document.getElementById('ss-color-picker-hue-box');
    var hPtr = document.getElementById('ss-color-picker-hue-pointer');
    var prev = document.getElementById('ss-color-picker-preview');

    satBox.style.background = 'linear-gradient(to bottom, transparent, #000), linear-gradient(to right, #fff, hsl(' + cpState.hue + ', 100%, 50%))';
    ptr.style.left = cpState.sat + '%';
    ptr.style.top = (100 - cpState.light) + '%';
    hPtr.style.top = (cpState.hue / 360 * 100) + '%';
    prev.style.background = bg;

    var rgb = hexToRgb(bg);
    var rInp = document.getElementById('edit_r_val');
    var gInp = document.getElementById('edit_g_val');
    var bInp = document.getElementById('edit_b_val');
    if (rInp) rInp.value = rgb.r;
    if (gInp) gInp.value = rgb.g;
    if (bInp) bInp.value = rgb.b;

    ssUpdatePreview();
}

function ssSetColorFromHex(hex) {
    if (!isProUser) return;
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(function(c) { return c + c; }).join('');
    var r = (parseInt(hex.substring(0, 2), 16) || 0) / 255;
    var g = (parseInt(hex.substring(2, 4), 16) || 0) / 255;
    var b = (parseInt(hex.substring(4, 6), 16) || 0) / 255;
    var cmax = Math.max(r, g, b),
        cmin = Math.min(r, g, b);
    var delta = cmax - cmin;
    var h = 0,
        s = 0,
        l = (cmax + cmin) / 2;
    if (delta !== 0) {
        if (cmax === r) h = ((g - b) / delta) % 6;
        else if (cmax === g) h = (b - r) / delta + 2;
        else h = (r - g) / delta + 4;
        s = delta / (1 - Math.abs(2 * l - 1));
    }
    h = Math.round(h * 60);
    if (h < 0) h += 360;
    cpState.hue = h;
    cpState.sat = s * 100;
    cpState.light = l * 100;
    ssSyncColorPickerUI();
}

function ssStartSatDrag(e) {
    cpState.isSatDragging = true;
    ssUpdateSatColor(e);
}

function ssStartHueDrag(e) {
    cpState.isHueDragging = true;
    ssUpdateHueColor(e);
}

function ssUpdateSatColor(e) {
    if (!cpState.isSatDragging) return;
    var box = document.getElementById('ss-color-picker-sat-box').getBoundingClientRect();
    var x = Math.max(0, Math.min(e.clientX - box.left, box.width));
    var y = Math.max(0, Math.min(e.clientY - box.top, box.height));
    cpState.sat = (x / box.width) * 100;
    cpState.light = 100 - ((y / box.height) * 100);
    document.getElementById('edit_bg').value = hslToHex(cpState.hue, cpState.sat, cpState.light).toUpperCase();
    ssSyncColorPickerUI();
}

function ssUpdateHueColor(e) {
    if (!cpState.isHueDragging) return;
    var box = document.getElementById('ss-color-picker-hue-box').getBoundingClientRect();
    var y = Math.max(0, Math.min(e.clientY - box.top, box.height));
    cpState.hue = (y / box.height) * 360;
    document.getElementById('edit_bg').value = hslToHex(cpState.hue, cpState.sat, cpState.light).toUpperCase();
    ssSyncColorPickerUI();
}

window.addEventListener('mousemove', function(e) {
    if (cpState.isSatDragging) ssUpdateSatColor(e);
    if (cpState.isHueDragging) ssUpdateHueColor(e);
});
window.addEventListener('mouseup', function() {
    cpState.isSatDragging = false;
    cpState.isHueDragging = false;
});

function ssFetchLibraryNotes(reset) {
    if (reset) {
        ssLibOffset = 0;
        ssLibHasMore = true;
        var grid = document.getElementById('ss-library-attach-grid');
        if (grid) grid.innerHTML = '';
    }

    if (!ssLibHasMore || ssLibIsLoading) return;

    ssLibIsLoading = true;
    var grid = document.getElementById('ss-library-attach-grid');

    if (ssLibOffset === 0 && grid) {
        grid.innerHTML = '<p class="ss-empty-placeholder">Loading highlighters...</p>';
    }

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_get_paginated_notes',
        nonce: ssNonce,
        offset: ssLibOffset,
        search: ssLibSearchQuery
    }, function(response) {
        ssLibIsLoading = false;

        if (response.success && response.data) {
            var notes = response.data.notes;
            ssLibHasMore = response.data.has_more;

            if (ssLibOffset === 0 && grid) {
                grid.innerHTML = '';
            }

            if (notes.length === 0 && ssLibOffset === 0) {
                grid.innerHTML = '<p class="ss-empty-placeholder">No highlighters found in library.</p>';
                return;
            }

            var oldTarget = grid.querySelector('.ss-lib-lazy-trigger');
            if (oldTarget) oldTarget.classList.remove('ss-lib-lazy-trigger');

            notes.forEach(function(note, index) {
                if (!ssGlobalLibrary.find(function(n) { return n.id === note.id; })) {
                    ssGlobalLibrary.push(note);
                }

                var isFocusMode = note.focus_mode == 1 ? 'On' : 'Off';
                var noteTier = note.tier || 'pro';
                var isLocked = !isProUser && (noteTier === 'pro');
                var displayId = (note.id || '').split('_')[1] || note.id;
                var hasImage = /<img[^>]+>/i.test(note.note_text || '') ? ' has-img' : '';

                var isTriggerNode = (index === Math.max(0, notes.length - 4));
                var triggerClass = isTriggerNode ? ' ss-lib-lazy-trigger' : '';

                var cardHTML = `
        <div class="ss-card simple-card${triggerClass}">
            <div class="ss-preview-wrapper">
                <div class="vini-content noTouch${hasImage} ss-live-preview-box" style="background:${note.bg_color || '#fff1f1'}; color:${note.text_color || '#333333'};">
                    <span class="scrollstrike-close-btn" style="position:absolute; top:8px; right:10px; font-weight:bold; line-height:1; font-family:Arial, sans-serif; color:${getCloseIconColor(note.bg_color || '#fff1f1')}; z-index:20; pointer-events:none;">✕</span>
                    <div class="ss-library-preview-text">${note.note_text}</div>
                    <div class="scrollstrike-arrow" style="border-top-color: ${note.bg_color || '#fff1f1'};"></div>
                </div>
            </div>

            <div class="ss-badges">
                <span class="ss-badge">ID: ${displayId}</span>
                <span class="ss-badge">Delay: ${note.delay_time || 0}s</span>
                <span class="ss-badge">Freq: ${note.frequency_type || 'always'}</span>
                <span class="ss-badge">Blur: ${isFocusMode}</span>
                ${noteTier === 'pro' ? '<span class="ss-badge ss-badge-tier-pro">PRO TIER</span>' : ''}
            </div>

            <div class="ss-actions">
                ${isLocked 
                    ? `<button onclick="ssOpenProUpgradeModal()" class="ss-btn ss-btn-locked" title="Upgrade to PRO to use">Use This Highlighter</button>`
                    : `<button onclick="ssImportSettings('${note.id}')" class="ss-btn ss-btn-pages">Use This Settings</button>`
                }
            </div>
        </div>`;

                grid.insertAdjacentHTML('beforeend', cardHTML);
            });

            if (ssLibObserver) ssLibObserver.disconnect();

            ssLibObserver = new IntersectionObserver(function(entries) {
                if (entries[0].isIntersecting && !ssLibIsLoading && ssLibHasMore) {
                    ssFetchLibraryNotes(false);
                }
            }, {
                root: document.getElementById('ss-library-container'),
                threshold: 0.1
            });

            var newTarget = grid.querySelector('.ss-lib-lazy-trigger');
            if (newTarget && ssLibHasMore) {
                ssLibObserver.observe(newTarget);
            }

            ssLibOffset += notes.length;
        }
    });
}

var ssLibSearchTimeout;

function ssFilterLibraryAttach() {
    clearTimeout(ssLibSearchTimeout);
    var input = document.getElementById('ss-library-search');
    ssLibSearchQuery = input ? input.value : '';

    ssLibSearchTimeout = setTimeout(function() {
        ssFetchLibraryNotes(true);
    }, 300);
}

function ssImportSettings(id) {
    var note = ssGlobalLibrary.find(function(n) {
        return n.id === id;
    });
    if (!note) return;

    document.getElementById('edit_bg').value = note.bg_color || '#fff1f1';
    var textCol = note.text_color || '#333333';
    if (document.getElementById('edit_text_color')) {
        document.getElementById('edit_text_color').value = textCol;
    }

    if (isProUser && typeof ssUpdateTextHex === 'function') {
        ssUpdateTextHex(textCol);
    }

    document.getElementById('edit_delay').value = note.delay_time || 0;
    document.getElementById('edit_freq_type').value = note.frequency_type || 'always';
    document.getElementById('edit_freq_val').value = note.frequency_value || 1;
    ssToggleFreqVal();

    if (isProUser) {
        var focusObj = document.getElementById('edit_focus');
        var bg = document.getElementById('ss-focus-toggle-bg');
        var knob = document.getElementById('ss-focus-toggle-knob');
        if (focusObj && bg && knob) {
            if (note.focus_mode == 1) {
                focusObj.value = '1';
                bg.style.background = '#2563eb';
                knob.style.left = '20px';
            } else {
                focusObj.value = '0';
                bg.style.background = '#94a3b8';
                knob.style.left = '2px';
            }
        }
        if (typeof ssSetColorFromHex === 'function') {
            ssSetColorFromHex(note.bg_color || '#fff1f1');
        }
    }

    ssInitViniEditor(note.note_text);
    ssUpdatePreview();
    ssSwitchTab('edit');
}

function ssSwitchTab(tab) {
    document.getElementById('ss-tab-edit').className = tab === 'edit' ? 'ss-studio-tab-btn active' : 'ss-studio-tab-btn inactive';
    document.getElementById('ss-tab-library').className = tab === 'library' ? 'ss-studio-tab-btn active' : 'ss-studio-tab-btn inactive';

    var editContainer = document.getElementById('ss-edit-container');
    var libContainer = document.getElementById('ss-library-container');

    if (tab === 'edit') {
        editContainer.classList.remove('ss-hide');
        editContainer.style.display = 'flex';
        libContainer.classList.add('ss-hide');
        libContainer.style.display = 'none';
    } else {
        editContainer.classList.add('ss-hide');
        editContainer.style.display = 'none';
        libContainer.classList.remove('ss-hide');
        libContainer.style.display = 'block';
        ssFetchLibraryNotes(true);
    }
}

var ssActiveEditorCanvas = null;

function ssInitViniEditor(initialContent) {
    var container = document.getElementById('scrollstrike-new-rte-container');
    if (!container) return;

    container.innerHTML = '';
    initViniRichText('scrollstrike-new-rte-container');

    ssActiveEditorCanvas = container.querySelector('.vini-content');

    if (ssActiveEditorCanvas && initialContent) {
        ssActiveEditorCanvas.innerHTML = initialContent;
    }

    if (ssActiveEditorCanvas) {
        ssActiveEditorCanvas.addEventListener('input', ssUpdatePreview);
        ssActiveEditorCanvas.addEventListener('keyup', ssUpdatePreview);
    }

    container.addEventListener('click', function(e) {
        var colorSwatch = e.target.closest('[data-color], .vini-color-swatch');
        if (colorSwatch) {
            var selectedColor = colorSwatch.getAttribute('data-color') || colorSwatch.style.backgroundColor;
            if (selectedColor) {
                var hexColor = rgb2hex(selectedColor);
                var input = document.getElementById('edit_text_color');
                if (input) input.value = hexColor;
                ssUpdatePreview();
            }
        }
    });

    ssUpdatePreview();
}

function ssUpdatePreview() {
    var bg = document.getElementById('edit_bg') ? document.getElementById('edit_bg').value : '#fff1f1';
    var textCol = document.getElementById('edit_text_color') ? document.getElementById('edit_text_color').value : '#333333';

    var toolbarColorIndicator = document.querySelector('#scrollstrike-new-rte-container .vini-color-preview') ||
        document.querySelector('#scrollstrike-new-rte-container [data-command="foreColor"]');
    if (toolbarColorIndicator) {
        toolbarColorIndicator.style.backgroundColor = textCol;
        toolbarColorIndicator.style.borderColor = textCol;
    }

    if (ssActiveEditorCanvas) {
        ssActiveEditorCanvas.style.backgroundColor = bg;
        ssActiveEditorCanvas.style.color = textCol;
    }

    var previewBox = document.getElementById('ss-live-preview-box');
    var previewContent = document.getElementById('ss-live-preview-content');
    var contentHTML = '';

    if (ssActiveEditorCanvas && previewContent) {
        contentHTML = ssActiveEditorCanvas.innerHTML.trim();
        previewContent.innerHTML = (contentHTML !== '' && contentHTML !== '<p><br></p>') ?
            contentHTML :
            'Type your message on the left to see the magic happen...';
    }

    var hasImage = /<img[^>]+>/i.test(contentHTML);

    if (previewBox) {
        previewBox.style.backgroundColor = bg;
        previewBox.style.color = textCol;
        previewBox.style.width = hasImage ? '100%' : 'max-content';
        previewBox.style.maxWidth = '450px';
    }
    var arrow = document.getElementById('ss-live-preview-arrow');
    if (arrow) arrow.style.borderTopColor = bg;

    var closeBtn = document.getElementById('ss-live-preview-close');
    if (closeBtn) closeBtn.style.color = getCloseIconColor(bg);
}

window.ssUpdatePreview = ssUpdatePreview;

function ssOpenEditModal(id) {
    var note = ssGlobalLibrary.find(function(n) {
        return n.id === id;
    });
    if (!note) return;

    var bgHex = note.bg_color || '#fff1f1';

    document.getElementById('edit_id').value = id;
    document.getElementById('edit_bg').value = bgHex;

    var textCol = note.text_color || '#333333';
    if (document.getElementById('edit_text_color')) {
        document.getElementById('edit_text_color').value = textCol;
    }

    document.getElementById('edit_delay').value = note.delay_time || 0;
    document.getElementById('edit_freq_type').value = note.frequency_type || 'always';
    document.getElementById('edit_freq_val').value = note.frequency_value || 1;
    ssToggleFreqVal();

    ssInitViniEditor(note.note_text);

    if (isProUser && typeof ssSetColorFromHex === 'function') {
        ssSetColorFromHex(bgHex);
    } else {
        ssUpdatePreview();
    }

    var cleanSavedHex = bgHex.toLowerCase();
    document.querySelectorAll('.ss-preset-btn').forEach(function(btn) {
        var btnColor = (btn.getAttribute('data-color') || '').toLowerCase();
        if (btnColor === cleanSavedHex) {
            btn.classList.add('is-active');
        } else {
            btn.classList.remove('is-active');
        }
    });

    ssSwitchTab('edit');
    var studioModal = document.getElementById('ss-studio-modal');
    studioModal.classList.remove('ss-hide');
    studioModal.style.display = 'flex';
}

function ssCloseEditModal() {
    var studioModal = document.getElementById('ss-studio-modal');
    studioModal.classList.add('ss-hide');
    studioModal.style.display = 'none';
    var container = document.getElementById('scrollstrike-new-rte-container');
    if (container) container.innerHTML = '';
    ssActiveEditorCanvas = null;
}

function ssSaveLibraryEdit() {
    var btn = document.getElementById('edit_save_btn');
    btn.innerText = 'Deploying...';
    btn.style.opacity = '0.7';

    var id = document.getElementById('edit_id').value;
    var textContent = ssActiveEditorCanvas ? ssActiveEditorCanvas.innerHTML : '';
    var bgColor = document.getElementById('edit_bg').value;
    var textColor = document.getElementById('edit_text_color') ? document.getElementById('edit_text_color').value : '#333333';
    var delay = document.getElementById('edit_delay').value;
    var freqType = document.getElementById('edit_freq_type').value;
    var freqVal = document.getElementById('edit_freq_val').value;
    var focusMode = document.getElementById('edit_focus').value === '1';

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_admin_save_edit',
        nonce: ssNonce,
        id: id,
        note_text: textContent,
        bg_color: bgColor,
        text_color: textColor,
        delay_time: delay,
        frequency_type: freqType,
        frequency_value: freqVal,
        focus_mode: focusMode ? 'true' : 'false'
    }, function(response) {
        if (response.success) {
            var updatedTier = (response.data && response.data.tier) ? response.data.tier : (focusMode ? 'pro' : 'free');

            var noteToUpdate = ssGlobalLibrary.find(function(n) {
                return n.id === id;
            });
            if (noteToUpdate) {
                noteToUpdate.note_text = textContent;
                noteToUpdate.bg_color = bgColor;
                noteToUpdate.text_color = textColor;
                noteToUpdate.delay_time = delay;
                noteToUpdate.frequency_type = freqType;
                noteToUpdate.frequency_value = freqVal;
                noteToUpdate.focus_mode = focusMode ? 1 : 0;
                noteToUpdate.tier = updatedTier;
            }

            var cardNode = document.getElementById('card_' + id);
            if (cardNode && noteToUpdate) {
                var tempContainer = document.createElement('div');
                tempContainer.innerHTML = createCardHTML(noteToUpdate);
                var updatedCardContent = tempContainer.firstElementChild;

                if (updatedCardContent) {
                    cardNode.innerHTML = updatedCardContent.innerHTML;
                }
            }

            btn.innerText = 'Save Settings';
            btn.style.opacity = '1';
            ssCloseEditModal();
        } else {
            alert(response.data || 'Error saving');
            btn.innerText = 'Save Settings';
            btn.style.opacity = '1';
        }
    });
}

var ssLinkedId = null;
var ssLinkedOffset = 0;
var ssLinkedLoading = false;
var ssLinkedHasMore = true;
var ssLinkedObserver = null;

function ssOpenLinkedPages(id) {
    ssLinkedId = id;
    ssLinkedOffset = 0;
    ssLinkedHasMore = true;
    document.getElementById('ss-linked-pages-content').innerHTML = '';
    
    var modal = document.getElementById('ss-linked-pages-modal');
    modal.classList.remove('ss-hide');
    modal.style.display = 'flex';

    if (ssLinkedObserver) ssLinkedObserver.disconnect();
    ssLinkedObserver = new IntersectionObserver(function(entries) {
        if (entries[0].isIntersecting && !ssLinkedLoading && ssLinkedHasMore) {
            ssFetchLinkedPages();
        }
    }, {
        root: document.getElementById('ss-linked-pages-content'),
        threshold: 0.1
    });

    ssFetchLinkedPages();
}

function ssCloseLinkedPages() {
    var modal = document.getElementById('ss-linked-pages-modal');
    modal.classList.add('ss-hide');
    modal.style.display = 'none';
    if (ssLinkedObserver) ssLinkedObserver.disconnect();
}

function ssFetchLinkedPages() {
    if (ssLinkedLoading || !ssLinkedHasMore) return;
    ssLinkedLoading = true;
    var loader = document.getElementById('ss-linked-pages-loader');
    if (loader) loader.classList.remove('ss-hide');

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_get_paginated_notes',
        nonce: ssNonce,
        tooltip_id: ssLinkedId,
        offset: ssLinkedOffset
    }, function(response) {
        ssLinkedLoading = false;
        if (loader) loader.classList.add('ss-hide');

        if (response.success) {
            var pages = response.data.pages || [];
            ssLinkedHasMore = response.data.has_more;
            var container = document.getElementById('ss-linked-pages-content');

            var oldTarget = container.querySelector('.ss-scroll-trigger-node');
            if (oldTarget) oldTarget.classList.remove('ss-scroll-trigger-node');

            if (pages.length === 0 && ssLinkedOffset === 0) {
                container.innerHTML = '<div class="ss-empty-placeholder">Not deployed on any pages yet. Open the block editor to attach this highlighter.</div>';
                return;
            }

            pages.forEach(function(page, index) {
                var div = document.createElement('div');
                div.className = 'ss-linked-page-item';
                div.innerHTML = '<a href="' + page.url + '" target="_blank" class="ss-linked-page-link">' + page.title + '</a><span class="ss-linked-page-date">Deployed: ' + page.date + '</span>';

                if (index === 9) div.classList.add('ss-scroll-trigger-node');
                container.appendChild(div);
            });

            var newTarget = container.querySelector('.ss-scroll-trigger-node');
            if (newTarget && ssLinkedHasMore) {
                ssLinkedObserver.observe(newTarget);
            }

            ssLinkedOffset += pages.length;
        }
    });
}


/* =========================================================================
   PAGES SYSTEM HANDLERS (UPGRADE, ACCOUNT, SUPPORT)
   ========================================================================= */
window.ssConfirmed = false;

document.addEventListener('DOMContentLoaded', function() {
    // Upgrade Form Submission
    var upgradeForm = document.getElementById('ss-upgrade-form');
    if (upgradeForm) {
        upgradeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var existingKey = (typeof ssAdminConfig !== 'undefined' && ssAdminConfig.existing_key) ? ssAdminConfig.existing_key : '';

            if (existingKey.trim() !== '' && !window.ssConfirmed) {
                var modal = document.getElementById('ss-overwrite-modal');
                if (modal) {
                    modal.classList.remove('ss-hide');
                    modal.style.display = 'flex';
                }
            } else {
                processLicenseVerification();
            }
        });
    }

    // Fast-track resolution check on initial load
    if (typeof window.scrollstrike_is_processing !== 'undefined' && window.scrollstrike_is_processing === false) {
        var event = new CustomEvent('scrollstrike_gatekeeper_resolved', {
            detail: { tier: window.scrollstrike_global_tier }
        });
        document.dispatchEvent(event);
    }
});

// Listener for Universal Gatekeeper state synchronization
document.addEventListener('scrollstrike_gatekeeper_resolved', function(e) {
    var currentTier = e.detail.tier;

    // 1. Upgrade Page Sync
    var banner = document.getElementById('ss-tier-status-banner');
    var loader = document.getElementById('ss-localized-loader');
    var matrix = document.getElementById('ss-features-matrix-grid');
    var packagesGrid = document.getElementById('ss-licensing-packages-section');
    var freeCurrentStrip = document.getElementById('ss-free-current-strip');
    var proCurrentStrip = document.getElementById('ss-pro-current-strip');

    if (banner) {
        var proText = (typeof ssAdminConfig !== 'undefined' && ssAdminConfig.i18n) ? ssAdminConfig.i18n.pro_active : 'You are in PRO Version';
        var freeText = (typeof ssAdminConfig !== 'undefined' && ssAdminConfig.i18n) ? ssAdminConfig.i18n.free_active : 'You are in FREE Version';

        if (currentTier === 'pro') {
            banner.innerHTML = '<span class="ss-text-pro">' + proText + '</span>';
            if (freeCurrentStrip) freeCurrentStrip.classList.add('ss-hide');
            if (proCurrentStrip) proCurrentStrip.classList.remove('ss-hide');

            if (packagesGrid) {
                packagesGrid.classList.add('ss-hide', 'ss-opacity-0');
                packagesGrid.classList.remove('ss-show-block', 'ss-opacity-1');
            }
        } else {
            banner.innerHTML = '<span class="ss-text-free">' + freeText + '</span>';
            if (freeCurrentStrip) freeCurrentStrip.classList.remove('ss-hide');
            if (proCurrentStrip) proCurrentStrip.classList.add('ss-hide');

            if (packagesGrid) {
                packagesGrid.classList.remove('ss-hide');
                packagesGrid.classList.add('ss-show-block');
                setTimeout(function() {
                    packagesGrid.classList.remove('ss-opacity-0');
                    packagesGrid.classList.add('ss-opacity-1');
                }, 50);
            }
        }
    }

    if (loader) {
        loader.style.opacity = '0';
        setTimeout(function() { loader.remove(); }, 300);
    }
    if (matrix) {
        matrix.classList.remove('ss-opacity-0');
        matrix.classList.add('ss-opacity-1');
    }

    // 2. Account Page Sync
    var accountGatekeeper = document.getElementById('ss-account-gatekeeper');
    var accountFree = document.getElementById('ss-account-free');
    var accountPro = document.getElementById('ss-account-pro');

    if (accountFree && accountPro) {
        if (currentTier === 'pro') {
            accountFree.classList.add('ss-hide');
            accountPro.classList.remove('ss-hide');
            ssFetchPlanDetails();
        } else {
            accountPro.classList.add('ss-hide');
            accountFree.classList.remove('ss-hide');
        }
    }

    if (accountGatekeeper) {
        accountGatekeeper.style.opacity = '0';
        setTimeout(function() { accountGatekeeper.remove(); }, 300);
    }
});

function ssToggleKeyVisibility() {
    var input = document.getElementById('ss_license_input_field');
    var trigger = document.getElementById('ss_toggle_visibility_trigger');
    if (!input || !trigger) return;

    if (input.type === 'password') {
        input.type = 'text';
        trigger.classList.remove('dashicons-visibility');
        trigger.classList.add('dashicons-hidden');
    } else {
        input.type = 'password';
        trigger.classList.remove('dashicons-hidden');
        trigger.classList.add('dashicons-visibility');
    }
}

function ssCloseOverwriteModal() {
    var modal = document.getElementById('ss-overwrite-modal');
    if (modal) {
        modal.classList.add('ss-hide');
        modal.style.display = 'none';
    }
    window.ssConfirmed = false;
}

function confirmOverwrite() {
    window.ssConfirmed = true;
    ssCloseOverwriteModal();
    processLicenseVerification();
}

function processLicenseVerification() {
    var keyField = document.getElementById('ss_license_input_field');
    var keyInput = keyField ? keyField.value.trim() : '';
    if (!keyInput) return;

    var btn = document.getElementById('ss-submit-btn');
    btn.innerText = 'Activating...';
    btn.style.opacity = '0.7';
    btn.disabled = true;

    var container = document.getElementById('ss-top-card');
    var gatekeeper = null;

    if (container) {
        gatekeeper = document.createElement('div');
        gatekeeper.id = 'ss-local-gatekeeper';
        gatekeeper.className = 'ss-gatekeeper-loader-wrap';
        var authText = (typeof ssAdminConfig !== 'undefined' && ssAdminConfig.i18n) ? ssAdminConfig.i18n.authenticating : 'Authenticating...';
        gatekeeper.innerHTML = '<div class="ss-gatekeeper-spinner"></div><h3 class="ss-gatekeeper-title">' + authText + '</h3>';
        container.appendChild(gatekeeper);
    }

    var upgradeNonce = (typeof ssAdminConfig !== 'undefined') ? ssAdminConfig.upgrade_nonce : '';
    var verifyNonce = (typeof ssAdminConfig !== 'undefined') ? ssAdminConfig.verify_nonce : '';

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_activate_license_ajax',
        nonce: upgradeNonce,
        ss_license_key: keyInput
    }, function(response) {
        if (response.success) {
            jQuery.post(ajaxurl, {
                action: 'scrollstrike_unified_gatekeeper_check',
                nonce: verifyNonce
            }, function(verifyRes) {
                if (verifyRes.success) {
                    var event = new CustomEvent('scrollstrike_gatekeeper_resolved', { detail: verifyRes.data });
                    document.dispatchEvent(event);

                    if (verifyRes.data.tier === 'pro') {
                        showToast('<strong>Success:</strong> License code verified and registered! Welcome to PRO.', 'success');
                    } else {
                        showToast('<strong>Error:</strong> The license key is invalid, expired, or refunded.', 'error');
                    }
                } else {
                    showToast('<strong>Error:</strong> Failed to reach verification server.', 'error');
                }
                cleanupLoader(gatekeeper, btn);
            }).fail(function() {
                showToast('<strong>Error:</strong> Failed to communicate with key verification server.', 'error');
                cleanupLoader(gatekeeper, btn);
            });
        } else {
            showToast('<strong>Error:</strong> Failed to save key to the database.', 'error');
            cleanupLoader(gatekeeper, btn);
        }
    }).fail(function() {
        showToast('<strong>Error:</strong> Network connection failed.', 'error');
        cleanupLoader(gatekeeper, btn);
    });
}

function cleanupLoader(gatekeeper, btn) {
    if (gatekeeper) {
        gatekeeper.style.opacity = '0';
        setTimeout(function() { gatekeeper.remove(); }, 300);
    }
    btn.innerText = 'Activate';
    btn.style.opacity = '1';
    btn.disabled = false;
    window.ssConfirmed = false;
}

function showToast(message, type) {
    var noticeContainer = document.getElementById('ss-upgrade-ajax-notice');
    if (!noticeContainer) return;

    var toastClass = type === 'success' ? 'ss-toast-success' : 'ss-toast-error';
    noticeContainer.innerHTML = '<div class="ss-toast-notice ' + toastClass + '"><p>' + message + '</p></div>';

    setTimeout(function() {
        if (noticeContainer.firstChild) {
            noticeContainer.firstChild.style.opacity = '0';
            setTimeout(function() { noticeContainer.innerHTML = ''; }, 300);
        }
    }, 5000);
}

function ssFetchPlanDetails() {
    var accountNonce = (typeof ssAdminConfig !== 'undefined') ? ssAdminConfig.account_nonce : '';
    jQuery.post(ajaxurl, {
        action: 'scrollstrike_get_subscription_details',
        nonce: accountNonce
    }, function(response) {
        if (response.success && response.data) {
            document.getElementById('ss-pro-email').innerText = response.data.email;
            document.getElementById('ss-sub-expiry').innerText = response.data.expiry_date;
            document.getElementById('ss-pro-name').innerText = response.data.product_name;
            document.getElementById('ss-sub-start').innerText = response.data.start_date;
        } else {
            document.getElementById('ss-sub-expiry').innerText = 'Data Error';
        }
    });
}

function ssOpenDowngradeModal() {
    var modal = document.getElementById('ss-downgrade-modal');
    if (modal) {
        modal.classList.remove('ss-hide');
        modal.style.display = 'flex';
    }
}

function ssCloseDowngradeModal() {
    var modal = document.getElementById('ss-downgrade-modal');
    if (modal) {
        modal.classList.add('ss-hide');
        modal.style.display = 'none';
    }
}

function ssExecuteDowngrade() {
    var btn = document.getElementById('ss-confirm-downgrade-btn');
    btn.innerText = 'Downgrading...';
    btn.style.opacity = '0.7';
    btn.disabled = true;

    var modalShell = document.getElementById('ss-downgrade-modal-shell');
    var originalModalHTML = modalShell.innerHTML;
    var downgradeMsg = (typeof ssAdminConfig !== 'undefined' && ssAdminConfig.i18n) ? ssAdminConfig.i18n.downgrading : 'Processing workspace downgrade, please wait...';

    modalShell.innerHTML = `
        <div class="ss-modal-processing-box">
            <div class="ss-modal-spinner"></div>
            <p class="ss-modal-processing-text">${downgradeMsg}</p>
        </div>
    `;

    var accountNonce = (typeof ssAdminConfig !== 'undefined') ? ssAdminConfig.account_nonce : '';

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_downgrade_to_free_ajax',
        nonce: accountNonce
    }, function(response) {
        if (response.success) {
            window.scrollstrike_global_tier = 'free';
            var event = new CustomEvent('scrollstrike_gatekeeper_resolved', { detail: { tier: 'free' } });
            document.dispatchEvent(event);
            
            ssCloseDowngradeModal();
            modalShell.innerHTML = originalModalHTML;
        } else {
            alert(response.data || 'Failed to downgrade product space.');
            modalShell.innerHTML = originalModalHTML;
            ssCloseDowngradeModal();
        }
    }).fail(function() {
        alert('Network timeout error occurred.');
        modalShell.innerHTML = originalModalHTML;
        ssCloseDowngradeModal();
    });
}

function ssToggleFaq(button) {
    var item = button.parentElement;
    var icon = button.querySelector('.ss-faq-icon');
    var isActive = item.classList.contains('active');

    var container = item.closest('.ss-faq-category-block');
    var siblings = container.querySelectorAll('.ss-faq-item');
    siblings.forEach(function(el) {
        el.classList.remove('active');
        var itemIcon = el.querySelector('.ss-faq-icon');
        if (itemIcon) itemIcon.innerText = '+';
    });

    if (!isActive) {
        item.classList.add('active');
        if (icon) icon.innerText = '−';
    } else {
        if (icon) icon.innerText = '+';
    }
}

function ssShowMore(button) {
    var container = button.closest('.ss-faq-category-block');
    var hiddenItems = container.querySelectorAll('.ss-faq-item.ss-hidden-faq');

    hiddenItems.forEach(function(el) {
        el.classList.remove('ss-hidden-faq');
    });

    var containerWrapper = button.parentElement;
    if (containerWrapper) {
        containerWrapper.classList.add('ss-hide');
    }
}


// Universal Gatekeeper Verification Lifecycle
document.addEventListener('DOMContentLoaded', function () {
    var config = window.ssAdminConfig || {};

    if (config.session_tier) {
        window.scrollstrike_is_processing = false;
        window.scrollstrike_global_tier = config.session_tier;

        document.dispatchEvent(new CustomEvent('scrollstrike_gatekeeper_resolved', {
            detail: { tier: window.scrollstrike_global_tier }
        }));
        return;
    }

    window.scrollstrike_is_processing = true;
    window.scrollstrike_global_tier = 'pending';

    var container = document.getElementById('ss-admin-dashboard') || document.getElementById('ss-top-card') || document.getElementById('ss-account-container');
    var gatekeeper = null;

    if (container) {
        container.classList.add('ss-auth-pending');
        if (window.getComputedStyle(container).position === 'static') {
            container.classList.add('ss-relative');
        }
        gatekeeper = document.createElement('div');
        gatekeeper.id = 'ss-localized-loader';
        gatekeeper.className = 'ss-gatekeeper-loader-wrap';
        gatekeeper.innerHTML = '<div class="ss-gatekeeper-spinner"></div><h3 class="ss-gatekeeper-title">Authenticating Workspace...</h3>';
        container.appendChild(gatekeeper);
    }

    var ajaxurl = config.ajax_url || (typeof window.ajaxurl !== 'undefined' ? window.ajaxurl : '');

    jQuery.post(ajaxurl, {
        action: 'scrollstrike_unified_gatekeeper_check',
        nonce: config.verify_nonce
    }).done(function (response) {
        window.scrollstrike_is_processing = false;
        window.scrollstrike_global_tier = (response.success && response.data && response.data.tier) ? response.data.tier : 'free';
    }).fail(function () {
        window.scrollstrike_is_processing = false;
        window.scrollstrike_global_tier = 'free';
    }).always(function () {
        document.dispatchEvent(new CustomEvent('scrollstrike_gatekeeper_resolved', {
            detail: { tier: window.scrollstrike_global_tier }
        }));

        if (container) {
            container.classList.remove('ss-auth-pending');
        }

        if (gatekeeper) {
            gatekeeper.style.opacity = '0';
            setTimeout(function () {
                if (gatekeeper.parentNode) gatekeeper.remove();
            }, 300);
        }
    });
});