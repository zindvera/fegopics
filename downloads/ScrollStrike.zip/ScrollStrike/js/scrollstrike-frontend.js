document.addEventListener("DOMContentLoaded", function () {
    const triggers = document.querySelectorAll('.scrollstrike-trigger-word');

    // If there are no trigger words on the page at all, we can safely exit.
    if (triggers.length === 0) return;

    // Securely load database variables, defaulting to empty arrays if all tooltips were deleted.
    let notesData = [];
    let isPro = false;

    if (typeof scrollstrike_data !== 'undefined' && scrollstrike_data.notes) {
        notesData = scrollstrike_data.notes;
        // BUG FIX: WordPress localize_script converts true to "1". We must check for both!
        isPro = scrollstrike_data.is_pro === true || scrollstrike_data.is_pro === '1';
    }

    // --- HELPER: Close Icon Color Contrast ---
    const getCloseIconColor = (hex) => {
        if (!hex) return 'rgba(0,0,0,0.4)';
        let cleanHex = hex.replace('#', '');
        if (cleanHex.length === 3) cleanHex = cleanHex.split('').map(c => c + c).join('');
        const r = parseInt(cleanHex.substring(0, 2), 16);
        const g = parseInt(cleanHex.substring(2, 4), 16);
        const b = parseInt(cleanHex.substring(4, 6), 16);
        const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
        return (yiq >= 128) ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.8)';
    };

    // --- LOGIC: Behavioral Frequency Checks (Gap Engine) ---
    const evaluateBehavioralRules = (note, trackingKey) => {
        const now = Date.now();

        const freqType = note.frequency_type || 'always';
        const freqVal = parseInt(note.frequency_value) || 1;

        const lastSeen = localStorage.getItem(`ss_last_seen_${trackingKey}`);
        const gapCount = parseInt(localStorage.getItem(`ss_gap_${trackingKey}`) || '0');

        // Rule: Lifetime once
        if (freqType === 'once' && lastSeen) return 'HIDE';

        // Rule: After [N] days
        if (freqType === 'days' && lastSeen) {
            const daysPassed = (now - parseInt(lastSeen)) / (1000 * 60 * 60 * 24);
            if (daysPassed < freqVal) return 'HIDE';
        }

        // Rule: After [N] visits (Gap interval)
        if (freqType === 'visits' && lastSeen) {
            if (gapCount < freqVal) {
                return 'GAP'; // In cool-down phase. Hide it, but count this as a gap visit.
            }
        }

        // Rule: 'always' naturally falls through to return SHOW.
        return 'SHOW';
    };

    const markAsViewed = (trackingKey) => {
        localStorage.setItem(`ss_last_seen_${trackingKey}`, Date.now());
        localStorage.setItem(`ss_gap_${trackingKey}`, '0'); // Reset gap counter on show
    };

    const incrementGap = (trackingKey) => {
        const gapCount = parseInt(localStorage.getItem(`ss_gap_${trackingKey}`) || '0');
        localStorage.setItem(`ss_gap_${trackingKey}`, gapCount + 1);
    };

    const handleDismiss = (tooltipWrapper, triggerEl, focusMode) => {
        tooltipWrapper.style.opacity = '0';
        tooltipWrapper.style.pointerEvents = 'none';

        if (isPro && focusMode == 1) {
            triggerEl.classList.remove('ss-focus-active');
            document.body.classList.remove('ss-blur-enabled'); // Disables frontend blur instantly
            const overlay = document.getElementById('ss-focus-overlay');
            if (overlay) overlay.style.opacity = '0';
            setTimeout(() => {
                if (overlay) overlay.remove();
                tooltipWrapper.remove();
            }, 400);
        } else {
            setTimeout(() => tooltipWrapper.remove(), 400);
        }
    };

    // --- LOGIC: Intersection Observer (Scroll Trigger) ---
    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const triggerEl = entry.target;
                const id = triggerEl.getAttribute('data-id');
                const placementIndex = triggerEl.getAttribute('data-placement-index');
                const pagePath = window.location.pathname;

                // Create the ultra-specific tracking key: TooltipID + PagePath + Index
                const trackingKey = `${id}_${pagePath}_${placementIndex}`;

                const note = notesData.find(n => n.id === id);

                if (note) {
                    const ruleStatus = evaluateBehavioralRules(note, trackingKey);

                    if (ruleStatus === 'SHOW') {
                        renderTooltip(triggerEl, note);
                        markAsViewed(trackingKey);
                    } else if (ruleStatus === 'GAP') {
                        incrementGap(trackingKey);
                    }
                }

                // Unobserve instantly to ensure we only process 1 gap/view per page session
                obs.unobserve(triggerEl);
            }
        });
    }, { threshold: 0.5 });

 
  // --- UI: Render Tooltip ---
    const renderTooltip = (triggerEl, note) => {
        const localDelayAttr = triggerEl.getAttribute('data-local-delay');
        const delay = localDelayAttr !== null ? parseFloat(localDelayAttr) : (parseFloat(note.delay_time) || 0);

        setTimeout(() => {
            // Detect if note HTML contains an image tag
            const hasImage = /<img\b[^>]*>/i.test(note.note_text || '');

            const tooltip = document.createElement('div');
            tooltip.className = 'scrollstrike-tooltip-box' + (hasImage ? ' has-img' : '');
            tooltip.style.backgroundColor = note.bg_color || '#fff1f1';
            tooltip.style.color = note.text_color || '#333333';

            const closeBtn = document.createElement('span');
            closeBtn.className = 'scrollstrike-close-btn';
            closeBtn.innerHTML = '✕';
            closeBtn.style.color = getCloseIconColor(note.bg_color);
            closeBtn.onclick = (e) => {
                e.stopPropagation();
                handleDismiss(tooltip, triggerEl, note.focus_mode);
            };

            const content = document.createElement('div');
            content.className = 'scrollstrike-content vini-content';
            content.innerHTML = note.note_text;

            const arrow = document.createElement('div');
            arrow.className = 'scrollstrike-arrow';
            
            // Set initial colors for both regular (top border) and flipped (bottom border) states
            const dynamicBg = note.bg_color || '#fff1f1';
            arrow.style.borderTopColor = dynamicBg;
            arrow.style.borderBottomColor = dynamicBg;

            // --- RE-ADDED APPEND CALLS TO ENSURE ARROW RENDERS ---
            tooltip.appendChild(closeBtn);
            tooltip.appendChild(content);
            tooltip.appendChild(arrow); 
            triggerEl.appendChild(tooltip);

            if (isPro && note.focus_mode == 1) {
                let overlay = document.getElementById('ss-focus-overlay');
                if (!overlay) {
                    overlay = document.createElement('div');
                    overlay.id = 'ss-focus-overlay';
                    document.body.appendChild(overlay);
                }
                void overlay.offsetWidth;
                overlay.style.opacity = '1';
                triggerEl.classList.add('ss-focus-active');
                document.body.classList.add('ss-blur-enabled');
            }

          requestAnimationFrame(() => {
                // 1. FREEZE ANIMATIONS to calculate perfect viewport math
                tooltip.style.transition = 'none';

                // 2. Snap to center baseline
                tooltip.style.transform = 'translateX(-50%) translateY(0)';

                // 3. Force browser layout calculation instantly
                void tooltip.offsetWidth;

                const rect = tooltip.getBoundingClientRect();
                const triggerRect = triggerEl.getBoundingClientRect();
                const viewportWidth = document.documentElement.clientWidth;

                // --- NEW VERTICAL FLIP DETECTOR ---
                const spaceOnTop = rect.top;
                const dynamicBgColor = note.bg_color || '#fff1f1';

                if (spaceOnTop < 10) {
                    tooltip.classList.add('ss-flipped');

                    const flippedArrow = tooltip.querySelector('.scrollstrike-arrow');
                    if (flippedArrow) {
                        flippedArrow.style.borderBottomColor = dynamicBgColor;
                    }
                }

                // Safety margins from left/right edges of viewports (16px buffer)
                const screenMargin = 16;
                let shift = 0;

                // 4. Calculate precise structural clipping limits (clamps both left & right edges)
                if (rect.right > viewportWidth - screenMargin) {
                    shift = rect.right - (viewportWidth - screenMargin);
                }
                if (rect.left - shift < screenMargin) {
                    shift = rect.left - screenMargin;
                }

                const finalTransformX = `calc(-50% - ${shift}px)`;

                // --- ACCURATE ARROW POINTER ALIGNMENT ---
                // Calculate the exact center of the trigger word relative to the rendered tooltip
                const triggerCenter = triggerRect.left + (triggerRect.width / 2);
                const tooltipLeft = rect.left - shift;
                const arrowTargetX = triggerCenter - tooltipLeft;

                // Position the arrow dynamically so it points dead center to the target word
                arrow.style.left = `${arrowTargetX}px`;
                arrow.style.transform = 'translateX(-50%)';

                // 5. Check current orientation state to set right directional pop animation
                const isFlipped = tooltip.classList.contains('ss-flipped');
                const startY = isFlipped ? '-10px' : '10px';

                // 6. Pre-set starting animation bounds
                tooltip.style.transform = `translateX(${finalTransformX}) translateY(${startY})`;

                // 7. Force repaint to lock coordinates
                void tooltip.offsetWidth;

                // 8. RESTORE ANIMATIONS and trigger final pop-in
                tooltip.style.transition = 'opacity 0.4s ease, transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                tooltip.style.transform = `translateX(${finalTransformX}) translateY(0)`;
                tooltip.style.opacity = '1';
            });

        }, delay * 1000);
    };
    
    // --- DOM INITIALIZATION & AUTO-CLEANUP ENGINE ---
    let activeElementsRendered = 0; // Counter tracking site page placements

    triggers.forEach((trigger, index) => {
        const id = trigger.getAttribute('data-id');
        const noteExists = notesData.some(n => n.id === id);

        // AUTO-CLEANUP & ELEMENT CAPPING ENFORCEMENT: 
        // 1. If the tooltip was deleted from the library, noteExists is false.
        // 2. NEW CAP: If user is on the Free tier and we have already processed 3 valid highlights,
        // treat any subsequent highlights as deleted, safely unwrapping them back to standard paragraph text.
        if (!noteExists || (!isPro && activeElementsRendered >= 3)) {
            const fragment = document.createDocumentFragment();
            while (trigger.firstChild) {
                fragment.appendChild(trigger.firstChild);
            }
            trigger.parentNode.replaceChild(fragment, trigger);
            return; // Exit out, successfully discarding this element slot
        }

        // Increment counter since it is a valid, allowed free highlight allocation
        activeElementsRendered++;

        // Assign the placement index to the element
        trigger.setAttribute('data-placement-index', index);

        observer.observe(trigger);
    });
});