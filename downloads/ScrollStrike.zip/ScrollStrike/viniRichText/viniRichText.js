/**
 * viniRichText.js
 * Modular Rich Text Editor script for WordPress
 */

function initViniRichText(targetId, options = {}) {
  const targetEl = document.getElementById(targetId);
  if (!targetEl) return;

  const __ = (typeof wp !== 'undefined' && wp.i18n && wp.i18n.__) ? wp.i18n.__ : (text) => text;

  targetEl.innerHTML = `
    <div class="vini-editor">
      <div class="vini-toolbar">
        <div class="vini-toolbar-group">
          <button type="button" class="vini-icon-btn" data-command="bold" title="Bold"><b>B</b></button>
          <button type="button" class="vini-icon-btn" data-command="italic" title="Italic"><i>I</i></button>
          <button type="button" class="vini-icon-btn" data-command="underline" title="Underline"><u>U</u></button>
        </div>

        <div class="vini-toolbar-divider"></div>

        <div class="vini-toolbar-group">
          <label for="vini-font-size" class="vini-label">${__('Font Size', 'scrollstrike')}</label>
          <input type="number" id="vini-font-size" class="vini-num-input" value="16" min="8" max="120" placeholder="16">
        </div>

        <div class="vini-toolbar-divider"></div>

        <div class="vini-toolbar-group">
          <label for="vini-font-color" class="vini-label">${__('Font Color', 'scrollstrike')}</label>
          <div class="vini-color-wrapper">
            <input type="color" id="vini-font-color" class="vini-color-picker" value="#1e293b">
          </div>
        </div>

        <div class="vini-toolbar-divider"></div>

        <div class="vini-toolbar-group">
          <button type="button" class="vini-text-action" id="vini-img-btn">
            <svg class="vini-action-svg" viewBox="0 0 24 24">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21 15 16 10 5 21"/>
            </svg>
            ${__('Upload Image', 'scrollstrike')}
          </button>
        </div>
      </div>

      <div class="vini-content" contenteditable="true" data-placeholder="${__('Start typing your rich content here...', 'scrollstrike')}"></div>

      <!-- Draggable Image Settings Modal -->
      <div class="vini-modal vini-hidden" id="vini-img-modal">
        <div class="vini-modal-header" id="vini-img-modal-header">
          <span>${__('IMAGE SETTINGS', 'scrollstrike')}</span>
          <button type="button" class="vini-modal-close" id="vini-img-modal-close">✕</button>
        </div>

        <div class="vini-field-group">
          <label>Size (Width %) <span id="vini-img-size-val">100%</span></label>
          <input type="range" id="vini-img-size-slider" min="8" max="100" value="100">
        </div>

        <div class="vini-field-group">
          <label>Alignment</label>
          <div class="vini-toggle-btns" id="vini-img-align-group">
            <button type="button" class="vini-toggle-btn active" data-align="left">Left</button>
            <button type="button" class="vini-toggle-btn" data-align="center">Center</button>
            <button type="button" class="vini-toggle-btn" data-align="right">Right</button>
          </div>
        </div>

        <div class="vini-field-group">
          <label>Top Space <span id="vini-img-top-val">14px</span></label>
          <input type="range" id="vini-img-top-slider" min="0" max="80" value="14">
        </div>

        <div class="vini-field-group">
          <label>Bottom Space <span id="vini-img-bottom-val">14px</span></label>
          <input type="range" id="vini-img-bottom-slider" min="0" max="80" value="14">
        </div>

        <button type="button" class="vini-delete-btn" id="vini-img-delete-btn">${__('Remove This Image', 'scrollstrike')}</button>
      </div>
    </div>
  `;

  // References
  const editorContent = targetEl.querySelector('.vini-content');
  const fontColorInput = targetEl.querySelector('#vini-font-color');

  // Dynamic helper method to update canvas background, text color, and toolbar picker
  targetEl.setCanvasColors = function (bgColor, textColor) {
    if (editorContent) {
      if (bgColor) editorContent.style.backgroundColor = bgColor;
      if (textColor) editorContent.style.color = textColor;
    }
    if (fontColorInput && textColor) {
      fontColorInput.value = textColor;
    }
  };

  // Set initial canvas colors from options or fallbacks
  const initBg = options.bgColor || '#ffffff';
  const initColor = options.textColor || '#1e293b';
  targetEl.setCanvasColors(initBg, initColor);

  // Force browser contenteditable to create uniform <p> tags on Enter
  document.execCommand('defaultParagraphSeparator', false, 'p');

  const formatButtons = targetEl.querySelectorAll('.vini-icon-btn[data-command]');
  const fontSizeInput = targetEl.querySelector('#vini-font-size');
  const imgBtn = targetEl.querySelector('#vini-img-btn');

  // Image Modal References
  const imgModal = targetEl.querySelector('#vini-img-modal');
  const imgModalHeader = targetEl.querySelector('#vini-img-modal-header');
  const imgModalClose = targetEl.querySelector('#vini-img-modal-close');
  const imgSizeSlider = targetEl.querySelector('#vini-img-size-slider');
  const imgSizeVal = targetEl.querySelector('#vini-img-size-val');
  const imgAlignBtns = targetEl.querySelectorAll('#vini-img-align-group .vini-toggle-btn');
  const imgTopSlider = targetEl.querySelector('#vini-img-top-slider');
  const imgTopVal = targetEl.querySelector('#vini-img-top-val');
  const imgBottomSlider = targetEl.querySelector('#vini-img-bottom-slider');
  const imgBottomVal = targetEl.querySelector('#vini-img-bottom-val');
  const imgDeleteBtn = targetEl.querySelector('#vini-img-delete-btn');

  let activeSelectedImg = null;
  let activeStyledSpan = null;

  // --- Lightweight Undo / Redo Manager ---
  let historyStack = [];
  let historyStep = -1;
  const maxHistory = 30;

  function saveState() {
    if (historyStep < historyStack.length - 1) {
      historyStack = historyStack.slice(0, historyStep + 1);
    }
    historyStack.push(editorContent.innerHTML);
    if (historyStack.length > maxHistory) {
      historyStack.shift();
    } else {
      historyStep++;
    }
    updatePreviews();
  }

  function undo() {
    if (historyStep > 0) {
      historyStep--;
      editorContent.innerHTML = historyStack[historyStep];
      updatePreviews();
    }
  }

  function redo() {
    if (historyStep < historyStack.length - 1) {
      historyStep++;
      editorContent.innerHTML = historyStack[historyStep];
      updatePreviews();
    }
  }

  setTimeout(saveState, 100);

  function rgbToHex(rgb) {
    if (!rgb) return '#2563eb';
    const res = rgb.match(/\d+/g);
    if (!res) return rgb;
    return "#" + res.slice(0, 3).map(x => (+x).toString(16).padStart(2, '0')).join('');
  }

  function makeDraggable(modalEl, handleEl) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handleEl.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
      if (e.target.classList.contains('vini-modal-close')) return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;
      modalEl.style.top = (modalEl.offsetTop - pos2) + "px";
      modalEl.style.left = (modalEl.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }

  makeDraggable(imgModal, imgModalHeader);

  function centerModal(modalEl) {
    modalEl.style.top = "50%";
    modalEl.style.left = "50%";
    modalEl.style.transform = "translate(-50%, -50%)";
  }

  fontSizeInput.addEventListener('mousedown', (e) => e.stopPropagation());
  fontColorInput.addEventListener('mousedown', (e) => e.stopPropagation());

  fontSizeInput.addEventListener('focus', () => {
    setTimeout(() => fontSizeInput.select(), 0);
    captureSelectionSpan();
  });

  function captureSelectionSpan() {
    const sel = window.getSelection();
    if (!sel.rangeCount || sel.isCollapsed) return;

    const range = sel.getRangeAt(0);
    if (!editorContent.contains(range.commonAncestorContainer)) return;

    let parentSpan = range.commonAncestorContainer;
    if (parentSpan.nodeType === 3) parentSpan = parentSpan.parentElement;

    if (parentSpan && parentSpan.tagName === 'SPAN' && parentSpan !== editorContent) {
      activeStyledSpan = parentSpan;
      activeStyledSpan.classList.add('vini-active-selection');
    } else {
      const span = document.createElement('span');
      span.className = 'vini-active-selection';
      try {
        range.surroundContents(span);
        activeStyledSpan = span;
      } catch (e) { }
    }
  }

  fontSizeInput.addEventListener('input', () => {
    const rawVal = fontSizeInput.value.replace(/[^0-9]/g, '');
    if (!rawVal) return;
    const val = rawVal + 'px';

    if (activeStyledSpan) {
      activeStyledSpan.style.fontSize = val;
      saveState();
    } else {
      document.execCommand('fontSize', false, '7');
      const fontSpans = editorContent.querySelectorAll('font[size="7"]');
      fontSpans.forEach(span => {
        span.removeAttribute('size');
        span.style.fontSize = val;
      });
      saveState();
    }
  });

  fontColorInput.addEventListener('input', () => {
    const color = fontColorInput.value;
    if (activeStyledSpan) {
      activeStyledSpan.style.color = color;
      saveState();
    } else {
      document.execCommand('foreColor', false, color);
      saveState();
    }
  });

  function syncToolbarState() {
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount) {
      if (document.activeElement !== fontSizeInput) fontSizeInput.value = 16;
      return;
    }

    let node = sel.anchorNode;
    if (!node || !editorContent.contains(node)) {
      if (document.activeElement !== fontSizeInput) fontSizeInput.value = 16;
      return;
    }

    if (node.nodeType === 3) node = node.parentElement;

    formatButtons.forEach(btn => {
      const cmd = btn.getAttribute('data-command');
      const isActive = document.queryCommandState(cmd);
      btn.classList.toggle('is-active', isActive);
    });

    if (node && node !== editorContent) {
      const computedStyle = window.getComputedStyle(node);
      const computedSize = parseInt(computedStyle.fontSize, 10);
      const computedColor = rgbToHex(computedStyle.color);

      if (document.activeElement !== fontSizeInput) fontSizeInput.value = computedSize || 16;
      if (computedColor && document.activeElement !== fontColorInput) fontColorInput.value = computedColor;
    } else {
      if (document.activeElement !== fontSizeInput) fontSizeInput.value = 16;
    }
  }

  editorContent.addEventListener('keyup', syncToolbarState);
  editorContent.addEventListener('mouseup', syncToolbarState);
  editorContent.addEventListener('click', syncToolbarState);

  editorContent.addEventListener('mousedown', () => {
    if (activeStyledSpan) {
      activeStyledSpan.classList.remove('vini-active-selection');
      activeStyledSpan = null;
    }
  });

  // KEYDOWN INTERCEPTOR
  editorContent.addEventListener('keydown', function (e) {
    const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    const ctrlCmd = isMac ? e.metaKey : e.ctrlKey;

    if (ctrlCmd && (e.key === 'z' || e.key === 'Z')) {
      e.preventDefault();
      if (e.shiftKey) {
        redo();
      } else {
        undo();
      }
      return;
    }

    if (ctrlCmd && (e.key === 'y' || e.key === 'Y')) {
      e.preventDefault();
      redo();
      return;
    }

    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    let currentNode = selection.anchorNode;
    if (currentNode.nodeType === 3) {
      currentNode = currentNode.parentNode;
    }

    if (e.key === 'Enter') {
      const blockWrapper = (currentNode === editorContent) ? null : currentNode.closest('.vini-img-wrapper');
      if (blockWrapper) {
        e.preventDefault();

        const range = selection.getRangeAt(0);
        const isLeftSide = (range.startOffset === 0);

        const newP = document.createElement('p');
        newP.style.textAlign = 'left';
        newP.innerHTML = '<br>';

        if (isLeftSide) {
          blockWrapper.before(newP);
          const newRange = document.createRange();
          newRange.setStart(blockWrapper, 0);
          newRange.collapse(true);
          selection.removeAllRanges();
          selection.addRange(newRange);
        } else {
          blockWrapper.after(newP);
          const newRange = document.createRange();
          newRange.setStart(newP, 0);
          newRange.collapse(true);
          selection.removeAllRanges();
          selection.addRange(newRange);
        }

        saveState();
        return;
      }
    }

    if (e.key === 'Backspace') {
      const range = selection.getRangeAt(0);

      if (range.collapsed) {
        const blockWrapper = currentNode.closest('.vini-img-wrapper');
        const currentP = currentNode.closest('p');

        if (blockWrapper && range.startOffset === 0) {
          e.preventDefault();
          const previousSibling = blockWrapper.previousElementSibling;

          if (previousSibling) {
            previousSibling.remove();
            placeCaretOnLeftSide(blockWrapper);
            saveState();
          }
          return;
        }

        if (currentP && range.startOffset === 0) {
          const previousSibling = currentP.previousElementSibling;

          if (previousSibling) {
            e.preventDefault();

            if (previousSibling.classList.contains('vini-img-wrapper')) {
              const isEmptyText = currentP.textContent.replace(/\u200B/g, '').trim() === '';
              if (isEmptyText) {
                currentP.remove();
              }
              placeCaretOnRightSide(previousSibling);
            } else if (previousSibling.tagName === 'P') {
              const targetRange = document.createRange();
              targetRange.selectNodeContents(previousSibling);
              targetRange.collapse(false);

              while (currentP.firstChild) {
                previousSibling.appendChild(currentP.firstChild);
              }

              currentP.remove();
              selection.removeAllRanges();
              selection.addRange(targetRange);
            } else {
              previousSibling.remove();
              placeCaretOnLeftSide(currentP);
            }

            saveState();
            return;
          }
        }
      }
    }
  });

  function placeCaretOnLeftSide(blockEl) {
    if (!blockEl) return;
    const sel = window.getSelection();
    const range = document.createRange();
    range.setStart(blockEl, 0);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function placeCaretOnRightSide(blockEl) {
    if (!blockEl) return;
    const sel = window.getSelection();
    const range = document.createRange();
    range.setStart(blockEl, blockEl.childNodes.length);
    range.collapse(true);
    sel.removeAllRanges();
    sel.addRange(range);
  }

  formatButtons.forEach(button => {
    button.addEventListener('mousedown', (e) => e.preventDefault());
    button.addEventListener('click', (e) => {
      e.preventDefault();
      const command = button.getAttribute('data-command');
      document.execCommand(command, false, null);
      editorContent.focus();
      syncToolbarState();
      saveState();
    });
  });

  function insertBlockContent(elementNode) {
    editorContent.focus();
    const sel = window.getSelection();
    if (!sel.rangeCount) return;

    const range = sel.getRangeAt(0);
    let node = range.startContainer;

    let currentBlock = node.nodeType === 3 ? node.parentElement : node;
    while (currentBlock && currentBlock.parentElement !== editorContent && currentBlock !== editorContent) {
      currentBlock = currentBlock.parentElement;
    }

    const textContent = (currentBlock ? currentBlock.textContent : editorContent.textContent).replace(/\u200B/g, '').trim();
    const hasMedia = currentBlock ? currentBlock.querySelector('img, .vini-img-wrapper') : editorContent.querySelector('img, .vini-img-wrapper');
    const isEmptyLine = textContent === '' && !hasMedia;

    if (isEmptyLine && currentBlock && currentBlock !== editorContent) {
      currentBlock.replaceWith(elementNode);
    } else {
      if (currentBlock && currentBlock !== editorContent) {
        currentBlock.after(elementNode);
      } else {
        editorContent.appendChild(elementNode);
      }
    }

    let trailingP = elementNode.nextElementSibling;
    if (!trailingP || trailingP.tagName !== 'P') {
      trailingP = document.createElement('p');
      trailingP.style.textAlign = 'left';
      trailingP.innerHTML = '<br>';
      elementNode.after(trailingP);
    }

    const newRange = document.createRange();
    newRange.setStart(trailingP, 0);
    newRange.collapse(true);
    sel.removeAllRanges();
    sel.addRange(newRange);

    saveState();
  }

  let wpMediaFrame = null;

  imgBtn.addEventListener('click', (e) => {
    e.preventDefault();

    if (typeof wp === 'undefined' || !wp.media) {
      return;
    }

    if (wpMediaFrame) {
      wpMediaFrame.open();
      return;
    }

    wpMediaFrame = wp.media({
      title: 'Select or Upload Image',
      button: {
        text: 'Use This Image'
      },
      multiple: false
    });

    wpMediaFrame.on('select', () => {
      const attachment = wpMediaFrame.state().get('selection').first().toJSON();
      if (attachment && attachment.url) {
        const wrapper = document.createElement('div');
        wrapper.className = 'vini-img-wrapper';
        wrapper.style.textAlign = 'left';
        wrapper.style.marginTop = '14px';
        wrapper.style.marginBottom = '14px';

        const img = document.createElement('img');
        img.src = attachment.url;
        img.alt = attachment.alt || 'Uploaded Image';
        img.style.width = '100%';

        wrapper.appendChild(img);
        insertBlockContent(wrapper);

        setTimeout(() => openImageModal(img), 50);
      }
    });

    wpMediaFrame.open();
  });

  editorContent.addEventListener('mousedown', (e) => {
    const img = e.target.closest('img');
    const wrapper = e.target.closest('.vini-img-wrapper');

    if (img) {
      e.preventDefault();
      openImageModal(img);

      const rect = img.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;

      if (e.clientX < centerX) {
        placeCaretOnLeftSide(wrapper || img.closest('.vini-img-wrapper'));
      } else {
        placeCaretOnRightSide(wrapper || img.closest('.vini-img-wrapper'));
      }
      return;
    }

    if (wrapper) {
      e.preventDefault();
      const childElem = wrapper.querySelector('a, img') || wrapper;
      const rect = childElem.getBoundingClientRect();

      if (e.clientX < rect.left) {
        placeCaretOnLeftSide(wrapper);
      } else {
        placeCaretOnRightSide(wrapper);
      }
    }
  });

  function openImageModal(imgEl) {
    activeSelectedImg = imgEl;
    let wrapper = imgEl.closest('.vini-img-wrapper');

    if (!wrapper) {
      wrapper = document.createElement('div');
      wrapper.className = 'vini-img-wrapper';
      imgEl.parentNode.insertBefore(wrapper, imgEl);
      wrapper.appendChild(imgEl);
    }

    const currentWidth = parseInt(imgEl.style.width, 10) || 100;
    const currentTop = parseInt(wrapper.style.marginTop, 10) || 14;
    const currentBottom = parseInt(wrapper.style.marginBottom, 10) || 14;
    const currentAlign = wrapper.style.textAlign || 'left';

    imgSizeSlider.value = currentWidth;
    imgSizeVal.innerText = currentWidth + '%';

    imgTopSlider.value = currentTop;
    imgTopVal.innerText = currentTop + 'px';

    imgBottomSlider.value = currentBottom;
    imgBottomVal.innerText = currentBottom + 'px';

    imgAlignBtns.forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-align') === currentAlign);
    });

    centerModal(imgModal);
    imgModal.classList.remove('vini-hidden');
  }

  imgModalClose.addEventListener('click', () => imgModal.classList.add('vini-hidden'));

  imgSizeSlider.addEventListener('input', () => {
    const val = imgSizeSlider.value;
    imgSizeVal.innerText = val + '%';
    if (activeSelectedImg) {
      activeSelectedImg.style.width = val + '%';
      saveState();
    }
  });

  imgAlignBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      imgAlignBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (activeSelectedImg) {
        let wrapper = activeSelectedImg.closest('.vini-img-wrapper');
        if (!wrapper) {
          wrapper = document.createElement('div');
          wrapper.className = 'vini-img-wrapper';
          activeSelectedImg.parentNode.insertBefore(wrapper, activeSelectedImg);
          wrapper.appendChild(activeSelectedImg);
        }
        wrapper.style.textAlign = btn.getAttribute('data-align');
        saveState();
      }
    });
  });

  imgTopSlider.addEventListener('input', () => {
    const val = imgTopSlider.value;
    imgTopVal.innerText = val + 'px';
    if (activeSelectedImg) {
      let wrapper = activeSelectedImg.closest('.vini-img-wrapper');
      if (wrapper) wrapper.style.marginTop = val + 'px';
      saveState();
    }
  });

  imgBottomSlider.addEventListener('input', () => {
    const val = imgBottomSlider.value;
    imgBottomVal.innerText = val + 'px';
    if (activeSelectedImg) {
      let wrapper = activeSelectedImg.closest('.vini-img-wrapper');
      if (wrapper) wrapper.style.marginBottom = val + 'px';
      saveState();
    }
  });

  imgDeleteBtn.addEventListener('click', () => {
    if (activeSelectedImg) {
      const wrapper = activeSelectedImg.closest('.vini-img-wrapper');
      if (wrapper) wrapper.remove();
      else activeSelectedImg.remove();

      activeSelectedImg = null;
      imgModal.classList.add('vini-hidden');
      saveState();
    }
  });

  function updatePreviews() {
    if (typeof window.ssUpdatePreview === 'function') {
      window.ssUpdatePreview();
    }
  }

  editorContent.addEventListener('input', saveState);
  updatePreviews();
}