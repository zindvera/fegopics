=== ScrollStrike ===
Contributors: Fegopics
Tags: affiliate-links, link-highlighter, tooltip, block-editor, affiliate-revenue
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Increase your affiliate link clicks by highlighting your affiliate links on the page.

== Description ==
Increase your affiliate link clicks & affiliate revenue by highlighting your affiliate links on the page.
Simply create highlighter tooltips on your affiliate links so as visitors scroll, your links get highlighted with context and can't be missed.

=== How It Works ===
1. Create a highlighter tooltip for your affiliate link.
2. Add short context or details about what the link offers.
3. As readers scroll through your article, your affiliate links automatically highlight themselves on-screen with their tooltips—making your affiliate link impossible to ignore.

== Third-Party Services ==
This plugin connects to an external third-party API service to handle PRO version license key verification and plan status checks.

* **Service Name:** Gumroad License Verification API
* **Service URL:** https://api.gumroad.com/v2/licenses/verify
* **Data Transmitted:** License key string and product ID hash entered by the site administrator. No personal user, visitor, or tracking data is collected or sent.
* **When Transmitted:** Executed asynchronously when an administrator enters a license key on the "Upgrade to PRO" page or during periodic background license status checks.
* **Terms of Service:** https://gumroad.com/terms
* **Privacy Policy:** https://gumroad.com/privacy

== Installation ==
1. Upload the `scrollstrike` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Open any post in the editor, highlight text, and attach your highlighter.

== Changelog ==
= 1.0.0 =
* Initial official release.