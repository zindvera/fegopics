<?php
if (!defined('ABSPATH')) exit;

function scrollstrike_render_support_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized entry.', 'scrollstrike'));
    }
?>
    <div class="wrap">
        <div class="ss-support-wrap">
            <div class="ss-support-dashboard">

                <div class="ss-support-header">
                    <h1><?php esc_html_e('Help & Support', 'scrollstrike'); ?></h1>
                    <p class="ss-support-intro-text"><?php esc_html_e('Have a query or need technical help with ScrollStrike Pro? You can reach our team directly at:', 'scrollstrike'); ?></p>
                    <div class="ss-premium-email-block">
                        <a href="mailto:support@fegopics.online" class="ss-support-email-link">support@fegopics.online</a>
                    </div>
                </div>

                <div class="ss-faq-container">
                    <div class="ss-faq-category-block">
                        <h2>⚙️ <?php esc_html_e('Highlighter Behavior & Setup', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How do I create and deploy a new scroll-triggered highlighter?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Open any post or page inside your WordPress block editor. Highlight the text or phrase you want to highlight, click the ScrollStrike marker icon in your text formatting toolbar, customize your message/colors, and update your post to make it live.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Will deleting a highlighter from my library break my page layouts?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('No. When you delete a highlighter from your dashboard library, the plugin automatically cleans up the markup across your site. Your original text remains intact on the page as normal, unhighlighted text.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q3:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('What happens if two highlighters overlap on the same text?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('To ensure clean styling and prevent conflicting triggers, each specific phrase can only have one highlighter attached. If you want to trigger another tooltip, apply it to a separate sentence or word further down the page.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="ss-faq-category-block">
                        <h2>👑 <?php esc_html_e('Pro Features & Capabilities', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How does Focus Mode (Background Blur) work?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('When Focus Mode is enabled on a highlighter, the rest of the page layout automatically dims and blurs when the visitor scrolls the highlighted element into view. This isolates the reader’s visual attention directly onto your high-value link or offer.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Can I use custom brand hex colors for highlighters?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Yes. Along with the curated presets, your Pro license includes the full custom color palette and manual hex/RGB inputs, allowing you to match your exact brand colors for highlighter backgrounds and text.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q3:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How do Display Frequency settings work?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('You can control how often a highlighter appears for returning visitors: "Every visit" shows it on each page load, "Lifetime once" shows it only once per visitor browser session, and custom options allow delays based on days or visit counts.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="ss-faq-category-block">
                        <h2>⭐ <?php esc_html_e('ScrollStrike Lifetime License', 'scrollstrike'); ?></h2>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q1:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('Does my ScrollStrike license ever expire?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('No. Your ScrollStrike Lifetime Plan purchase provides lifetime access with no recurring subscription fees. Your workspace remains permanently unlocked on the Pro tier.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="ss-faq-item">
                            <button class="ss-faq-question" onclick="ssToggleFaq(this)">
                                <span class="ss-faq-q-text-wrapper">
                                    <span class="ss-faq-q-number"><?php esc_html_e('Q2:', 'scrollstrike'); ?></span>
                                    <span><?php esc_html_e('How do I receive plugin updates for my Pro version?', 'scrollstrike'); ?></span>
                                </span>
                                <span class="ss-faq-icon">+</span>
                            </button>
                            <div class="ss-faq-answer">
                                <div class="ss-faq-answer-content">
                                    <?php esc_html_e('Updates are integrated into your WordPress dashboard. Whenever a new version is released, an update notice will appear under Plugins > Installed Plugins, where you can update seamlessly with one click.', 'scrollstrike'); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php
}