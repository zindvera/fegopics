<?php
if (!defined('ABSPATH')) exit;

// Handlers kept for backwards-compatibility with any background pings
add_action('wp_ajax_scrollstrike_get_subscription_details', 'scrollstrike_ajax_get_subscription_details');
function scrollstrike_ajax_get_subscription_details() {
    check_ajax_referer('ss_account_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(esc_html__('Unauthorized', 'scrollstrike'));
    }

    $installed_at = get_option('scrollstrike_installed_at');
    if (empty($installed_at)) {
        $installed_at = current_time('timestamp');
        update_option('scrollstrike_installed_at', $installed_at);
    }
    $formatted_start_date = wp_date(get_option('date_format'), intval($installed_at));

    wp_send_json_success([
        'email'        => '',
        'product_name' => esc_html__('ScrollStrike Lifetime Pro Plan', 'scrollstrike'),
        'start_date'   => $formatted_start_date,
        'expiry_date'  => esc_html__('Lifetime (Never Expires)', 'scrollstrike')
    ]);
}

function scrollstrike_render_account_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized entry.', 'scrollstrike'));
    }

    $current_user = wp_get_current_user();
    $display_name = !empty($current_user->display_name) ? $current_user->display_name : $current_user->user_login;
    $system_email = $current_user->user_email;

    // Direct server-side generation of installation & plan details
    $installed_at = get_option('scrollstrike_installed_at');
    if (empty($installed_at)) {
        $installed_at = current_time('timestamp');
        update_option('scrollstrike_installed_at', $installed_at);
    }
    $formatted_start_date = wp_date(get_option('date_format'), intval($installed_at));
    $plan_name            = esc_html__('ScrollStrike Lifetime Pro Plan', 'scrollstrike');
    $expiry_date          = esc_html__('Lifetime (Never Expires)', 'scrollstrike');
    ?>
    <div class="wrap ss-account-page-wrap">
        <div id="ss-account-container" class="ss-account-card">

            <h1 class="ss-page-main-heading"><?php esc_html_e('Account Overview', 'scrollstrike'); ?></h1>

            <div id="ss-account-pro">
                <div class="ss-detail-box ss-bg-orange-tint">
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Administrator', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><?php echo esc_html($display_name); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('System Email', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><?php echo esc_html($system_email); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Current Plan', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value"><span class="ss-pill-pro"><?php esc_html_e('PRO Version Active', 'scrollstrike'); ?></span></span>
                    </div>
                </div>

                <div class="ss-detail-box ss-bg-white">
                    <h3 class="ss-plan-details-subhead"><?php esc_html_e('Plan Details', 'scrollstrike'); ?></h3>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Plan Package Name', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-pro-name"><?php echo esc_html($plan_name); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Plan Start Date', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-sub-start"><?php echo esc_html($formatted_start_date); ?></span>
                    </div>
                    <div class="ss-detail-row">
                        <span class="ss-detail-label"><?php esc_html_e('Expiry Date', 'scrollstrike'); ?></span>
                        <span class="ss-detail-value" id="ss-sub-expiry"><?php echo esc_html($expiry_date); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}