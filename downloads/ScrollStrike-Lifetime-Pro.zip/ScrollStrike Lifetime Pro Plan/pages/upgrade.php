<?php
if (!defined('ABSPATH')) exit;

function scrollstrike_render_upgrade_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized entry.', 'scrollstrike'));
    }

    $account_url = admin_url('admin.php?page=scrollstrike-account');
?>
    <div class="wrap ss-page-wrapper">
        <div id="ss-top-card" class="ss-top-card-container">
            <h1 class="ss-page-main-heading"><?php esc_html_e('Pro Plan Workspace', 'scrollstrike'); ?></h1>

            <div class="ss-banner-status-box">
                <div id="ss-tier-status-banner" class="ss-status-banner-text">
                    <span class="ss-text-pro"><?php esc_html_e('You are in PRO Version', 'scrollstrike'); ?></span>
                </div>
                <div>
                    <a href="<?php echo esc_url($account_url); ?>" class="ss-link-sub-details"><?php esc_html_e('Subscription Details →', 'scrollstrike'); ?></a>
                </div>
            </div>

            <!-- Polished Lifetime License Status Card -->
            <div class="ss-detail-box ss-bg-slate" style="margin-top: 20px; border-left: 4px solid #ea580c; padding: 18px 22px; border-radius: 6px;">
                <div class="ss-detail-row" style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span class="ss-detail-label" style="font-weight: 600; font-size: 14px; color: #1e293b; display: block;">
                            <?php esc_html_e('License Plan', 'scrollstrike'); ?>
                        </span>
                        <span style="font-size: 13px; color: #64748b; margin-top: 4px; display: block;">
                            <?php esc_html_e('Your ScrollStrike Lifetime license is active and fully unlocked on this site.'); ?>
                        </span>
                    </div>
                    <span class="ss-pill-pro" style="background: #ea580c; color: #fff; font-weight: 700; padding: 6px 14px; border-radius: 20px; font-size: 12px; letter-spacing: 0.5px;">
                        <?php esc_html_e('LIFETIME ACTIVE', 'scrollstrike'); ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Features Comparison Matrix -->
        <div id="ss-features-matrix-grid" class="ss-features-matrix ss-opacity-1" style="margin-top: 25px;">
            <div class="ss-matrix-card ss-matrix-free">
                <h3 class="ss-matrix-card-title ss-text-muted"><?php esc_html_e('Free Version', 'scrollstrike'); ?></h3>

                <div class="ss-matrix-features-list ss-text-slate">
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('Max 3 unique highlighters', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('Target only 3 elements', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('8 basic color presets only', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-green">✓</span> <?php esc_html_e('Frequency & Delay Control', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row ss-feature-disabled"><span class="ss-cross-gray">✕</span> <?php esc_html_e('Focus Mode (Background Blur)', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row ss-feature-disabled"><span class="ss-cross-gray">✕</span> <?php esc_html_e('Premium Customer Support', 'scrollstrike'); ?></div>
                </div>
            </div>

            <div class="ss-matrix-card ss-matrix-pro">
                <div id="ss-pro-current-strip" class="ss-current-plan-ribbon ss-show-block"><?php esc_html_e('Current Plan', 'scrollstrike'); ?></div>
                <h3 class="ss-matrix-card-title ss-text-orange"><?php esc_html_e('ScrollStrike PRO', 'scrollstrike'); ?></h3>

                <div class="ss-matrix-features-list ss-text-dark">
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <span><span class="ss-bold-orange"><?php esc_html_e('Unlimited', 'scrollstrike'); ?></span> <?php esc_html_e('unique highlighters', 'scrollstrike'); ?></span></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <span><span class="ss-bold-orange"><?php esc_html_e('Unlimited', 'scrollstrike'); ?></span> <?php esc_html_e('target elements', 'scrollstrike'); ?></span></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Pick Any Color', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Frequency & Delay Control', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Focus Mode (Background Blur)', 'scrollstrike'); ?></div>
                    <div class="ss-feature-row"><span class="ss-check-orange">✓</span> <?php esc_html_e('Premium Customer Support', 'scrollstrike'); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php
}