(function () {
    const initScrollStrike = () => {
        // --- STEP 0: DOM NORMALIZER (Invert <a href><mark> to <mark><a href>) ---
        document.querySelectorAll('a > mark.scrollstrike-trigger-word').forEach(mark => {
            const anchor = mark.closest('a');
            if (!anchor || !anchor.parentNode) return;

            const nonWhitespaceNodes = Array.from(anchor.childNodes).filter(
                node => node.nodeType !== Node.TEXT_NODE || node.textContent.trim().length > 0
            );

            if (nonWhitespaceNodes.length === 1 && nonWhitespaceNodes[0] === mark) {
                const innerLink = anchor.cloneNode(false);
                while (mark.firstChild) {
                    innerLink.appendChild(mark.firstChild);
                }
                mark.appendChild(innerLink);
                anchor.parentNode.insertBefore(mark, anchor);
                anchor.remove();
            } else {
                const innerLink = anchor.cloneNode(false);
                while (mark.firstChild) {
                    innerLink.appendChild(mark.firstChild);
                }
                mark.appendChild(innerLink);
                anchor.parentNode.insertBefore(mark, anchor);
            }
        });

        const triggers = document.querySelectorAll('.scrollstrike-trigger-word');
        if (triggers.length === 0) return;

        let notesData = [];
        let isPro = false;

        if (typeof scrollstrike_data !== 'undefined' && scrollstrike_data.notes) {
            notesData = scrollstrike_data.notes;
            isPro = scrollstrike_data.is_pro === true || scrollstrike_data.is_pro === '1';
        }

        // --- HELPER: Close Icon Color Contrast ---
        const getCloseIconColor = (hex) => {
            if (!hex) return 'rgba(0,0,0,0.4)';
            let cleanHex = hex.replace('#', '');
            if (cleanHex.length === 3) cleanHex = cleanHex.split('').map(c => c + c).join('');
            const r = parseInt(cleanHex.substring(0, 2), 16);
            const g = parseInt(cleanHex.substring(2, 4), 16);
            const b = parseInt(cleanHex.substring(4, 6), 16);
            const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
            return (yiq >= 128) ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.8)';
        };

        // --- HELPER: Page-Relative Mask Hole with Responsive Clearance ---
        const updateOverlayHole = (triggerEl, overlay) => {
            if (!triggerEl || !overlay) return;
            const rect = triggerEl.getBoundingClientRect();
            const isMobile = window.innerWidth <= 767;

            // Clearance settings: mobile expands upward and tightens at bottom
            const padX = isMobile ? 30 : 110;
            const padTop = isMobile ? 95 : 85;
            const padBottom = isMobile ? 18 : 35;

            const pageX = rect.left + window.scrollX;
            const pageY = rect.top + window.scrollY;

            const x = Math.max(0, pageX - padX);
            const y = Math.max(0, pageY - padTop);
            const w = rect.width + (padX * 2);
            const h = rect.height + padTop + padBottom;

            overlay.style.setProperty('--hole-x', `${x}px`);
            overlay.style.setProperty('--hole-y', `${y}px`);
            overlay.style.setProperty('--hole-w', `${w}px`);
            overlay.style.setProperty('--hole-h', `${h}px`);
        };

        // --- LOGIC: Behavioral Rules ---
        const evaluateBehavioralRules = (note, trackingKey) => {
            const now = Date.now();
            const freqType = note.frequency_type || 'always';
            const freqVal = parseInt(note.frequency_value) || 1;

            const lastSeen = localStorage.getItem(`ss_last_seen_${trackingKey}`);
            const gapCount = parseInt(localStorage.getItem(`ss_gap_${trackingKey}`) || '0');

            if (freqType === 'once' && lastSeen) return 'HIDE';
            if (freqType === 'days' && lastSeen) {
                const daysPassed = (now - parseInt(lastSeen)) / (1000 * 60 * 60 * 24);
                if (daysPassed < freqVal) return 'HIDE';
            }
            if (freqType === 'visits' && lastSeen) {
                if (gapCount < freqVal) return 'GAP';
            }
            return 'SHOW';
        };

        const markAsViewed = (trackingKey) => {
            localStorage.setItem(`ss_last_seen_${trackingKey}`, Date.now());
            localStorage.setItem(`ss_gap_${trackingKey}`, '0');
        };

        const incrementGap = (trackingKey) => {
            const gapCount = parseInt(localStorage.getItem(`ss_gap_${trackingKey}`) || '0');
            localStorage.setItem(`ss_gap_${trackingKey}`, gapCount + 1);
        };

        const handleDismiss = (tooltipWrapper, triggerEl, focusMode) => {
            tooltipWrapper.style.opacity = '0';
            tooltipWrapper.style.pointerEvents = 'none';

            if (isPro && focusMode == 1) {
                triggerEl.classList.remove('ss-focus-active');
                document.body.classList.remove('ss-blur-enabled');
                const overlay = document.getElementById('ss-focus-overlay');
                if (overlay) {
                    overlay.style.opacity = '0';
                    if (window._ssOverlayResizeHandler) {
                        window.removeEventListener('resize', window._ssOverlayResizeHandler);
                    }
                }
                setTimeout(() => {
                    if (overlay) overlay.remove();
                    tooltipWrapper.remove();
                }, 400);
            } else {
                setTimeout(() => tooltipWrapper.remove(), 400);
            }
        };

        // --- LOGIC: Intersection Observer ---
        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const triggerEl = entry.target;
                    if (triggerEl.dataset.rendered === "true") return;

                    const id = triggerEl.getAttribute('data-id');
                    const placementIndex = triggerEl.getAttribute('data-placement-index');
                    const pagePath = window.location.pathname;
                    const trackingKey = `${id}_${pagePath}_${placementIndex}`;
                    const note = notesData.find(n => n.id === id);

                    if (note) {
                        const ruleStatus = evaluateBehavioralRules(note, trackingKey);

                        if (ruleStatus === 'SHOW') {
                            triggerEl.dataset.rendered = "true";
                            renderTooltip(triggerEl, note);
                            markAsViewed(trackingKey);
                        } else if (ruleStatus === 'GAP') {
                            incrementGap(trackingKey);
                        }
                    }

                    obs.unobserve(triggerEl);
                }
            });
        }, { threshold: 0.5 });

        // --- UI: Render Tooltip ---
        const renderTooltip = (triggerEl, note) => {
            if (triggerEl.querySelector('.scrollstrike-tooltip-box')) return;

            const localDelayAttr = triggerEl.getAttribute('data-local-delay');
            const delay = localDelayAttr !== null ? parseFloat(localDelayAttr) : (parseFloat(note.delay_time) || 0);

            setTimeout(() => {
                const hasImage = /<img\b[^>]*>/i.test(note.note_text || '');

                const tooltip = document.createElement('div');
                tooltip.className = 'scrollstrike-tooltip-box' + (hasImage ? ' has-img' : '');
                tooltip.style.backgroundColor = note.bg_color || '#fff1f1';
                tooltip.style.color = note.text_color || '#333333';

                const closeBtn = document.createElement('span');
                closeBtn.className = 'scrollstrike-close-btn';
                closeBtn.innerHTML = '✕';
                closeBtn.style.color = getCloseIconColor(note.bg_color);
                closeBtn.onclick = (e) => {
                    e.stopPropagation();
                    handleDismiss(tooltip, triggerEl, note.focus_mode);
                };

                const content = document.createElement('div');
                content.className = 'scrollstrike-content vini-content';
                content.innerHTML = note.note_text;

                content.querySelectorAll('.vini-img-wrapper').forEach(wrapper => {
                    if (wrapper.style.textAlign) wrapper.style.setProperty('text-align', wrapper.style.textAlign, 'important');
                    if (wrapper.style.marginTop) wrapper.style.setProperty('margin-top', wrapper.style.marginTop, 'important');
                    if (wrapper.style.marginBottom) wrapper.style.setProperty('margin-bottom', wrapper.style.marginBottom, 'important');
                });

                content.querySelectorAll('img').forEach(img => {
                    if (img.style.width) img.style.setProperty('width', img.style.width, 'important');
                });

                const arrow = document.createElement('div');
                arrow.className = 'scrollstrike-arrow';
                const dynamicBg = note.bg_color || '#fff1f1';
                arrow.style.borderTopColor = dynamicBg;
                arrow.style.borderBottomColor = dynamicBg;

                tooltip.appendChild(closeBtn);
                tooltip.appendChild(content);
                tooltip.appendChild(arrow);
                triggerEl.appendChild(tooltip);

                if (isPro && note.focus_mode == 1) {
                    document.querySelectorAll('.ss-focus-active').forEach(el => el.classList.remove('ss-focus-active'));

                    let overlay = document.getElementById('ss-focus-overlay');
                    if (!overlay) {
                        overlay = document.createElement('div');
                        overlay.id = 'ss-focus-overlay';
                        document.body.appendChild(overlay);
                    }

                    triggerEl.classList.add('ss-focus-active');
                    updateOverlayHole(triggerEl, overlay);

                    window._ssOverlayResizeHandler = () => updateOverlayHole(triggerEl, overlay);
                    window.addEventListener('resize', window._ssOverlayResizeHandler, { passive: true });

                    void overlay.offsetWidth;
                    overlay.style.opacity = '1';
                    document.body.classList.add('ss-blur-enabled');
                }

                requestAnimationFrame(() => {
                    tooltip.style.transition = 'none';

                    const lineRects = triggerEl.getClientRects();
                    const triggerRect = triggerEl.getBoundingClientRect();
                    const firstLineRect = lineRects.length > 0 ? lineRects[0] : triggerRect;

                    let majorityLine = firstLineRect;
                    for (let i = 1; i < lineRects.length; i++) {
                        if (lineRects[i].width > majorityLine.width) {
                            majorityLine = lineRects[i];
                        }
                    }

                    const defaultOriginTop = firstLineRect.top;
                    const verticalDeltaY = majorityLine.top - defaultOriginTop;

                    const defaultOriginLeft = firstLineRect.left;
                    const majorityCenterOffset = (majorityLine.left + (majorityLine.width / 2)) - defaultOriginLeft;

                    tooltip.style.left = `${majorityCenterOffset}px`;
                    tooltip.style.transform = `translateX(-50%) translateY(${verticalDeltaY}px)`;

                    void tooltip.offsetWidth;

                    const rect = tooltip.getBoundingClientRect();
                    const viewportWidth = document.documentElement.clientWidth;

                    // --- VERTICAL FLIP DETECTOR ---
                    const spaceOnTop = rect.top;
                    const dynamicBgColor = note.bg_color || '#fff1f1';

                    if (spaceOnTop < 10) {
                        tooltip.classList.add('ss-flipped');
                        const flippedArrow = tooltip.querySelector('.scrollstrike-arrow');
                        if (flippedArrow) flippedArrow.style.borderBottomColor = dynamicBgColor;
                    }

                    const isFlipped = tooltip.classList.contains('ss-flipped');
                    const screenMargin = 16;
                    let shift = 0;

                    if (rect.right > viewportWidth - screenMargin) {
                        shift = rect.right - (viewportWidth - screenMargin);
                    }
                    if (rect.left - shift < screenMargin) {
                        shift = (rect.left - screenMargin);
                    }

                    const finalTransformX = `calc(-50% - ${shift}px)`;

                    // Pointer calculation
                    const activeTargetRect = isFlipped ? firstLineRect : majorityLine;
                    const targetCenter = activeTargetRect.left + (activeTargetRect.width / 2);
                    const visualTooltipLeft = rect.left - shift;
                    let arrowTargetX = targetCenter - visualTooltipLeft;

                    const arrowPadding = 18;
                    const minX = arrowPadding;
                    const maxX = Math.max(arrowPadding, rect.width - arrowPadding);
                    arrowTargetX = Math.max(minX, Math.min(arrowTargetX, maxX));

                    arrow.style.left = `${arrowTargetX}px`;
                    arrow.style.transform = 'translateX(-50%)';

                    // Distance: When flipped downward, place it just 14px below line 1
                    const flippedFinalY = firstLineRect.height + 14;
                    const finalTargetY = isFlipped ? flippedFinalY : verticalDeltaY;

                    // Entrance pop offset
                    const startY = isFlipped ? (finalTargetY - 8) : (verticalDeltaY + 10);
                    tooltip.style.transform = `translateX(${finalTransformX}) translateY(${startY}px)`;

                    void tooltip.offsetWidth;

                    tooltip.style.transition = 'opacity 0.4s ease, transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                    tooltip.style.transform = `translateX(${finalTransformX}) translateY(${finalTargetY}px)`;
                    tooltip.style.opacity = '1';
                });

            }, delay * 1000);
        };

        // --- DOM INITIALIZATION ---
        let activeElementsRendered = 0;

        triggers.forEach((trigger, index) => {
            const id = trigger.getAttribute('data-id');
            const noteExists = notesData.some(n => n.id === id);

            if (!noteExists || (!isPro && activeElementsRendered >= 3)) {
                const fragment = document.createDocumentFragment();
                while (trigger.firstChild) {
                    fragment.appendChild(trigger.firstChild);
                }
                trigger.parentNode.replaceChild(fragment, trigger);
                return;
            }

            activeElementsRendered++;
            trigger.setAttribute('data-placement-index', index);
            observer.observe(trigger);
        });
    };

    const onFullLoad = () => {
        setTimeout(initScrollStrike, 500);
    };

    if (document.readyState === 'complete') {
        onFullLoad();
    } else {
        window.addEventListener('load', onFullLoad);
    }
})();