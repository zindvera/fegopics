=== ScrollStrike Pro ===
Contributors: Fegopics
Tags: affiliate-links, link-highlighter, tooltip, block-editor, affiliate-revenue
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Increase your affiliate link clicks by highlighting your affiliate links on the page.

== Description ==
Increase your affiliate link clicks & affiliate revenue by highlighting your affiliate links on the page.
Simply create highlighter tooltips on your affiliate links so as visitors scroll, your links get highlighted with context and can't be missed.

=== Lifetime Pro Edition ===
This build includes full, permanent access to all ScrollStrike Pro features:
* Unlimited unique highlighters and element deployments
* Full custom hex & RGB color customization
* Focus Mode (scroll-triggered background blur)
* Custom trigger delays and display frequency controls
* Dashboard-integrated automatic updates with no recurring fees

=== How It Works ===
1. Create a highlighter tooltip for your affiliate link.
2. Add short context or details about what the link offers.
3. As readers scroll through your article, your affiliate links automatically highlight themselves on-screen with their tooltips—making your affiliate link impossible to ignore.

== Installation ==
1. Upload the `scrollstrike` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Open any post in the editor, highlight text, and attach your highlighter.

== Changelog ==
= 1.0.0 =
* Initial official Lifetime Pro release.